#!/usr/bin/env sh

docker image build --build-arg APP_BIN=lms-energybatch.jar --tag lms-batch:latest .
docker image tag lms-batch:latest aztechsg/lms-batch:latest
docker image push aztechsg/lms-batch:latest
