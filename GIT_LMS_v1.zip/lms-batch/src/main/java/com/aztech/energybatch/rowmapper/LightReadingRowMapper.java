package com.aztech.energybatch.rowmapper;

import com.aztech.energybatch.listener.JobExecutionListener;
import com.aztech.energybatch.entity.LightReading;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class LightReadingRowMapper implements RowMapper<LightReading> {
    private static final Logger log = LoggerFactory.getLogger(LightReadingRowMapper.class);

    @Override
    public LightReading mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new LightReading(rs.getInt("currentLevel"),
                rs.getString("reportDateTime"), rs.getString("lightSN"),
                rs.getString("blockNO"));
    }
}
