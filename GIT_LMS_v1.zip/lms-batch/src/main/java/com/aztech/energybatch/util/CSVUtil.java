package com.aztech.energybatch.util;

import com.aztech.energybatch.entity.HourlyConsumption;
import com.aztech.energybatch.entity.LightReading;
import com.aztech.energybatch.entity.Smartlight;

import java.io.*;
import java.util.*;

/**
 * Simple util class for file CRUD operations
 */
public class CSVUtil {
    public static Map<String, List<LightReading>> readLightReadingFile(String fileName) {
        Map<String, List<LightReading>> lightReadingsMap = new HashMap<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line = "";
            while ((line = reader.readLine()) != null) {
                String[] items = line.split(",");

                try {
                    if (items.length>4) {
                        throw new ArrayIndexOutOfBoundsException();
                    } else {
                        LightReading lightReading = new LightReading(Integer.parseInt(items[0]), items[1], items[2], items[3]);

                        String newKey = lightReading.getBlockNO() + "@" + lightReading.getLightSN();

                        if (lightReadingsMap.containsKey(newKey)) {
                            lightReadingsMap.get(newKey).add(lightReading);
                        } else {
                            List lst = new ArrayList<>();
                            lst.add(lightReading);
                            lightReadingsMap.put(newKey, lst);
                        }
                    }
                } catch (ArrayIndexOutOfBoundsException|NumberFormatException|NullPointerException e) {
                    System.out.println("Invalid line: "+ line);
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lightReadingsMap;
    }

    public static ArrayList<HourlyConsumption> readHourlyConsumptionFile(String fileName) {
        ArrayList<HourlyConsumption> consumptionList = new ArrayList<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line = "";
            while ((line = reader.readLine()) != null) {
                String[] items = line.split(",");

                try {
                    if (items.length>4) {
                        throw new ArrayIndexOutOfBoundsException();
                    } else {
                        HourlyConsumption hourlyConsumption = new HourlyConsumption(Integer.parseInt(items[0]), items[1], Float.parseFloat(items[2]));
                        consumptionList.add(hourlyConsumption);
                    }
                } catch (ArrayIndexOutOfBoundsException|NumberFormatException|NullPointerException e) {
                    System.out.println("Invalid line: "+ line);
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return consumptionList;
    }

    public static ArrayList<Smartlight> readSmartLightsFile(String fileName) {
        ArrayList<Smartlight> smartlights = new ArrayList<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line = "";
            while ((line = reader.readLine()) != null) {
                String[] items = line.split(",");

                try {
                    if (items.length>4) {
                        throw new ArrayIndexOutOfBoundsException();
                    } else {
                        Smartlight smartlight = new Smartlight();
                        smartlight.setLightId(items[0]);
                        smartlight.setLastHrCurrentLevel(Integer.parseInt(items[1]));
                        smartlights.add(smartlight);
                    }
                } catch (ArrayIndexOutOfBoundsException|NumberFormatException|NullPointerException e) {
                    System.out.println("Invalid line: "+ line);
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return smartlights;
    }

    public static void writeFile(String fileName, ArrayList<HourlyConsumption> consumptionList) {
        try (PrintWriter writer = new PrintWriter(new File(fileName))) {
            StringBuilder sb = new StringBuilder();
            for (HourlyConsumption temp: consumptionList) {
                sb.append(temp.toCsvString());
            }

            writer.write(String.valueOf(sb));
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void writeFile2(String fileName, ArrayList<Smartlight> smartLights) {
        try (PrintWriter writer = new PrintWriter(new File(fileName))) {
            StringBuilder sb = new StringBuilder();
            for (Smartlight temp: smartLights) {
                sb.append(temp.toCsvString());
            }

            writer.write(String.valueOf(sb));
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void writeExceptionFile(String fileName,  List<Throwable> exceptions) {
        try (PrintWriter writer = new PrintWriter(new File(fileName))) {
            StringBuilder sb = new StringBuilder();
            for (Throwable temp: exceptions) {
                sb.append(Arrays.toString(temp.getStackTrace()));
            }

            writer.write(String.valueOf(sb));
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void appendFile(String content) {
        File file = new File("batchlog.txt");

        try (FileWriter fw = new FileWriter(file, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write(content);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean deleteFile(String fileName) {
        File file = new File(fileName);
        return file.delete();
    }
}
