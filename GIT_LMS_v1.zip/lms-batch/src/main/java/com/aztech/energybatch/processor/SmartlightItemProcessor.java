package com.aztech.energybatch.processor;

import com.aztech.energybatch.BatchProcessingApplication;
import com.aztech.energybatch.entity.HourlyConsumption;
import com.aztech.energybatch.entity.LightReading;
import com.aztech.energybatch.entity.Smartlight;
import com.aztech.energybatch.util.CSVUtil;
import com.aztech.energybatch.util.ConstantValues;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.*;

public class SmartlightItemProcessor implements ItemProcessor<Smartlight, Smartlight>, StepExecutionListener {
	private static final Logger log = LoggerFactory.getLogger(SmartlightItemProcessor.class);
	private static String inputFile = "", outputFile = "", outputFile2 = "";

	private ArrayList<HourlyConsumption> consumptionList = new ArrayList<>();
	private Map<String, List<LightReading>> lightReadingsMap = new HashMap<>();
	private Map<String, Float> communityConsumption = new HashMap<>();
	private Map<String, Float> blockConsumption = new HashMap<>();
	private Map<String, Float> floorConsumption = new HashMap<>();
	private Map<String, Float> lightConsumption = new HashMap<>();
	private ArrayList<Smartlight> smartLights = new ArrayList<>();

	@Override
	public Smartlight process(final Smartlight smartlight) {
		//Final rounding for more human-readability
		DecimalFormat df = new DecimalFormat("#.####");
		df.setRoundingMode(RoundingMode.CEILING);

		String communityId = smartlight.getCommunityId();
		String blockId = smartlight.getBlockId();
		String floorId = smartlight.getFloorId();
		String lightId = smartlight.getLightId();
		LightReading currentLevelBeforeStartTime = new LightReading(smartlight.getLastHrCurrentLevel(), BatchProcessingApplication.startTime, smartlight.getDisplayName(), smartlight.getBlockNO());

		float ratedPower = 0.007f;    		//SPS100 Lighting 7Wh
		float actualPower = ratedPower * ((float)smartlight.getLastHrCurrentLevel()/100);

		//Loop the available current level readings
		SortedSet<String> keys = new TreeSet<>(lightReadingsMap.keySet());
		for (String key : keys) {
			if (lightReadingsMap.containsKey(key)) {
				ArrayList<LightReading> readings = (ArrayList<LightReading>) lightReadingsMap.get(key);
				String blockNO = readings.get(0).getBlockNO();
				String lightSN = readings.get(0).getLightSN();

				if (smartlight.getDisplayName().equals(lightSN) && smartlight.getBlockNO().equals(blockNO)) {
					//This smartlight has light reading data, do calculations
					actualPower = 0;

					try {
						//reading at xx:00:00
						if (!readings.get(0).getReportDateTime().equals(BatchProcessingApplication.startTime)) {
							readings.add(0, currentLevelBeforeStartTime);
						}

						//processing time in-between data (xx:00:00 - xx:59:59)
						for (int i = 1; i < readings.size() - 1; i++) {
							Date prevDate = BatchProcessingApplication.format.parse(readings.get(i - 1).getReportDateTime());            //get x date time
							Date nextDate = BatchProcessingApplication.format.parse(readings.get(i).getReportDateTime());                //get y date time
							float timeIntervalInMilis = Math.abs(nextDate.getTime() - prevDate.getTime());                               //get y - x time difference in ms
							float timeIntervalInHrs = (timeIntervalInMilis / 1000) / 60 / 60;                                            //convert to hours

							LightReading currentLevelOfPrevDate = readings.get(i - 1);                                                    //get x reading
							float calculatedPower = timeIntervalInHrs * ratedPower * ((float) currentLevelOfPrevDate.getLoad() / 100);    //get power consumption in kwH
							actualPower += calculatedPower;
						}

						//processing last data
						int lastIndex = readings.size() - 1;
						Date beforeLastDate = BatchProcessingApplication.format.parse(readings.get(lastIndex).getReportDateTime());    //currentList last date
						Date lastDate = BatchProcessingApplication.format.parse(BatchProcessingApplication.endTime);                   //xx:59:59

						if (beforeLastDate.before(lastDate)) {                                                                         //last data is before xx:59:59, so need to calculate interval
							float timeIntervalInMilis = Math.abs(beforeLastDate.getTime() - lastDate.getTime());
							float timeIntervalInHrs = (timeIntervalInMilis / 1000) / 60 / 60;

							float calculatedPower = timeIntervalInHrs * ratedPower * ((float) readings.get(readings.size() - 1).getLoad() / 100);
							actualPower += calculatedPower;
						}

						smartlight.setLastHrCurrentLevel(readings.get(readings.size() - 1).getLoad());
					} catch (ParseException pe) {
						pe.printStackTrace();
					}
				}
			}
		}

		//Final power, add sensor power usage
		//sps100 0.45w, sps200 0.575w
		actualPower += 0.0005f;

		//initialize power
		if (!lightConsumption.containsKey(lightId)) {
			lightConsumption.put(lightId, 0.0f);
		}
		if (!floorConsumption.containsKey(floorId)) {
			floorConsumption.put(floorId, 0.0f);
		}
		if (!blockConsumption.containsKey(blockId)) {
			blockConsumption.put(blockId, 0.0f);
		}
		if (!communityConsumption.containsKey(communityId)) {
			communityConsumption.put(communityId, 0.0f);
		}

		//fill power values
		if (lightId != null) {
			lightConsumption.put(lightId, Float.parseFloat(df.format(actualPower)));
		}
		if (floorId != null) {
			float newPower = floorConsumption.get(floorId);
			newPower += actualPower;
			floorConsumption.put(floorId, Float.parseFloat(df.format(newPower)));
		}
		if (blockId != null) {
			float newPower = blockConsumption.get(blockId);
			newPower += actualPower;
			blockConsumption.put(blockId, Float.parseFloat(df.format(newPower)));
		}
		if (communityId != null) {
			float newPower = communityConsumption.get(communityId);
			newPower += actualPower;
			communityConsumption.put(communityId, Float.parseFloat(df.format(newPower)));
		}

		smartLights.add(smartlight);

		return smartlight;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.info("START CALCULATING ENERGY CONSUMPTIONS - JOB PARAMS: " + stepExecution.getJobParameters() + " - inputFile: " + inputFile);
		inputFile = "energyBatchStep1_" + stepExecution.getJobParameters().getString("reportTime") + ".csv";
		outputFile = "energyBatchStep2_" + stepExecution.getJobParameters().getString("reportTime") + ".csv";
		outputFile2 = "energyBatchStep3_" + stepExecution.getJobParameters().getString("reportTime") + ".csv";
		lightReadingsMap = CSVUtil.readLightReadingFile(inputFile);
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		lightConsumption.forEach((key, value) -> consumptionList.add(new HourlyConsumption(ConstantValues.DataType.LIGHT, key, value)));
		floorConsumption.forEach((key, value) -> consumptionList.add(new HourlyConsumption(ConstantValues.DataType.FLOOR, key, value)));
		blockConsumption.forEach((key, value) -> consumptionList.add(new HourlyConsumption(ConstantValues.DataType.BLOCK, key, value)));
		communityConsumption.forEach((key, value) -> consumptionList.add(new HourlyConsumption(ConstantValues.DataType.AREA, key, value)));
		CSVUtil.writeFile(outputFile, consumptionList);
		CSVUtil.writeFile2(outputFile2, smartLights);
		boolean fileDeleted = CSVUtil.deleteFile(inputFile);
		log.info("COMPLETED CALCULATING ENERGY CONSUMPTIONS - prevStepFileDeleted: " + fileDeleted + " - JOB PARAMS: " + stepExecution.getJobParameters() + " - outputFile: " + outputFile);
		return stepExecution.getExitStatus();
	}
}