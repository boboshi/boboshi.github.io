package com.aztech.energybatch.util;

/**
 * Simple class for global constant values
 */
public class ConstantValues {
	public class MotionSensitivityString {
		public static final String ONE = "High";
		public static final String TWO = "Medium-High";
		public static final String THREE = "Medium";
		public static final String FOUR = "Medium-Low";
		public static final String FIVE = "Low";
	}

	public class LightIntensityString {
		public static final String ONE = "Slow";
		public static final String TWO = "Medium";
		public static final String THREE = "Fast";
	}

	public class DataType {
		public static final int AREA = 1;
		public static final int BLOCK = 2;
		public static final int FLOOR = 3;
		public static final int LIGHT = 4;
	}
}