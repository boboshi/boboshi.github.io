package com.aztech.energybatch.config;

import org.apache.hc.core5.net.URIBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import javax.sql.DataSource;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.Date;

public class DataSourceConfig {
    @Value("${app.datasource.url}")
    private String HSQL_URL;
    @Value("${app.mysqldatasource.url}")
    private String MYSQL_URL;
    @Autowired
    private Environment env;

    /**
     * Bean for hsql data source for spring batch's job management
     */
    @Bean
    @Primary
    public DataSource hsqldbDataSource() {
        final SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
        dataSource.setDriver(new org.hsqldb.jdbcDriver());
        dataSource.setUrl(HSQL_URL);
        dataSource.setUsername("sa");
        dataSource.setPassword("");
        return dataSource;
    }

    /**
     * Bean for mysql data source for lms db
     */
    @Bean
    public DataSource mysqlDataSource(Environment environment) throws SQLException, URISyntaxException {
        final SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
        dataSource.setDriver(new com.mysql.cj.jdbc.Driver());
        dataSource.setUrl(prepareJdbcUri(environment));
        dataSource.setUsername(loadUsername());
        dataSource.setPassword(loadPassword());
        return dataSource;
    }

    private String prepareJdbcUri(Environment environment) throws URISyntaxException {
        String dbHost = environment.getProperty("DB_HOST", "localhost");
        int dbPort = environment.getProperty("DB_PORT", Integer.class, 3306);

        URIBuilder uriBuilder = new URIBuilder();

        return new StringBuilder()
                .append("jdbc:")
                .append(uriBuilder
                        .setScheme("mysql")
                        .setHost(dbHost)
                        .setPort(dbPort)
                        .setPath("spsdb_sg")
                        .addParameter("useSSL", "false")
                        .addParameter("serverTimezone", "Asia/Singapore")
                        .addParameter("useLegacyDatetimeCode", "false")
                        .addParameter("useServerPrepStmts", "false")
                        .addParameter("rewriteBatchedStatements", "true")
                        .build().toString()).toString();
    }

    private String loadUsername() {
        return loadSecret("mysql_username");
    }

    private String loadPassword() {
        return loadSecret("mysql_password");
    }

    private String loadSecret(String name) {
        String secret = "";
        String secretPath = String.format("/run/secrets/%s", name);
        File secretFile = new File(secretPath);

        if (secretFile.exists()) {
            try (FileReader fileReader = new FileReader(secretFile)) {
                try (BufferedReader reader = new BufferedReader(fileReader)) {
                    secret = reader.readLine();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return secret;
    }
}
