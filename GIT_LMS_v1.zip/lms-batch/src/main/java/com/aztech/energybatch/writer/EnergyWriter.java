package com.aztech.energybatch.writer;

import com.aztech.energybatch.entity.HourlyConsumption;
import com.aztech.energybatch.entity.Smartlight;
import com.aztech.energybatch.util.CSVUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class EnergyWriter implements Tasklet, StepExecutionListener {
    private static final Logger log = LoggerFactory.getLogger(EnergyWriter.class);
    private String inputFile = "", inputFile2 = "";
    private ArrayList<HourlyConsumption> consumptionList;
    private ArrayList<Smartlight> smartlights;
    private String reportDate = "", reportTime = "";
    private int reportYear, reportMonth, reportDay, reportHour;

    @Autowired @Qualifier("mysqlDataSource")
    private DataSource dataSource;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        dailyBatch();
        monthlyBatch();
        yearlyBatch();
        updateSmartLights();

        return RepeatStatus.FINISHED;
    }

    private void dailyBatch() {
        String hour = String.valueOf(reportHour+1);
        String sql = "INSERT INTO energyConsumptionDay(dataType, dataId, reportDate, hourEnergy" + hour + ") " +
                "VALUES (?, ?, ?, ?) " +
                "ON DUPLICATE KEY " +
                "UPDATE hourEnergy" + hour + " = ?";

        log.info("dailyBatch() - reportDate: " + reportDate + ", sql: "  + sql);

        new JdbcTemplate(dataSource).batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                HourlyConsumption temp = consumptionList.get(i);
                ps.setInt(1, temp.getDataType());
                ps.setString(2, temp.getDataId());
                ps.setString(3, reportDate);
                ps.setFloat(4, temp.getValue());
                ps.setFloat(5, temp.getValue());
            }

            @Override
            public int getBatchSize() {
                return consumptionList.size();
            }
        });
    }

    private void monthlyBatch() {
        String day = String.valueOf(reportDay);
        String sql = "INSERT INTO energyConsumptionMonth(dataType, dataId, reportMonth, reportYear, dayEnergy" + day + ") " +
                "VALUES (?, ?, ?, ?, ?) " +
                "ON DUPLICATE KEY " +
                "UPDATE energyConsumptionMonth.dayEnergy" + day + " = energyConsumptionMonth.dayEnergy" + day + " + ?";

        log.info("monthlyBatch() - reportMonth: " + reportMonth + ", reportYear: " + reportYear + ", sql: " + sql);

        new JdbcTemplate(dataSource).batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                HourlyConsumption temp = consumptionList.get(i);
                ps.setInt(1, temp.getDataType());
                ps.setString(2, temp.getDataId());
                ps.setString(3, String.valueOf(reportMonth));
                ps.setString(4, String.valueOf(reportYear));
                ps.setFloat(5, temp.getValue());
                ps.setFloat(6, temp.getValue());
            }

            @Override
            public int getBatchSize() {
                return consumptionList.size();
            }
        });
    }

    private void yearlyBatch() {
        String month = String.valueOf(reportMonth);
        String sql = "INSERT INTO energyConsumptionYear(dataType, dataId, reportYear, monthEnergy" + month + ") " +
                "VALUES (?, ?, ?, ?) "+
                "ON DUPLICATE KEY " +
                "UPDATE energyConsumptionYear.monthEnergy" + month + " = energyConsumptionYear.monthEnergy" + month + " + ?";

        log.info("yearlyBatch() - reportYear: " + reportYear + ", sql: " + sql);

        new JdbcTemplate(dataSource).batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                HourlyConsumption temp = consumptionList.get(i);
                ps.setInt(1, temp.getDataType());
                ps.setString(2, temp.getDataId());
                ps.setString(3, String.valueOf(reportYear));
                ps.setFloat(4, temp.getValue());
                ps.setFloat(5, temp.getValue());
            }

            @Override
            public int getBatchSize() {
                return consumptionList.size();
            }
        });
    }

    private void updateSmartLights() {
        String sql = "INSERT INTO smartLightBatch(lightId, lastHrCurrentLevel) VALUES (?, ?) " +
                "ON DUPLICATE KEY " +
                "UPDATE lastHrCurrentLevel = ? ";
        log.info("updateSmartLights() - reportDate: " + reportDate + ", sql: "  + sql);

        new JdbcTemplate(dataSource).batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                Smartlight temp = smartlights.get(i);
                ps.setString(1, temp.getLightId());
                ps.setInt(2, temp.getLastHrCurrentLevel());
                ps.setInt(3, temp.getLastHrCurrentLevel());
            }

            @Override
            public int getBatchSize() {
                return smartlights.size();
            }
        });
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info("START WRITING ENERGY CONSUMPTIONS TO DB - JOB PARAMS: " + stepExecution.getJobParameters());
        inputFile = "energyBatchStep2_" + stepExecution.getJobParameters().getString("reportTime") + ".csv";
        inputFile2 = "energyBatchStep3_" + stepExecution.getJobParameters().getString("reportTime") + ".csv";
        consumptionList = CSVUtil.readHourlyConsumptionFile(inputFile);
        smartlights = CSVUtil.readSmartLightsFile(inputFile2);
        reportDate = stepExecution.getJobParameters().getString("reportDate");
        reportTime = stepExecution.getJobParameters().getString("reportTime");
        Scanner sc = new Scanner(reportTime);
        sc.useDelimiter("_");
        reportYear = sc.nextInt();
        reportMonth = sc.nextInt();
        reportDay = sc.nextInt();
        reportHour = sc.nextInt();
        sc.close();
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        boolean fileDeleted = CSVUtil.deleteFile(inputFile);
        boolean fileDeleted2 = CSVUtil.deleteFile(inputFile2);
        log.info("COMPLETED WRITING ENERGY CONSUMPTIONS TO DB - prevStepFileDeleted: " + fileDeleted + " - JOB PARAMS: " + stepExecution.getJobParameters());
        log.info("COMPLETED WRITING ENERGY CONSUMPTIONS TO DB - prevStep2FileDeleted: " + fileDeleted2 + " - JOB PARAMS: " + stepExecution.getJobParameters());
        return stepExecution.getExitStatus();
    }
}