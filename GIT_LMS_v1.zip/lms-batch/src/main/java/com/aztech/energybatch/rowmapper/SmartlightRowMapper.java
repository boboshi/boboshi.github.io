package com.aztech.energybatch.rowmapper;

import com.aztech.energybatch.listener.JobExecutionListener;
import com.aztech.energybatch.entity.Smartlight;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SmartlightRowMapper implements RowMapper<Smartlight> {
    private static final Logger log = LoggerFactory.getLogger(SmartlightRowMapper.class);

    @Override
    public Smartlight mapRow(ResultSet rs, int rowNum) throws SQLException {
        Smartlight smartlight = new Smartlight();
        smartlight.setDisplayName(rs.getString("displayName"));
        smartlight.setBlockNO(rs.getString("blockNO"));
        smartlight.setLightId(rs.getString("lightId"));
        smartlight.setFloorId(rs.getString("floorId"));
        smartlight.setBlockId(rs.getString("blockId"));
        smartlight.setCommunityId(rs.getString("communityId"));
        smartlight.setLastHrCurrentLevel(rs.getInt("lastHrCurrentLevel"));

        return smartlight;
    }
}
