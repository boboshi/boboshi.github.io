package com.aztech.energybatch.config;

import javax.sql.DataSource;

import com.aztech.energybatch.listener.JobExecutionListener;
import com.aztech.energybatch.entity.LightReading;
import com.aztech.energybatch.writer.NoOpItemWriter;
import com.aztech.energybatch.entity.Smartlight;
import com.aztech.energybatch.writer.EnergyWriter;
import com.aztech.energybatch.processor.LightReadingItemProcessor;
import com.aztech.energybatch.processor.SmartlightItemProcessor;
import com.aztech.energybatch.rowmapper.LightReadingRowMapper;
import com.aztech.energybatch.rowmapper.SmartlightRowMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.io.FileSystemResource;

import java.lang.management.ManagementFactory;
import java.util.Date;

@Configuration
@EnableBatchProcessing
@Import({ DataSourceConfig.class })
public class BatchConfig {
	private static final Logger log = LoggerFactory.getLogger(BatchConfig.class);
	@Autowired
	public JobBuilderFactory jobBuilderFactory;
	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	/**
	 * Bean for maintaining the job registry for recovery & resumption of failed jobs later (if any)
	 *
	 * @param jobRegistry JobRegistry class
	 */
	@Bean
	public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
		JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor = new JobRegistryBeanPostProcessor();
		jobRegistryBeanPostProcessor.setJobRegistry(jobRegistry);
		return jobRegistryBeanPostProcessor;
	}

	/**
	 * Bean for current level retrieval step reader
	 *
	 * @param dataSource mysqldb data source
	 * @param startTime startTime sql parameter
	 * @param endTime endTime sql parameter
	 */
	@Bean
	@StepScope
	public JdbcCursorItemReader<LightReading> lightReadingReader(@Qualifier("mysqlDataSource") final DataSource dataSource,
																 @Value("#{jobParameters['startTime']}") String startTime,
																 @Value("#{jobParameters['endTime']}") String endTime) {
		String sqlQuery = "SELECT cl.currentLevel, cl.reportDateTime, cl.lightSN, cl.blockNO FROM spsdb_sg.currentLevel cl "+
				"INNER JOIN spsdb_sg.block bl ON cl.blockNO = bl.blockNO " +
				"WHERE cl.reportDateTime >= ? AND cl.reportDateTime <= ? ORDER BY cl.blockNO, cl.lightSN , cl.reportDateTime ASC";

		JdbcCursorItemReader<LightReading> reader = new JdbcCursorItemReader<>();
		reader.setDataSource(dataSource);
		reader.setSql(sqlQuery);
		reader.setPreparedStatementSetter(ps -> {
			ps.setString(1, startTime);
			ps.setString(2, endTime);
		});
		reader.setRowMapper(new LightReadingRowMapper());
		return reader;
	}

	/**
	 * Bean for current level retrieval step processor
	 */
	@Bean
	public LightReadingItemProcessor lightReadingProcessor() {
		return new LightReadingItemProcessor();
	}

	/**
	 * Bean for current level retrieval step writer
	 *
	 * @param reportTime reportTime parameter for creation of temporary xls file (for job recovery later)
	 */
	@Bean
	@StepScope
	public FlatFileItemWriter<LightReading> lightReadingWriter(@Value("#{jobParameters['reportTime']}") String reportTime){
		FlatFileItemWriter<LightReading> writer = new FlatFileItemWriter<>();
		writer.setShouldDeleteIfEmpty(false);
		writer.setResource(new FileSystemResource("energyBatchStep1_" + reportTime +".csv"));
		writer.setLineAggregator(new DelimitedLineAggregator<LightReading>() {{
			setDelimiter(",");
			setFieldExtractor(new BeanWrapperFieldExtractor<LightReading>() {{
				setNames(new String[] { "load", "reportDateTime", "lightSN", "blockNO" });
			}});
		}});
		return writer;
	}

	/**
	 * Bean for smartlights retrieval step reader
	 *
	 * @param dataSource mysqldb data source
	 */
	@Bean
	public JdbcCursorItemReader<Smartlight> smartlightReader(@Qualifier("mysqlDataSource") final DataSource dataSource) {
		String sqlQuery = "SELECT * FROM smartLight sl INNER JOIN block b ON sl.blockId = b.blockId INNER JOIN smartLightBatch slb ON sl.lightId = slb.lightId";
		JdbcCursorItemReader<Smartlight> reader = new JdbcCursorItemReader<>();
		reader.setDataSource(dataSource);
		reader.setSql(sqlQuery);
		reader.setRowMapper(new SmartlightRowMapper());
		return reader;
	}

	/**
	 * Bean for smartlights retrieval step processor
	 */
	@Bean
	public SmartlightItemProcessor smartlightProcessor() {
		return new SmartlightItemProcessor();
	}

	/**
	 * Bean for smartlights retrieval step writer
	 *
	 * @param reportTime reportTime parameter for creation of temporary xls file (for job recovery later)
	 */
	@Bean
	@StepScope
	public FlatFileItemWriter<Smartlight> smartlightWriter(@Value("#{jobParameters['reportTime']}") String reportTime){
		FlatFileItemWriter<Smartlight> writer = new FlatFileItemWriter<>();
		writer.setShouldDeleteIfEmpty(true);
		writer.setResource(new FileSystemResource("smartlights" + reportTime +".csv"));
		writer.setLineAggregator(new DelimitedLineAggregator<Smartlight>() {{
			setDelimiter(",");
			setFieldExtractor(new BeanWrapperFieldExtractor<Smartlight>() {{
				setNames(new String[] { "displayName", "blockNO", "lastHrCurrentLevel", "lightId", "floorId", "blockId", "communityId" });
			}});
		}});

		return writer;
	}

	/**
	 * Bean for a no op writer
	 */
	@Bean
	public NoOpItemWriter noOpWriter() {
		return new NoOpItemWriter();
	}

	/**
	 * Bean for current level retrieval step
	 *
	 * @param reader the earlier reader bean
	 * @param processor the earlier processor bean
	 * @param writer the earlier writer bean
	 */
	@Bean
	public Step step1(JdbcCursorItemReader<LightReading> reader, LightReadingItemProcessor processor, FlatFileItemWriter<LightReading> writer) {
		return stepBuilderFactory.get("step1")
				.<LightReading, LightReading> chunk(100)
				.reader(reader)
				.processor(processor)
				.writer(writer)
				.build();
	}

	/**
	 * Bean for smartlight retrieval step
	 *
	 * @param reader the earlier reader bean
	 * @param processor the earlier processor bean
	 * @param writer the earlier writer bean
	 */
	@Bean
	public Step step2(JdbcCursorItemReader<Smartlight> reader, SmartlightItemProcessor processor, NoOpItemWriter writer) {
		return stepBuilderFactory.get("step2")
				.<Smartlight, Smartlight> chunk(100)
				.reader(reader)
				.processor(processor)
				.writer(writer)
				.build();
	}


	/**
	 * Bean for energy consumption writer tasklet
	 */
	@Bean
	public EnergyWriter energyWriter() {
		return new EnergyWriter();
	}

	/**
	 * Bean for energy consumption writer tasklet step
	 */
	@Bean
	public Step step3() {
		return stepBuilderFactory
				.get("step3")
				.tasklet(energyWriter())
				.build();
	}

	/**
	 * Bean for energy consumption job
	 *
	 * @param listener listener class for post-job handling
	 * @param step1 current level retrieval step
	 * @param step2 smartlight retrieval step
	 * @param step3 energywriter step
	 */
	@Bean
	public Job batchJob(JobExecutionListener listener, Step step1, Step step2, Step step3) {
		return jobBuilderFactory.get("batchJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.start(step1)
				.next(step2)
				.next(step3)
				.build();
	}

	/**
	 * Bean for job resumptions
	 *
	 * @param jobOperator JobOperator class for resuming the specified job (via job id)
	 * @param jobRepository JobRepository class for repo of all jobs (spring batch managed jobs db)
	 * @param jobExplorer JobExplorer class for iterating the jobs
	 */
	@Bean
	public ApplicationListener<ContextRefreshedEvent> resumeJobsListener(JobOperator jobOperator, JobRepository jobRepository, JobExplorer jobExplorer) {
		// restart jobs that failed due to
		return event -> {
			Date jvmStartTime = new Date(ManagementFactory.getRuntimeMXBean().getStartTime());

			// for each job
			for (String jobName : jobExplorer.getJobNames()) {
				// get latest job instance (max 5)
				for (JobInstance instance : jobExplorer.getJobInstances(jobName, 0, 5)) {
					// for each of the executions
					for (JobExecution execution : jobExplorer.getJobExecutions(instance)) {
						if (execution.getStatus().equals(BatchStatus.STARTED) && execution.getCreateTime().before(jvmStartTime)) {
							// this job is broken and must be restarted
							log.info("Resuming job: " + execution.getJobId() + " with parameters: " + execution.getJobParameters());

							execution.setEndTime(new Date());
							execution.setStatus(BatchStatus.FAILED);
							execution.setExitStatus(ExitStatus.FAILED);

							// this job is broken and must be restarted at the step
							for (StepExecution se : execution.getStepExecutions()) {
								if (se.getStatus().equals(BatchStatus.STARTED)) {
									se.setEndTime(new Date());
									se.setStatus(BatchStatus.FAILED);
									se.setExitStatus(ExitStatus.FAILED);
									jobRepository.update(se);
									log.info("Resuming job: " + execution.getJobId() + " with parameters: " + execution.getJobParameters() + " at step: " + se.getStepName());
								}
							}

							jobRepository.update(execution);
							try {
								jobOperator.restart(execution.getId());
							} catch (JobExecutionException e) {
								log.warn("Couldn't resume job execution {}", execution, e);
							}
						}
					}
				}
			}
		};
	}
}