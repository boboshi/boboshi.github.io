package com.aztech.energybatch.entity;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.aztech.energybatch.util.ConstantValues;

/**
 * Represents a smartlight object
 */
public class Smartlight implements Cloneable {
	private String lightId = "";
	private String lightSN = "";
	private String displayName = "";
	private String communityId = "";
	private String blockId = "";
	private String floorId = "";
	private String userId = "";
	private String lightBirthday = ""; 
	private int lightType = 1;						//1-SPS100,2-SPS210
	private String firmware = "";
	private int isOnline = 255;
	private Date reportDateTime;
	private Date serverDateTime;
	
	//Config
	private String motionSensing = "Enable";
	private int motionSensitivity = 2;				//1-High,2-Medium-High,3-Medium,4-Medium-Low,5-Low
	private int dimLevel = 20;						//20 of 100%
	private int motionLevel = 10;					//10 of 10 (need to x 10, done in get)
	private int brightLevel = 10;					//10 of 10 (need to x 10, done in get)
	private int holdTime = 15;						//seconds
	private int lightIntensity = 3;					//always 3-Fast		

	private String scheduling = "Enable";
	private String photosensorGroup = "07001859";	//hhmmhhmm
	private String brightGroup = "19002359";		//hhmmhhmm
	
	//Photosensor config
	private String photoSensing = "Disable";		
	private int photoUpperThreshold = 150;
	private int photoLowerThreshold = 50;
	
	private String clockSync = "Enable";	
	
	private String ratedPower = "400";				//Unused for now		
	private String ratedVoltage = "7";				//watts
	private String coordinates = "";				//Future use
		
	private String blockNO = "";
	private String floorNO = "";
	private String motionSensitivityString = "Medium-High";
	private String lightIntensityString = "Fast";
	private String photosensorGroupString = "07001859";
	private String brightGroupString = "19002359";
	private String motionGroupString = "";
	private String holdTimeString = "15";

	private int lastHrCurrentLevel = 0;

	public String getLightId() {
		return lightId;
	}
	public void setLightId(String lightId) {
		this.lightId = lightId;
	}
	public String getLightSN() {
		return lightSN;
	}
	public void setLightSN(String lightSN) {
		this.lightSN = lightSN;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getCommunityId() {
		return communityId;
	}
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
	public String getBlockId() {
		return blockId;
	}
	public void setBlockId(String blockId) {
		this.blockId = blockId;
	}
	public String getFloorId() {
		return floorId;
	}
	public void setFloorId(String floorId) {
		this.floorId = floorId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLightBirthday() {
		return lightBirthday;
	}
	public void setLightBirthday(String lightBirthday) {
		this.lightBirthday = lightBirthday;
	}
	public int getLightType() {
		return lightType;
	}
	public void setLightType(int lightType) {
		this.lightType = lightType;
	}
	public String getFirmware() {
		return firmware;
	}
	public void setFirmware(String firmware) {
		this.firmware = firmware;
	}
	public int getIsOnline() {
		return isOnline;
	}
	public void setIsOnline(int isOnline) {
		this.isOnline = isOnline;
	}
	public Date getReportDateTime() {
		return reportDateTime;
	}
	public void setReportDateTime(Date reportDateTime) {
		this.reportDateTime = reportDateTime;
	}
	public Date getServerDateTime() {
		return serverDateTime;
	}
	public void setServerDateTime(Date serverDateTime) {
		this.serverDateTime = serverDateTime;
	}
	public String getMotionSensing() {
		return motionSensing;
	}
	public void setMotionSensing(String motionSensing) {
		this.motionSensing = motionSensing;
	}
	public int getMotionSensitivity() {
		return motionSensitivity;
	}
	public void setMotionSensitivity(int motionSensitivity) {
		this.motionSensitivity = motionSensitivity;
	}
	public int getDimLevel() {
		return dimLevel;
	}
	public void setDimLevel(int dimLevel) {
		this.dimLevel = dimLevel;
	}
	public int getMotionLevel() {
		return motionLevel;
	}
	public void setMotionLevel(int motionLevel) {
		this.motionLevel = motionLevel;
	}
	public int getBrightLevel() {
		return brightLevel;
	}
	public void setBrightLevel(int brightLevel) {
		this.brightLevel = brightLevel;
	}
	public int getHoldTime() {
		return holdTime;
	}
	public void setHoldTime(int holdTime) {
		this.holdTime = holdTime;
	}
	public int getLightIntensity() {
		return lightIntensity;
	}
	public void setLightIntensity(int lightIntensity) {
		this.lightIntensity = lightIntensity;
	}
	public String getScheduling() {
		return scheduling;
	}
	public void setScheduling(String scheduling) {
		this.scheduling = scheduling;
	}
	public String getPhotosensorGroup() {
		return photosensorGroup;
	}
	public void setPhotosensorGroup(String photosensorGroup) {
		this.photosensorGroup = photosensorGroup;
	}
	public String getBrightGroup() {
		return brightGroup;
	}
	public void setBrightGroup(String brightGroup) {
		this.brightGroup = brightGroup;
	}
	public String getPhotoSensing() {
		return photoSensing;
	}
	public void setPhotoSensing(String photoSensing) {
		this.photoSensing = photoSensing;
	}
	public int getPhotoUpperThreshold() {
		return photoUpperThreshold;
	}
	public void setPhotoUpperThreshold(int photoUpperThreshold) {
		this.photoUpperThreshold = photoUpperThreshold;
	}
	public int getPhotoLowerThreshold() {
		return photoLowerThreshold;
	}
	public void setPhotoLowerThreshold(int photoLowerThreshold) {
		this.photoLowerThreshold = photoLowerThreshold;
	}
	public String getClockSync() {
		return clockSync;
	}
	public void setClockSync(String clockSync) {
		this.clockSync = clockSync;
	}
	public String getRatedPower() {
		return ratedPower;
	}
	public void setRatedPower(String ratedPower) {
		this.ratedPower = ratedPower;
	}
	public String getRatedVoltage() {
		return ratedVoltage;
	}
	public void setRatedVoltage(String ratedVoltage) {
		this.ratedVoltage = ratedVoltage;
	}
	public String getCoordinates() {
		return coordinates;
	}
	public void setCoordinates(String coordinates) {
		this.coordinates = coordinates;
	}
	public String getBlockNO() {
		return blockNO;
	}
	public void setBlockNO(String blockNO) {
		this.blockNO = blockNO;
	}
	public String getFloorNO() {
		return floorNO;
	}
	public void setFloorNO(String floorNO) {
		this.floorNO = floorNO;
	}
	public String getLightIntensityString() {
		if (lightIntensity == 1) {
			lightIntensityString = ConstantValues.LightIntensityString.ONE;
		} else if (lightIntensity == 2) {
			lightIntensityString = ConstantValues.LightIntensityString.TWO;
		} else if (lightIntensity == 3) {
			lightIntensityString = ConstantValues.LightIntensityString.THREE;
		}
		return lightIntensityString;
	}
	public String getMotionSensitivityString() {
		if (motionSensitivity == 1) {
			motionSensitivityString = ConstantValues.MotionSensitivityString.ONE;
		} else if (motionSensitivity == 2) {
			motionSensitivityString = ConstantValues.MotionSensitivityString.TWO;
		} else if (motionSensitivity == 3) {
			motionSensitivityString = ConstantValues.MotionSensitivityString.THREE;
		} else if (motionSensitivity == 4) {
			motionSensitivityString = ConstantValues.MotionSensitivityString.FOUR;
		} else if (motionSensitivity == 5) {
			motionSensitivityString = ConstantValues.MotionSensitivityString.FIVE;
		}
		return motionSensitivityString;
	}
	public String getPhotosensorGroupString() {
		photosensorGroupString = photosensorGroup.substring(0,4) + "hrs - " + photosensorGroup.substring(4,8) + "hrs";
		if (photosensorGroup.equals("00000000")) {
			photosensorGroupString ="Disabled";
		}
		return photosensorGroupString;
	}
	public String getBrightGroupString() {
		brightGroupString = brightGroup.substring(0,4) + "hrs - " + brightGroup.substring(4,8) + "hrs";
		if (brightGroup.equals("00000000")) {
			brightGroupString ="Disabled";
		}
		return brightGroupString;
	}
	public String getMotionGroupString() {
		motionGroupString = "";
		boolean photoGroupDisabled = false, brightGroupDisabled = false;

		if (photosensorGroup.equals("00000000")) {
			photoGroupDisabled = true;
		}
		if (brightGroup.equals("00000000")) {
			brightGroupDisabled = true;
		}
		
		DateTimeFormatter f2 = DateTimeFormatter.ofPattern("HHmm");

		//Photosensor group disabled
		if (photoGroupDisabled && !brightGroupDisabled) {
			LocalTime brightStart = LocalTime.parse(brightGroup.substring(0,4), f2);
			LocalTime motionEnd = brightStart.plusMinutes(-1);
			
			LocalTime brightEnd = LocalTime.parse(brightGroup.substring(4,8), f2);
			LocalTime motionStart = brightEnd.plusMinutes(1);			

			motionGroupString = motionStart + "hrs - " + motionEnd + "hrs";
		} else if (!photoGroupDisabled && brightGroupDisabled) {			
			LocalTime photoStart = LocalTime.parse(photosensorGroup.substring(0,4), f2);
			LocalTime motionEnd = photoStart.plusMinutes(-1);
			
			LocalTime photoEnd = LocalTime.parse(photosensorGroup.substring(4,8), f2);
			LocalTime motionStart = photoEnd.plusMinutes(1);			

			motionGroupString = motionStart + "hrs - " + motionEnd + "hrs";
		} else if (photoGroupDisabled && brightGroupDisabled) {
			motionGroupString = "0000hrs - 2359hrs";
		} else if (!photoGroupDisabled && !brightGroupDisabled) {
			LocalTime photoStart = LocalTime.parse(photosensorGroup.substring(0,4), f2);		
			LocalTime photoEnd = LocalTime.parse(photosensorGroup.substring(4,8), f2);
			
			LocalTime brightStart = LocalTime.parse(brightGroup.substring(0,4), f2);
			LocalTime brightEnd = LocalTime.parse(brightGroup.substring(4,8), f2);

			if (photoEnd.plusMinutes(1) != brightStart) {
				LocalTime motionStart = photoEnd.plusMinutes(1);			
				LocalTime motionEnd = brightStart.plusMinutes(-1);
								
				motionGroupString = motionStart + "hrs - " + motionEnd + "hrs &<br>";
	 		}
			
			if (brightEnd.plusMinutes(1) != photoStart) {
				LocalTime motionStart = brightEnd.plusMinutes(1);			
				LocalTime motionEnd = photoStart.plusMinutes(-1);	
								
				motionGroupString += motionStart + "hrs - " + motionEnd + "hrs";
	 		}
			
			if (motionGroupString.isEmpty()) {
				motionGroupString = "Disabled";
			}
			
		}
		
		return motionGroupString.replaceAll(":", "");
	}
	public String getHoldTimeString() {
		if (holdTime >= 128) {
			holdTimeString = (holdTime-128) + "mins";
		} else {
			holdTimeString = holdTime + "s";
		}
		return holdTimeString;
	}

	public int getLastHrCurrentLevel() {
		if (lastHrCurrentLevel < 0) {
			return 0;
		} else if (lastHrCurrentLevel > 100) {
			return 100;
		}

		return lastHrCurrentLevel;
	}

	public void setLastHrCurrentLevel(int lastHrCurrentLevel) {
		this.lastHrCurrentLevel = lastHrCurrentLevel;
	}

	@Override
	public String toString() {
		return "Smartlight{" +
				"lightId='" + lightId + '\'' +
				", lightSN='" + lightSN + '\'' +
				", displayName='" + displayName + '\'' +
				", communityId='" + communityId + '\'' +
				", blockId='" + blockId + '\'' +
				", floorId='" + floorId + '\'' +
				", userId='" + userId + '\'' +
				", lightBirthday='" + lightBirthday + '\'' +
				", lightType=" + lightType +
				", firmware='" + firmware + '\'' +
				", isOnline=" + isOnline +
				", reportDateTime=" + reportDateTime +
				", serverDateTime=" + serverDateTime +
				", motionSensing='" + motionSensing + '\'' +
				", motionSensitivity=" + motionSensitivity +
				", dimLevel=" + dimLevel +
				", motionLevel=" + motionLevel +
				", brightLevel=" + brightLevel +
				", holdTime=" + holdTime +
				", lightIntensity=" + lightIntensity +
				", scheduling='" + scheduling + '\'' +
				", photosensorGroup='" + photosensorGroup + '\'' +
				", brightGroup='" + brightGroup + '\'' +
				", photoSensing='" + photoSensing + '\'' +
				", photoUpperThreshold=" + photoUpperThreshold +
				", photoLowerThreshold=" + photoLowerThreshold +
				", clockSync='" + clockSync + '\'' +
				", ratedPower='" + ratedPower + '\'' +
				", ratedVoltage='" + ratedVoltage + '\'' +
				", coordinates='" + coordinates + '\'' +
				", blockNO='" + blockNO + '\'' +
				", floorNO='" + floorNO + '\'' +
				", motionSensitivityString='" + motionSensitivityString + '\'' +
				", lightIntensityString='" + lightIntensityString + '\'' +
				", photosensorGroupString='" + photosensorGroupString + '\'' +
				", brightGroupString='" + brightGroupString + '\'' +
				", motionGroupString='" + motionGroupString + '\'' +
				", holdTimeString='" + holdTimeString + '\'' +
				", lastHrCurrentLevel=" + lastHrCurrentLevel +
				'}';
	}

	public String toCustomString() {
		return "Smartlight [lightId=" + lightId + ", displayName=" + displayName + ", communityId=" + communityId + ", blockId=" + blockId + ", floorId=" + floorId + ", lastHrCurrentLevel=" + lastHrCurrentLevel + ", blockNO=" + blockNO + "]";
	}

	public String toCsvString() {
		return lightId + "," + lastHrCurrentLevel + "\n";
	}
}