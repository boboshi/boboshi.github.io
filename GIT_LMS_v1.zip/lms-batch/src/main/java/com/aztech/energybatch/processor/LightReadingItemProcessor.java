package com.aztech.energybatch.processor;

import com.aztech.energybatch.entity.LightReading;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

public class LightReadingItemProcessor implements ItemProcessor<LightReading, LightReading>, StepExecutionListener {
	private static final Logger log = LoggerFactory.getLogger(LightReadingItemProcessor.class);

	@Override
	public LightReading process(final LightReading lightReading) {
		return lightReading;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.info("START GETTING LIGHT READINGS - JOB PARAMS: " + stepExecution.getJobParameters());
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.info("COMPLETED GETTING LIGHT READINGS - JOB PARAMS: " + stepExecution.getJobParameters());
		return stepExecution.getExitStatus();
	}
}