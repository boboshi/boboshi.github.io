package com.aztech.energybatch.entity;

/**
 * Represents a current level reading object
 */
public class LightReading {
	private int load;
	private String reportDateTime;
	private String serverDateTime = "";
	private String lightSN;
	private String blockNO;

	public LightReading(int load, String reportDateTime, String lightSN, String blockNO) {
		super();
		this.load = load;
		this.reportDateTime = reportDateTime;
		this.lightSN = lightSN;
		this.blockNO = blockNO;
	}
	
	public int getLoad() {
		return load;
	}
	public void setLoad(int load) {
		this.load = load;
	}
	public String getReportDateTime() {
		return reportDateTime;
	}
	public void setReportDateTime(String reportDateTime) {
		this.reportDateTime = reportDateTime;
	}
	public String getServerDateTime() {
		return serverDateTime;
	}
	public void setServerDateTime(String serverDateTime) {
		this.serverDateTime = serverDateTime;
	}
	public String getLightSN() {
		return lightSN;
	}
	public void setLightSN(String lightSN) {
		this.lightSN = lightSN;
	}
	public String getBlockNO() {
		return blockNO;
	}
	public void setBlockNO(String blockNO) {
		this.blockNO = blockNO;
	}

	@Override
	public String toString() {
		return "LightReading{" +
				"load=" + load +
				", reportDateTime='" + reportDateTime + '\'' +
				", serverDateTime='" + serverDateTime + '\'' +
				", lightSN='" + lightSN + '\'' +
				", blockNO='" + blockNO + '\'' +
				'}';
	}
}
