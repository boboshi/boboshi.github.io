package com.aztech.energybatch.entity;

/**
 * Represents an hourly consumption object
 */
public class HourlyConsumption {
	private int dataType;
	private String dataId;
	private Float value;

    public HourlyConsumption(int dataType, String dataId, Float value) {
        this.dataType = dataType;
        this.dataId = dataId;
        this.value = value;
    }

    public int getDataType() {
        return dataType;
    }
    public void setDataType(int dataType) {
        this.dataType = dataType;
    }
    public String getDataId() {
        return dataId;
    }
    public void setDataId(String dataId) {
        this.dataId = dataId;
    }
    public Float getValue() {
        return value;
    }
    public void setValue(Float value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "HourlyConsumption{" +
                "dataType=" + dataType +
                ", dataId='" + dataId + '\'' +
                ", value=" + value +
                '}';
    }

    public String toCsvString() {
        return dataType + "," + dataId + "," + value + "\n";
    }
}