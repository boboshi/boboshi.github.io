package com.aztech.energybatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@EnableScheduling
@SpringBootApplication
public class BatchProcessingApplication {
	private static final Logger log = LoggerFactory.getLogger(BatchProcessingApplication.class);
	public static final DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	public static String startTime;
	public static String endTime;
	public static String reportDate;
	public static String reportTime;

	@Value("${app.name}")
	private String appName;

	@Autowired
	JobLauncher jobLauncher;
	@Autowired
	Job job;

	public static void main(String[] args) {
		SpringApplication.run(BatchProcessingApplication.class, args);
	}

	/**
	 * Schedules a job every hour at xx:00:05 that calculates energy consumption for the previous hour.
	 * If xx = 12 (12pm), calculation is done for 11:00:00 - 11:59:59
	 */
	@Scheduled(cron = "0 0/15 * * * *")
	public void perform() {
		log.info("Application (" + appName + ") job started at: " + new Date());
		initTime();
		try {
			JobParametersBuilder jobBuilder= new JobParametersBuilder();
			jobBuilder.addString("startTime", startTime);
			jobBuilder.addString("endTime", endTime);
			jobBuilder.addString("reportTime", reportTime);
			jobBuilder.addString("reportDate", reportDate);
			JobParameters jobParameters = jobBuilder.toJobParameters();
			JobExecution execution = jobLauncher.run(job, jobParameters);
			log.info("Job completed at:" + new Date());
			log.info("Job completion status: " + execution.getStatus());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initializes the required unique parameters for each hourly job
	 * startTime - start time parameter for sql query
	 * endTime - end time parameter for sql query
	 * reportDate - date parameter for sql query
	 * reportTime - for logging purposes
	 *
	 * startTime, endTime, reportDate are used for querying the current level records for the energy consumption calculation
	 * Etc. Grab all records from reportDate startTime - reportDate endTime (2020-20-20 20:00:00 to 20-20-20 20:59:59)
	 */
	public void initTime() {
		Calendar startHourTime = Calendar.getInstance();
		startHourTime.add(Calendar.HOUR, -1);
		startHourTime.set(Calendar.MINUTE, 0);
		startHourTime.set(Calendar.SECOND, 0);
		Calendar endHourTime = Calendar.getInstance();
		endHourTime.add(Calendar.HOUR, -1);
		endHourTime.set(Calendar.MINUTE, 59);
		endHourTime.set(Calendar.SECOND, 59);
		startTime = format.format(startHourTime.getTime());
		endTime = format.format(endHourTime.getTime());

		int hour = endHourTime.get(Calendar.HOUR_OF_DAY);
		int day = endHourTime.get(Calendar.DAY_OF_MONTH);
		int month = endHourTime.get(Calendar.MONTH) + 1;
		int year = endHourTime.get(Calendar.YEAR);
		reportDate = year + "-" + month + "-" + day;
		reportTime = year + "_" + month + "_" + day + "_" + hour;
	}
}
