#!/usr/bin/env sh

set -e

./wait-for-it.sh $DB_SERVICE -s -t 120 -- java -jar lms-energybatch.jar
