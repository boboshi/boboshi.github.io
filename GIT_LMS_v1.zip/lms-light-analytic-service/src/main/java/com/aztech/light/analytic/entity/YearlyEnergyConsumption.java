package com.aztech.light.analytic.entity;

import com.aztech.light.analytic.model.LightScopeCategory;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Converter;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "energyConsumptionYear")
public class YearlyEnergyConsumption {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "energyConsumptionYearId")
    private Long id;
    private LightScopeCategory dataType;
    private String dataId;
    private int reportYear;
    private float monthEnergy1;
    private float monthEnergy2;
    private float monthEnergy3;
    private float monthEnergy4;
    private float monthEnergy5;
    private float monthEnergy6;
    private float monthEnergy7;
    private float monthEnergy8;
    private float monthEnergy9;
    private float monthEnergy10;
    private float monthEnergy11;
    private float monthEnergy12;
}
