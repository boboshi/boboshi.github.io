package com.aztech.light.analytic.exception;

public class MotionEventCountNotFoundException extends RuntimeException {
    public MotionEventCountNotFoundException(int day, int month, int year) {
        super(buildMessage(day, month, year));
    }

    public MotionEventCountNotFoundException(int month, int year) {
        super(buildMessage(month, year));
    }

    public MotionEventCountNotFoundException(int year) {
        super(buildMessage(year));
    }

    private static String buildMessage(int day, int month, int year) {
        return String.format("Records for %d-%d-%d cannot be found", year, month, day);
    }

    private static String buildMessage(int month, int year) {
        return String.format("Records for %d-%d cannot be found", year, month);
    }

    private static String buildMessage(int year) {
        return String.format("Records for %d cannot be found", year);
    }
}
