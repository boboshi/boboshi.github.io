package com.aztech.light.analytic.configuration;

import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.model.DailyMotionDetectionCount;
import com.aztech.light.analytic.model.MonthlyMotionDetectionCount;
import com.aztech.light.analytic.model.SerializableDailyEnergyConsumption;
import com.aztech.light.analytic.model.YearlyMotionDetectionCount;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.hibernate.HikariConfigurationUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.connection.ReactiveRedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.ReactiveRedisOperations;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriBuilderFactory;

import javax.sql.DataSource;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

@Configuration
public class LightAnalyticServiceConfiguration {
    @Value("${redis.host}")
    private String redisHost;

    @Bean
    @Primary
    public ReactiveRedisConnectionFactory lettuceConnectionFactory() {
        return new LettuceConnectionFactory(new RedisStandaloneConfiguration(redisHost));
    }

    @Bean
    public ReactiveRedisOperations<String, SerializableDailyEnergyConsumption> dailyEnergyOperations(ReactiveRedisConnectionFactory factory) {
        Jackson2JsonRedisSerializer<SerializableDailyEnergyConsumption> serializer = new Jackson2JsonRedisSerializer<>(SerializableDailyEnergyConsumption.class);

        final RedisSerializationContext.RedisSerializationContextBuilder<String, SerializableDailyEnergyConsumption> builder =
                RedisSerializationContext.newSerializationContext(new StringRedisSerializer());

        final RedisSerializationContext<String, SerializableDailyEnergyConsumption> context = builder.value(serializer).build();

        return new ReactiveRedisTemplate<>(factory, context);
    }

    @Bean
    public ReactiveRedisOperations<String, MonthlyEnergyConsumption> monthlyEnergyOperations(ReactiveRedisConnectionFactory factory) {
        Jackson2JsonRedisSerializer<MonthlyEnergyConsumption> serializer = new Jackson2JsonRedisSerializer<>(MonthlyEnergyConsumption.class);

        final RedisSerializationContext.RedisSerializationContextBuilder<String, MonthlyEnergyConsumption> builder =
                RedisSerializationContext.newSerializationContext(new StringRedisSerializer());

        final RedisSerializationContext<String, MonthlyEnergyConsumption> context = builder.value(serializer).build();

        return new ReactiveRedisTemplate<>(factory, context);
    }

    @Bean
    public ReactiveRedisOperations<String, YearlyEnergyConsumption> yearlyEnergyOperations(ReactiveRedisConnectionFactory factory) {
        Jackson2JsonRedisSerializer<YearlyEnergyConsumption> serializer = new Jackson2JsonRedisSerializer<>(YearlyEnergyConsumption.class);

        final RedisSerializationContext.RedisSerializationContextBuilder<String, YearlyEnergyConsumption> builder =
                RedisSerializationContext.newSerializationContext(new StringRedisSerializer());

        final RedisSerializationContext<String, YearlyEnergyConsumption> context = builder.value(serializer).build();

        return new ReactiveRedisTemplate<>(factory, context);
    }

    @Bean
    public ReactiveRedisOperations<String, DailyMotionDetectionCount> dailyMotionOperations(ReactiveRedisConnectionFactory factory) {
        Jackson2JsonRedisSerializer<DailyMotionDetectionCount> serializer = new Jackson2JsonRedisSerializer<>(DailyMotionDetectionCount.class);

        final RedisSerializationContext.RedisSerializationContextBuilder<String, DailyMotionDetectionCount> builder =
                RedisSerializationContext.newSerializationContext(new StringRedisSerializer());

        final RedisSerializationContext<String, DailyMotionDetectionCount> context = builder.value(serializer).build();

        return new ReactiveRedisTemplate<>(factory, context);
    }

    @Bean
    public ReactiveRedisOperations<String, MonthlyMotionDetectionCount> monthlyMotionOperations(ReactiveRedisConnectionFactory factory) {
        Jackson2JsonRedisSerializer<MonthlyMotionDetectionCount> serializer = new Jackson2JsonRedisSerializer<>(MonthlyMotionDetectionCount.class);

        final RedisSerializationContext.RedisSerializationContextBuilder<String, MonthlyMotionDetectionCount> builder =
                RedisSerializationContext.newSerializationContext(new StringRedisSerializer());

        final RedisSerializationContext<String, MonthlyMotionDetectionCount> context = builder.value(serializer).build();

        return new ReactiveRedisTemplate<>(factory, context);
    }

    @Bean
    public ReactiveRedisOperations<String, YearlyMotionDetectionCount> yearlyMotionOperations(ReactiveRedisConnectionFactory factory) {
        Jackson2JsonRedisSerializer<YearlyMotionDetectionCount> serializer = new Jackson2JsonRedisSerializer<>(YearlyMotionDetectionCount.class);

        final RedisSerializationContext.RedisSerializationContextBuilder<String, YearlyMotionDetectionCount> builder =
                RedisSerializationContext.newSerializationContext(new StringRedisSerializer());

        final RedisSerializationContext<String, YearlyMotionDetectionCount> context = builder.value(serializer).build();

        return new ReactiveRedisTemplate<>(factory, context);
    }

    @Bean
    public DataSource dataSource(Environment environment) {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(prepareJdbcUri(environment));
        hikariConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
        hikariConfig.setUsername(loadUsername());
        hikariConfig.setPassword(loadPassword());
        return new HikariDataSource(hikariConfig);
    }

    private String prepareJdbcUri(Environment environment) {
        String dbHost = environment.getProperty("DB_HOST", "localhost");
        String dbPort = environment.getProperty("DB_PORT", "3306");

        UriBuilderFactory builderFactory = new DefaultUriBuilderFactory();
        return new StringBuilder()
                .append("jdbc:")
                .append(builderFactory.builder()
                        .scheme("mysql")
                        .host(dbHost)
                        .port(dbPort)
                        .path("spsdb_sg")
                        .queryParam("useSSL", false)
                        .queryParam("serverTimezone", "Asia/Singapore")
                        .queryParam("useLegacyDatetimeCode", false)
                        .build().toString()).toString();
    }

    private String loadUsername() {
        return loadSecret("mysql_username");
    }

    private String loadPassword() {
        return loadSecret("mysql_password");
    }

    private String loadSecret(String name) {
        String secret = "";
        String secretPath = String.format("/run/secrets/%s", name);
        File secretFile = new File(secretPath);

        if (secretFile.exists()) {
            try (FileReader fileReader = new FileReader(secretFile)) {
                try (BufferedReader reader = new BufferedReader(fileReader)) {
                    secret = reader.readLine();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return secret;
    }

}
