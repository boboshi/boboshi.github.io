package com.aztech.light.analytic.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(force = true)
public class DailyMotionDetectionCount {
    private long hourPIRDetectNumber1;
    private long hourPIRDetectNumber2;
    private long hourPIRDetectNumber3;
    private long hourPIRDetectNumber4;
    private long hourPIRDetectNumber5;
    private long hourPIRDetectNumber6;
    private long hourPIRDetectNumber7;
    private long hourPIRDetectNumber8;
    private long hourPIRDetectNumber9;
    private long hourPIRDetectNumber10;
    private long hourPIRDetectNumber11;
    private long hourPIRDetectNumber12;
    private long hourPIRDetectNumber13;
    private long hourPIRDetectNumber14;
    private long hourPIRDetectNumber15;
    private long hourPIRDetectNumber16;
    private long hourPIRDetectNumber17;
    private long hourPIRDetectNumber18;
    private long hourPIRDetectNumber19;
    private long hourPIRDetectNumber20;
    private long hourPIRDetectNumber21;
    private long hourPIRDetectNumber22;
    private long hourPIRDetectNumber23;
    private long hourPIRDetectNumber24;
}
