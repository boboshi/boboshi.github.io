package com.aztech.light.analytic.exception;

public class EnergyConsumptionNotFoundException extends RuntimeException {
    public EnergyConsumptionNotFoundException(String id, int month, int year) {
        super(buildMessage(id, month, year));
    }
    public EnergyConsumptionNotFoundException(String id, int year) {
        super(buildMessage(id, year));
    }
    public EnergyConsumptionNotFoundException(String id, int day, int month, int year) { super(buildMessage(id, day, month, year)); }

    private static String buildMessage(String id, int month, int year) {
        StringBuilder builder = new StringBuilder();
        return builder
                .append("[id: ").append(id).append(", ")
                .append("month: ").append(month).append(", ")
                .append("year: ").append(year).append("] cannot be found")
                .toString();
    }

    private static String buildMessage(String id, int year) {
        StringBuilder builder = new StringBuilder();
        return builder
                .append("[id: ").append(id).append(", ")
                .append("year: ").append(year).append("] cannot be found")
                .toString();
    }

    private static String buildMessage(String id, int day, int month, int year) {
        StringBuilder builder = new StringBuilder();
        return builder
                .append("[id: ").append(id).append(", ")
                .append("date: ").append(year).append("-").append(month).append("-").append(day).append("] cannot be found")
                .toString();
    }
}
