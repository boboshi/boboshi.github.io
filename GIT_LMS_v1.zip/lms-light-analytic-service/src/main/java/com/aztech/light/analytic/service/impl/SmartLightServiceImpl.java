package com.aztech.light.analytic.service.impl;

import com.aztech.light.analytic.entity.SmartLight;
import com.aztech.light.analytic.repository.SmartLightRepository;
import com.aztech.light.analytic.service.SmartLightService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SmartLightServiceImpl implements SmartLightService {
    private final SmartLightRepository smartLightRepository;

    public SmartLightServiceImpl(SmartLightRepository smartLightRepository) {
        this.smartLightRepository = smartLightRepository;
    }

    @Override
    public List<SmartLight> getSmartLight(long floorId) {
        return smartLightRepository.findByFloorId(floorId);
    }
}
