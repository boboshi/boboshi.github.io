package com.aztech.light.analytic.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.sql.Date;
import java.time.Instant;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler({EnergyConsumptionNotFoundException.class, MotionEventCountNotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public LightAnalyticServiceError energyConsumptionNotFoundExceptionHandler(Exception e) {
        return new LightAnalyticServiceError(e.getMessage(), Date.from(Instant.now()));
    }
}
