package com.aztech.light.analytic.service;

import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.model.DailyMotionDetectionCount;
import com.aztech.light.analytic.model.MonthlyMotionDetectionCount;
import com.aztech.light.analytic.model.YearlyMotionDetectionCount;

import java.util.Optional;

public interface LightAnalyticCacheService {
    Optional<DailyEnergyConsumption> getLightEnergyConsumption(String lightId, int day, int month, int year);
    void putLightEnergyConsumption(String lightId, int day, int month, int year, DailyEnergyConsumption lightEnergyConsumption);

    Optional<MonthlyEnergyConsumption> getLightEnergyConsumption(String lightId, int month, int year);
    void putLightEnergyConsumption(String lightId, int month, int year, MonthlyEnergyConsumption lightEnergyConsumption);

    Optional<YearlyEnergyConsumption> getLightEnergyConsumption(String lightId, int year);
    void putLightEnergyConsumption(String lightId, int year, YearlyEnergyConsumption lightEnergyConsumption);

    Optional<DailyEnergyConsumption> getFloorEnergyConsumption(String floorId, int day, int month, int year);
    void putFloorEnergyConsumption(String floorId, int day, int month, int year, DailyEnergyConsumption lightEnergyConsumption);

    Optional<MonthlyEnergyConsumption> getFloorEnergyConsumption(String floorId, int month, int year);
    void putFloorEnergyConsumption(String floorId, int month, int year, MonthlyEnergyConsumption floorEnergyConsumption);

    Optional<YearlyEnergyConsumption> getFloorEnergyConsumption(String floorId, int year);
    void putFloorEnergyConsumption(String floorId, int year, YearlyEnergyConsumption floorEnergyConsumption);

    Optional<DailyEnergyConsumption> getBlockEnergyConsumption(String blockId, int day, int month, int year);
    void putBlockEnergyConsumption(String blockId, int day, int month, int year, DailyEnergyConsumption lightEnergyConsumption);

    Optional<MonthlyEnergyConsumption> getBlockEnergyConsumption(String blockId, int month, int year);
    void putBlockEnergyConsumption(String blockId, int month, int year, MonthlyEnergyConsumption floorEnergyConsumption);

    Optional<YearlyEnergyConsumption> getBlockEnergyConsumption(String blockId, int year);
    void putBlockEnergyConsumption(String blockId, int year, YearlyEnergyConsumption floorEnergyConsumption);

    Optional<DailyMotionDetectionCount> getLightMotionEventCount(String lightId, String blockId, int day, int month, int year);
    void putLightMotionEventCount(String lightId, String blockId, int day, int month, int year, DailyMotionDetectionCount dailyMotionDetectionCount);

    Optional<MonthlyMotionDetectionCount> getLightMotionEventCount(String lightId, String blockId, int month, int year);
    void putLightMotionEventCount(String lightId, String blockId, int month, int year, MonthlyMotionDetectionCount monthlyMotionDetectionCount);

    Optional<YearlyMotionDetectionCount> getLightMotionEventCount(String lightId, String blockId, int year);
    void putLightMotionEventCount(String lightId, String blockId, int year, YearlyMotionDetectionCount yearlyMotionDetectionCount);

    Optional<DailyMotionDetectionCount> getBlockMotionEventCount(String blockId, int day, int month, int year);
    void putBlockMotionEventCount(String blockId, int day, int month, int year, DailyMotionDetectionCount dailyMotionDetectionCount);

    Optional<MonthlyMotionDetectionCount> getBlockMotionEventCount(String blockId, int month, int year);
    void putBlockMotionEventCount(String blockId, int month, int year, MonthlyMotionDetectionCount monthlyMotionDetectionCount);

    Optional<YearlyMotionDetectionCount> getBlockMotionEventCount(String blockId, int year);
    void putBlockMotionEventCount(String blockId, int year, YearlyMotionDetectionCount yearlyMotionDetectionCount);

    Optional<DailyMotionDetectionCount> getFloorMotionEventCount(long floorId, int day, int month, int year);
    void putFloorMotionEventCount(long floorId, int day, int month, int year, DailyMotionDetectionCount dailyMotionDetectionCount);

    Optional<MonthlyMotionDetectionCount> getFloorMotionEventCount(long floorId, int month, int year);
    void putFloorMotionEventCount(long floorId, int month, int year, MonthlyMotionDetectionCount monthlyMotionDetectionCount);

    Optional<YearlyMotionDetectionCount> getFloorMotionEventCount(long floorId, int year);
    void putFloorMotionEventCount(long floorId, int year, YearlyMotionDetectionCount yearlyMotionDetectionCount);
}
