package com.aztech.light.analytic.entity;

import com.aztech.light.analytic.model.LightScopeCategory;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Data
@Entity
@Table(name = "energyConsumptionDay")
public class DailyEnergyConsumption {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "energyConsumptionDayId")
    private Long id;
    private LightScopeCategory dataType;
    private String dataId;
    private LocalDate reportDate;
    private float hourEnergy1;
    private float hourEnergy2;
    private float hourEnergy3;
    private float hourEnergy4;
    private float hourEnergy5;
    private float hourEnergy6;
    private float hourEnergy7;
    private float hourEnergy8;
    private float hourEnergy9;
    private float hourEnergy10;
    private float hourEnergy11;
    private float hourEnergy12;
    private float hourEnergy13;
    private float hourEnergy14;
    private float hourEnergy15;
    private float hourEnergy16;
    private float hourEnergy17;
    private float hourEnergy18;
    private float hourEnergy19;
    private float hourEnergy20;
    private float hourEnergy21;
    private float hourEnergy22;
    private float hourEnergy23;
    private float hourEnergy24;
}
