package com.aztech.light.analytic.service.impl;

import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.entity.SmartLight;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.model.DailyMotionDetectionCount;
import com.aztech.light.analytic.model.MonthlyMotionDetectionCount;
import com.aztech.light.analytic.model.YearlyMotionDetectionCount;
import com.aztech.light.analytic.service.CompositeLightAnalyticService;
import com.aztech.light.analytic.service.LightAnalyticCacheService;
import com.aztech.light.analytic.service.LightAnalyticService;
import com.aztech.light.analytic.service.SmartLightService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompositeLightAnalyticServiceImpl implements CompositeLightAnalyticService {
    private final LightAnalyticCacheService lightAnalyticCacheService;
    private final LightAnalyticService lightAnalyticService;
    private final SmartLightService smartLightService;

    public CompositeLightAnalyticServiceImpl(
            LightAnalyticCacheService lightAnalyticCacheService,
            LightAnalyticService lightAnalyticService,
            SmartLightService smartLightService) {
        this.lightAnalyticCacheService = lightAnalyticCacheService;
        this.lightAnalyticService = lightAnalyticService;
        this.smartLightService = smartLightService;
    }

    @Override
    public DailyEnergyConsumption getLightEnergyConsumption(String lightId, int day, int month, int year) {
        return lightAnalyticCacheService.getLightEnergyConsumption(lightId, day, month, year).orElseGet(() -> {
            final DailyEnergyConsumption dailyEnergyConsumption = lightAnalyticService.getLightEnergyConsumption(lightId, day, month, year);
            lightAnalyticCacheService.putLightEnergyConsumption(lightId, day, month, year, dailyEnergyConsumption);
            return dailyEnergyConsumption;
        });
    }

    @Override
    public MonthlyEnergyConsumption getLightEnergyConsumption(String lightId, int month, int year) {
        return lightAnalyticCacheService.getLightEnergyConsumption(lightId, month, year).orElseGet(() -> {
            final MonthlyEnergyConsumption monthlyEnergyConsumption = lightAnalyticService.getLightEnergyConsumption(lightId, month, year);
            lightAnalyticCacheService.putLightEnergyConsumption(lightId, month, year, monthlyEnergyConsumption);
            return monthlyEnergyConsumption;
        });
    }

    @Override
    public YearlyEnergyConsumption getLightEnergyConsumption(String lightId, int year) {
        return lightAnalyticCacheService.getLightEnergyConsumption(lightId, year).orElseGet(() -> {
            final YearlyEnergyConsumption yearlyEnergyConsumption = lightAnalyticService.getLightEnergyConsumption(lightId, year);
            lightAnalyticCacheService.putLightEnergyConsumption(lightId, year, yearlyEnergyConsumption);
            return yearlyEnergyConsumption;
        });
    }

    @Override
    public DailyEnergyConsumption getFloorEnergyConsumption(String floorId, int day, int month, int year) {
        return lightAnalyticCacheService.getFloorEnergyConsumption(floorId, day, month, year).orElseGet(() -> {
            final DailyEnergyConsumption dailyEnergyConsumption = lightAnalyticService.getFloorEnergyConsumption(floorId, day, month, year);
            lightAnalyticCacheService.putFloorEnergyConsumption(floorId, day, month, year, dailyEnergyConsumption);
            return dailyEnergyConsumption;
        });
    }

    @Override
    public MonthlyEnergyConsumption getFloorEnergyConsumption(String floorId, int month, int year) {
        return lightAnalyticCacheService.getFloorEnergyConsumption(floorId, month, year).orElseGet(() -> {
            final MonthlyEnergyConsumption monthlyEnergyConsumption = lightAnalyticService.getFloorEnergyConsumption(floorId, month, year);
            lightAnalyticCacheService.putFloorEnergyConsumption(floorId, month, year, monthlyEnergyConsumption);
            return monthlyEnergyConsumption;
        });
    }

    @Override
    public YearlyEnergyConsumption getFloorEnergyConsumption(String floorId, int year) {
        return lightAnalyticCacheService.getFloorEnergyConsumption(floorId, year).orElseGet(() -> {
            final YearlyEnergyConsumption yearlyEnergyConsumption = lightAnalyticService.getFloorEnergyConsumption(floorId, year);
            lightAnalyticCacheService.putFloorEnergyConsumption(floorId, year, yearlyEnergyConsumption);
            return yearlyEnergyConsumption;
        });
    }

    @Override
    public DailyEnergyConsumption getBlockEnergyConsumption(String blockId, int day, int month, int year) {
        return lightAnalyticCacheService.getBlockEnergyConsumption(blockId, day, month, year).orElseGet(() -> {
            final DailyEnergyConsumption dailyEnergyConsumption = lightAnalyticService.getBlockEnergyConsumption(blockId, day, month, year);
            lightAnalyticCacheService.putBlockEnergyConsumption(blockId, day, month, year, dailyEnergyConsumption);
            return dailyEnergyConsumption;
        });
    }

    @Override
    public MonthlyEnergyConsumption getBlockEnergyConsumption(String blockId, int month, int year) {
        return lightAnalyticCacheService.getBlockEnergyConsumption(blockId, month, year).orElseGet(() -> {
            final MonthlyEnergyConsumption monthlyEnergyConsumption = lightAnalyticService.getBlockEnergyConsumption(blockId, month, year);
            lightAnalyticCacheService.putBlockEnergyConsumption(blockId, month, year, monthlyEnergyConsumption);
            return monthlyEnergyConsumption;
        });
    }

    @Override
    public YearlyEnergyConsumption getBlockEnergyConsumption(String blockId, int year) {
        return lightAnalyticCacheService.getBlockEnergyConsumption(blockId, year).orElseGet(() -> {
            final YearlyEnergyConsumption yearlyEnergyConsumption = lightAnalyticService.getBlockEnergyConsumption(blockId, year);
            lightAnalyticCacheService.putBlockEnergyConsumption(blockId, year, yearlyEnergyConsumption);
            return yearlyEnergyConsumption;
        });
    }

    @Override
    public DailyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int day, int month, int year) {
        return lightAnalyticCacheService.getLightMotionEventCount(lightId, blockId, day, month, year).orElseGet(() -> {
            final DailyMotionDetectionCount dailyMotionDetectionCount =
                    lightAnalyticService.getLightMotionEventCount(lightId, blockId, day, month, year);
            lightAnalyticCacheService.putLightMotionEventCount(lightId, blockId, day, month, year, dailyMotionDetectionCount);
            return dailyMotionDetectionCount;
        });
    }

    @Override
    public MonthlyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int month, int year) {
        return lightAnalyticCacheService.getLightMotionEventCount(lightId, blockId, month, year).orElseGet(() -> {
            final MonthlyMotionDetectionCount monthlyMotionDetectionCount = lightAnalyticService.getLightMotionEventCount(lightId, blockId, month, year);
            lightAnalyticCacheService.putLightMotionEventCount(lightId, blockId, month, year, monthlyMotionDetectionCount);
            return monthlyMotionDetectionCount;
        });
    }

    @Override
    public YearlyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int year) {
        return lightAnalyticCacheService.getLightMotionEventCount(lightId, blockId, year).orElseGet(() -> {
            final YearlyMotionDetectionCount yearlyMotionDetectionCount = lightAnalyticService.getLightMotionEventCount(lightId, blockId, year);
            lightAnalyticCacheService.putLightMotionEventCount(lightId, blockId, year, yearlyMotionDetectionCount);
            return yearlyMotionDetectionCount;
        });
    }

    @Override
    public DailyMotionDetectionCount getBlockMotionEventCount(String blockId, int day, int month, int year) {
        return lightAnalyticCacheService.getBlockMotionEventCount(blockId, day, month, year).orElseGet(() -> {
            final DailyMotionDetectionCount dailyMotionDetectionCount =
                    lightAnalyticService.getBlockMotionEventCount(blockId, day, month, year);
            lightAnalyticCacheService.putBlockMotionEventCount(blockId, day, month, year, dailyMotionDetectionCount);
            return dailyMotionDetectionCount;
        });
    }

    @Override
    public MonthlyMotionDetectionCount getBlockMotionEventCount(String blockId, int month, int year) {
        return lightAnalyticCacheService.getBlockMotionEventCount(blockId, month, year).orElseGet(() -> {
            final MonthlyMotionDetectionCount monthlyMotionDetectionCount = lightAnalyticService.getBlockMotionEventCount(blockId, month, year);
            lightAnalyticCacheService.putBlockMotionEventCount(blockId, month, year, monthlyMotionDetectionCount);
            return monthlyMotionDetectionCount;
        });
    }

    @Override
    public YearlyMotionDetectionCount getBlockMotionEventCount(String blockId, int year) {
        return lightAnalyticCacheService.getBlockMotionEventCount(blockId, year).orElseGet(() -> {
            final YearlyMotionDetectionCount yearlyMotionDetectionCount = lightAnalyticService.getBlockMotionEventCount(blockId, year);
            lightAnalyticCacheService.putBlockMotionEventCount(blockId, year, yearlyMotionDetectionCount);
            return yearlyMotionDetectionCount;
        });
    }

    @Override
    public DailyMotionDetectionCount getFloorMotionEventCount(long floorId, String blockNO, int day, int month, int year) {
        return lightAnalyticCacheService.getFloorMotionEventCount(floorId, day, month, year).orElseGet(() -> {
            List<SmartLight> smartLightList = smartLightService.getSmartLight(floorId);
            final DailyMotionDetectionCount dailyMotionDetectionCount = lightAnalyticService.getFloorMotionEventCount(smartLightList, blockNO, day, month, year);
            lightAnalyticCacheService.putFloorMotionEventCount(floorId, day, month, year, dailyMotionDetectionCount);
            return dailyMotionDetectionCount;
        });
    }

    @Override
    public MonthlyMotionDetectionCount getFloorMotionEventCount(long floorId, String blockNO, int month, int year) {
        return lightAnalyticCacheService.getFloorMotionEventCount(floorId, month, year).orElseGet(() -> {
            List<SmartLight> smartLightList = smartLightService.getSmartLight(floorId);
            final MonthlyMotionDetectionCount monthlyMotionDetectionCount = lightAnalyticService.getFloorMotionEventCount(smartLightList, blockNO, month, year);
            lightAnalyticCacheService.putFloorMotionEventCount(floorId, month, year, monthlyMotionDetectionCount);
            return monthlyMotionDetectionCount;
        });
    }

    @Override
    public YearlyMotionDetectionCount getFloorMotionEventCount(long floorId, String blockNO, int year) {
        return lightAnalyticCacheService.getFloorMotionEventCount(floorId, year).orElseGet(() -> {
            List<SmartLight> smartLightList = smartLightService.getSmartLight(floorId);
            final YearlyMotionDetectionCount yearlyMotionDetectionCount = lightAnalyticService.getFloorMotionEventCount(smartLightList, blockNO, year);
            lightAnalyticCacheService.putFloorMotionEventCount(floorId, year, yearlyMotionDetectionCount);
            return yearlyMotionDetectionCount;
        });
    }
}
