package com.aztech.light.analytic.exception;

public class LightScopeCategoryNotFoundException extends RuntimeException {
    public LightScopeCategoryNotFoundException(int scopeValue) {
        super(String.format("LightScopeCategory of value '%d' cannot be found", scopeValue));
    }
}
