package com.aztech.light.analytic.repository;

import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.model.LightScopeCategory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface YearlyEnergyConsumptionRepository extends CrudRepository<YearlyEnergyConsumption, Long> {
    Optional<YearlyEnergyConsumption> findByDataTypeAndDataIdAndReportYear(LightScopeCategory dataType, String dataId, int year);
}
