package com.aztech.light.analytic.service;

import com.aztech.light.analytic.entity.SmartLight;

import java.util.List;

public interface SmartLightService {
    List<SmartLight> getSmartLight(long floorId);
}
