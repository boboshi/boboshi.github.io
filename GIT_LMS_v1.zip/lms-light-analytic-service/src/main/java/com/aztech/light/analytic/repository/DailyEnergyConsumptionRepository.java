package com.aztech.light.analytic.repository;

import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.model.LightScopeCategory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public interface DailyEnergyConsumptionRepository extends CrudRepository<DailyEnergyConsumption, Long> {
    Optional<DailyEnergyConsumption> findByDataTypeAndDataIdAndReportDate(LightScopeCategory dataType, String dataId, LocalDate date);
}
