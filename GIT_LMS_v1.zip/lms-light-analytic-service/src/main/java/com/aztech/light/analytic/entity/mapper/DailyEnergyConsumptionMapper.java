package com.aztech.light.analytic.entity.mapper;

import com.aztech.light.analytic.dto.DailyEnergyConsumptionDto;
import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.model.SerializableDailyEnergyConsumption;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = LocalDateMapper.class)
public interface DailyEnergyConsumptionMapper {
    DailyEnergyConsumptionDto toDailyEnergyConsumptionDto(DailyEnergyConsumption dailyEnergyConsumption);
    SerializableDailyEnergyConsumption toSerializableDailyEnergyConsumption(DailyEnergyConsumption dailyEnergyConsumption);
    DailyEnergyConsumption fromSerializableDailyEnergyConsumption(SerializableDailyEnergyConsumption serializableDailyEnergyConsumption);
}
