package com.aztech.light.analytic.model;

public enum LightScopeCategory {
    AREA(1),
    BLOCK(2),
    FLOOR(3),
    LIGHT(4);

    private final int scope;

    LightScopeCategory(final int scope) {
        this.scope = scope;
    }

    int getScopeValue() {
        return scope;
    }
}
