package com.aztech.light.analytic.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MonthlyEnergyConsumptionDto {
    private int reportMonth;
    private int reportYear;
    private double dayEnergy1;
    private double dayEnergy2;
    private double dayEnergy3;
    private double dayEnergy4;
    private double dayEnergy5;
    private double dayEnergy6;
    private double dayEnergy7;
    private double dayEnergy8;
    private double dayEnergy9;
    private double dayEnergy10;
    private double dayEnergy11;
    private double dayEnergy12;
    private double dayEnergy13;
    private double dayEnergy14;
    private double dayEnergy15;
    private double dayEnergy16;
    private double dayEnergy17;
    private double dayEnergy18;
    private double dayEnergy19;
    private double dayEnergy20;
    private double dayEnergy21;
    private double dayEnergy22;
    private double dayEnergy23;
    private double dayEnergy24;
    private double dayEnergy25;
    private double dayEnergy26;
    private double dayEnergy27;
    private double dayEnergy28;
    private double dayEnergy29;
    private double dayEnergy30;
    private double dayEnergy31;
}
