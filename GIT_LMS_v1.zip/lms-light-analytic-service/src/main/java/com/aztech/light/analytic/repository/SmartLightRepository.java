package com.aztech.light.analytic.repository;

import com.aztech.light.analytic.entity.SmartLight;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SmartLightRepository extends CrudRepository<SmartLight, Long> {
    List<SmartLight> findByFloorId(long floorId);
}
