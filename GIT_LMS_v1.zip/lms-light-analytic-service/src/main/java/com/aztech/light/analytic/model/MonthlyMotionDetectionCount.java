package com.aztech.light.analytic.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(force = true)
public class MonthlyMotionDetectionCount {
    private long dayPIRDetectNumber1;
    private long dayPIRDetectNumber2;
    private long dayPIRDetectNumber3;
    private long dayPIRDetectNumber4;
    private long dayPIRDetectNumber5;
    private long dayPIRDetectNumber6;
    private long dayPIRDetectNumber7;
    private long dayPIRDetectNumber8;
    private long dayPIRDetectNumber9;
    private long dayPIRDetectNumber10;
    private long dayPIRDetectNumber11;
    private long dayPIRDetectNumber12;
    private long dayPIRDetectNumber13;
    private long dayPIRDetectNumber14;
    private long dayPIRDetectNumber15;
    private long dayPIRDetectNumber16;
    private long dayPIRDetectNumber17;
    private long dayPIRDetectNumber18;
    private long dayPIRDetectNumber19;
    private long dayPIRDetectNumber20;
    private long dayPIRDetectNumber21;
    private long dayPIRDetectNumber22;
    private long dayPIRDetectNumber23;
    private long dayPIRDetectNumber24;
    private long dayPIRDetectNumber25;
    private long dayPIRDetectNumber26;
    private long dayPIRDetectNumber27;
    private long dayPIRDetectNumber28;
    private long dayPIRDetectNumber29;
    private long dayPIRDetectNumber30;
    private long dayPIRDetectNumber31;
}
