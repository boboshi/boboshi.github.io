package com.aztech.light.analytic.entity.mapper;

import com.aztech.light.analytic.dto.MonthlyEnergyConsumptionDto;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import org.mapstruct.Mapper;

import java.util.Arrays;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Mapper(componentModel = "spring")
public interface MonthlyEnergyConsumptionMapper {

    MonthlyEnergyConsumptionDto toMonthlyEnergyConsumptionDto(MonthlyEnergyConsumption monthlyEnergyConsumption);

//    public List<List<Double>> toDoubleArrays(List<MonthlyEnergyConsumption> monthlyEnergyConsumptions) {
//        return monthlyEnergyConsumptions.stream()
//                .map(this::getDailyEnergyConsumptionAsList)
//                .collect(toList());
//    }
//
//    private List<Double> getDailyEnergyConsumptionAsList(MonthlyEnergyConsumption monthlyEnergyConsumption) {
//        return Arrays.asList(
//                monthlyEnergyConsumption.getDayEnergy1(),
//                monthlyEnergyConsumption.getDayEnergy2(),
//                monthlyEnergyConsumption.getDayEnergy3(),
//                monthlyEnergyConsumption.getDayEnergy4(),
//                monthlyEnergyConsumption.getDayEnergy5(),
//                monthlyEnergyConsumption.getDayEnergy6(),
//                monthlyEnergyConsumption.getDayEnergy7(),
//                monthlyEnergyConsumption.getDayEnergy8(),
//                monthlyEnergyConsumption.getDayEnergy9(),
//                monthlyEnergyConsumption.getDayEnergy10(),
//                monthlyEnergyConsumption.getDayEnergy11(),
//                monthlyEnergyConsumption.getDayEnergy12(),
//                monthlyEnergyConsumption.getDayEnergy13(),
//                monthlyEnergyConsumption.getDayEnergy14(),
//                monthlyEnergyConsumption.getDayEnergy15(),
//                monthlyEnergyConsumption.getDayEnergy16(),
//                monthlyEnergyConsumption.getDayEnergy17(),
//                monthlyEnergyConsumption.getDayEnergy18(),
//                monthlyEnergyConsumption.getDayEnergy19(),
//                monthlyEnergyConsumption.getDayEnergy20(),
//                monthlyEnergyConsumption.getDayEnergy21(),
//                monthlyEnergyConsumption.getDayEnergy22(),
//                monthlyEnergyConsumption.getDayEnergy23(),
//                monthlyEnergyConsumption.getDayEnergy24(),
//                monthlyEnergyConsumption.getDayEnergy25(),
//                monthlyEnergyConsumption.getDayEnergy26(),
//                monthlyEnergyConsumption.getDayEnergy27(),
//                monthlyEnergyConsumption.getDayEnergy28(),
//                monthlyEnergyConsumption.getDayEnergy29(),
//                monthlyEnergyConsumption.getDayEnergy30(),
//                monthlyEnergyConsumption.getDayEnergy31()
//        );
//    }
}
