package com.aztech.light.analytic.repository;

import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.model.LightScopeCategory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MonthlyEnergyConsumptionRepository extends CrudRepository<MonthlyEnergyConsumption, Long> {
    Optional<MonthlyEnergyConsumption> findByDataTypeAndDataIdAndReportMonthAndReportYear(LightScopeCategory dataType, String dataId, int month, int year);
}
