package com.aztech.light.analytic.entity.mapper;

import com.aztech.light.analytic.dto.YearlyEnergyConsumptionDto;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface YearlyEnergyConsumptionMapper {
    YearlyEnergyConsumptionDto toYearlyEnergyConsumptionDto(YearlyEnergyConsumption yearlyEnergyConsumption);
}
