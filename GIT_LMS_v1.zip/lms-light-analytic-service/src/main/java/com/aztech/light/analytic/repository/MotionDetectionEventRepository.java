package com.aztech.light.analytic.repository;

import com.aztech.light.analytic.entity.MotionDetectionEvent;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MotionDetectionEventRepository extends CrudRepository<MotionDetectionEvent, Long> {
    List<MotionDetectionEvent> findByDetectedStatusGreaterThanEqualAndLightSNAndBlockNOAndReportDateTimeBetween(
            int detectedStatus, String lightSN, String blockNO, LocalDateTime startDate, LocalDateTime endDate);

    List<MotionDetectionEvent> findByDetectedStatusGreaterThanEqualAndBlockNOAndReportDateTimeBetween(
            int detectedStatus, String blockNO, LocalDateTime startDate, LocalDateTime endDate);

    List<MotionDetectionEvent> findByLightSNInAndReportDateTimeBetween(List<String> lightId, LocalDateTime startDate, LocalDateTime endDate);

    List<MotionDetectionEvent> findByLightSNInAndBlockNOAndReportDateTimeBetween(List<String> lightId, String blockNO, LocalDateTime startDate, LocalDateTime endDate);
}
