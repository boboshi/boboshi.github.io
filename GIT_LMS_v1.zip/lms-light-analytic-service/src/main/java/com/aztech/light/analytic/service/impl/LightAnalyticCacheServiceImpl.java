package com.aztech.light.analytic.service.impl;

import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.entity.mapper.DailyEnergyConsumptionMapper;
import com.aztech.light.analytic.model.DailyMotionDetectionCount;
import com.aztech.light.analytic.model.MonthlyMotionDetectionCount;
import com.aztech.light.analytic.model.SerializableDailyEnergyConsumption;
import com.aztech.light.analytic.model.YearlyMotionDetectionCount;
import com.aztech.light.analytic.service.LightAnalyticCacheService;
import org.springframework.data.redis.core.ReactiveRedisOperations;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Arrays;
import java.util.Optional;

@Service
public class LightAnalyticCacheServiceImpl implements LightAnalyticCacheService {
    private static final Duration KEY_EXPIRY_30_MINUTES = Duration.ofMinutes(30);
    private static final Duration KEY_EXPIRY_24_HOURS = Duration.ofDays(1);
    private ReactiveRedisOperations<String, SerializableDailyEnergyConsumption> dailyEnergyOperations;
    private ReactiveRedisOperations<String, MonthlyEnergyConsumption> monthlyEnergyOperations;
    private ReactiveRedisOperations<String, YearlyEnergyConsumption> yearlyEnergyOperations;
    private ReactiveRedisOperations<String, DailyMotionDetectionCount> dailyMotionOperations;
    private ReactiveRedisOperations<String, MonthlyMotionDetectionCount> monthlyMotionOperations;
    private ReactiveRedisOperations<String, YearlyMotionDetectionCount> yearlyMotionOperations;
    private DailyEnergyConsumptionMapper dailyEnergyConsumptionMapper;

    public LightAnalyticCacheServiceImpl(
            ReactiveRedisOperations<String, SerializableDailyEnergyConsumption> dailyEnergyOperations,
            ReactiveRedisOperations<String, MonthlyEnergyConsumption> monthlyEnergyOperations,
            ReactiveRedisOperations<String, YearlyEnergyConsumption> yearlyEnergyOperations,
            ReactiveRedisOperations<String, DailyMotionDetectionCount> dailyMotionOperations,
            ReactiveRedisOperations<String, MonthlyMotionDetectionCount> monthlyMotionOperations,
            ReactiveRedisOperations<String, YearlyMotionDetectionCount> yearlyMotionOperations,
            DailyEnergyConsumptionMapper dailyEnergyConsumptionMapper) {
        this.dailyEnergyOperations = dailyEnergyOperations;
        this.monthlyEnergyOperations = monthlyEnergyOperations;
        this.yearlyEnergyOperations = yearlyEnergyOperations;
        this.dailyMotionOperations = dailyMotionOperations;
        this.monthlyMotionOperations = monthlyMotionOperations;
        this.yearlyMotionOperations = yearlyMotionOperations;
        this.dailyEnergyConsumptionMapper = dailyEnergyConsumptionMapper;
    }

    @Override
    public Optional<DailyEnergyConsumption> getLightEnergyConsumption(String lightId, int day, int month, int year) {
        final String key = makeKey("energy", lightId, day, month, year);
        return dailyEnergyOperations.opsForValue().get(key).blockOptional()
                .flatMap(o -> Optional.of(dailyEnergyConsumptionMapper.fromSerializableDailyEnergyConsumption(o)));
    }

    @Override
    public void putLightEnergyConsumption(String lightId, int day, int month, int year, DailyEnergyConsumption lightEnergyConsumption) {
        final String key = makeKey("energy", lightId, day, month, year);
        final SerializableDailyEnergyConsumption serializableDailyEnergyConsumption = dailyEnergyConsumptionMapper.toSerializableDailyEnergyConsumption(lightEnergyConsumption);
        dailyEnergyOperations.opsForValue().set(key, serializableDailyEnergyConsumption, KEY_EXPIRY_30_MINUTES).block();
    }

    @Override
    public Optional<MonthlyEnergyConsumption> getLightEnergyConsumption(String lightId, int month, int year) {
        final String key = makeKey("energy", lightId, month, year);
        return monthlyEnergyOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putLightEnergyConsumption(String lightId, int month, int year, MonthlyEnergyConsumption lightEnergyConsumption) {
        final String key = makeKey("energy", lightId, month, year);
        monthlyEnergyOperations.opsForValue().set(key, lightEnergyConsumption, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<YearlyEnergyConsumption> getLightEnergyConsumption(String lightId, int year) {
        final String key = makeKey("energy", lightId, year);
        return yearlyEnergyOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putLightEnergyConsumption(String lightId, int year, YearlyEnergyConsumption lightEnergyConsumption) {
        final String key = makeKey("energy", lightId, year);
        yearlyEnergyOperations.opsForValue().set(key, lightEnergyConsumption, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<DailyEnergyConsumption> getFloorEnergyConsumption(String floorId, int day, int month, int year) {
        final String key = makeKey("energy", floorId, day, month, year);
        return dailyEnergyOperations.opsForValue().get(key).blockOptional()
                .flatMap(o -> Optional.of(dailyEnergyConsumptionMapper.fromSerializableDailyEnergyConsumption(o)));
    }

    @Override
    public void putFloorEnergyConsumption(String floorId, int day, int month, int year, DailyEnergyConsumption lightEnergyConsumption) {
        final String key = makeKey("energy", floorId, day, month, year);
        final SerializableDailyEnergyConsumption serializableDailyEnergyConsumption = dailyEnergyConsumptionMapper.toSerializableDailyEnergyConsumption(lightEnergyConsumption);
        dailyEnergyOperations.opsForValue().set(key, serializableDailyEnergyConsumption, KEY_EXPIRY_30_MINUTES).block();
    }

    @Override
    public Optional<MonthlyEnergyConsumption> getFloorEnergyConsumption(String floorId, int month, int year) {
        final String key = makeKey("energy", floorId, month, year);
        return monthlyEnergyOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putFloorEnergyConsumption(String floorId, int month, int year, MonthlyEnergyConsumption floorEnergyConsumption) {
        final String key = makeKey("energy", floorId, month, year);
        monthlyEnergyOperations.opsForValue().set(key, floorEnergyConsumption, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<YearlyEnergyConsumption> getFloorEnergyConsumption(String floorId, int year) {
        final String key = makeKey("energy", floorId, year);
        return yearlyEnergyOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putFloorEnergyConsumption(String floorId, int year, YearlyEnergyConsumption floorEnergyConsumption) {
        final String key = makeKey("energy", floorId, year);
        yearlyEnergyOperations.opsForValue().set(key, floorEnergyConsumption, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<DailyEnergyConsumption> getBlockEnergyConsumption(String blockId, int day, int month, int year) {
        final String key = makeKey("energy", blockId, day, month, year);
        return dailyEnergyOperations.opsForValue().get(key).blockOptional()
                .flatMap(o -> Optional.of(dailyEnergyConsumptionMapper.fromSerializableDailyEnergyConsumption(o)));
    }

    @Override
    public void putBlockEnergyConsumption(String blockId, int day, int month, int year, DailyEnergyConsumption lightEnergyConsumption) {
        final String key = makeKey("energy", blockId, day, month, year);
        final SerializableDailyEnergyConsumption serializableDailyEnergyConsumption = dailyEnergyConsumptionMapper.toSerializableDailyEnergyConsumption(lightEnergyConsumption);
        dailyEnergyOperations.opsForValue().set(key, serializableDailyEnergyConsumption, KEY_EXPIRY_30_MINUTES).block();
    }

    @Override
    public Optional<MonthlyEnergyConsumption> getBlockEnergyConsumption(String blockId, int month, int year) {
        final String key = makeKey("energy", blockId, month, year);
        return monthlyEnergyOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putBlockEnergyConsumption(String blockId, int month, int year, MonthlyEnergyConsumption floorEnergyConsumption) {
        final String key = makeKey("energy", blockId, month, year);
        monthlyEnergyOperations.opsForValue().set(key, floorEnergyConsumption, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<YearlyEnergyConsumption> getBlockEnergyConsumption(String blockId, int year) {
        final String key = makeKey("energy", blockId, year);
        return yearlyEnergyOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putBlockEnergyConsumption(String blockId, int year, YearlyEnergyConsumption floorEnergyConsumption) {
        final String key = makeKey("energy", blockId, year);
        yearlyEnergyOperations.opsForValue().set(key, floorEnergyConsumption, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<DailyMotionDetectionCount> getLightMotionEventCount(String lightId, String blockId, int day, int month, int year) {
        final String key = makeKey("motion", lightId, blockId, day, month, year);
        return dailyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putLightMotionEventCount(String lightId, String blockId, int day, int month, int year, DailyMotionDetectionCount dailyMotionDetectionCount) {
        final String key = makeKey("motion", lightId, blockId, day, month, year);
        dailyMotionOperations.opsForValue().set(key, dailyMotionDetectionCount, KEY_EXPIRY_30_MINUTES).block();
    }

    @Override
    public Optional<MonthlyMotionDetectionCount> getLightMotionEventCount(String lightId, String blockId, int month, int year) {
        final String key = makeKey("motion", lightId, blockId, month, year);
        return monthlyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putLightMotionEventCount(String lightId, String blockId, int month, int year, MonthlyMotionDetectionCount monthlyMotionDetectionCount) {
        final String key = makeKey("motion", lightId, blockId, month, year);
        monthlyMotionOperations.opsForValue().set(key, monthlyMotionDetectionCount, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<YearlyMotionDetectionCount> getLightMotionEventCount(String lightId, String blockId, int year) {
        final String key = makeKey("motion", lightId, blockId, year);
        return yearlyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putLightMotionEventCount(String lightId, String blockId, int year, YearlyMotionDetectionCount yearlyMotionDetectionCount) {
        final String key = makeKey("motion", lightId, blockId, year);
        yearlyMotionOperations.opsForValue().set(key, yearlyMotionDetectionCount, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<DailyMotionDetectionCount> getBlockMotionEventCount(String blockId, int day, int month, int year) {
        final String key = makeKey("motion", blockId, day, month, year);
        return dailyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putBlockMotionEventCount(String blockId, int day, int month, int year, DailyMotionDetectionCount dailyMotionDetectionCount) {
        final String key = makeKey("motion", blockId, day, month, year);
        dailyMotionOperations.opsForValue().set(key, dailyMotionDetectionCount, KEY_EXPIRY_30_MINUTES).block();
    }

    @Override
    public Optional<MonthlyMotionDetectionCount> getBlockMotionEventCount(String blockId, int month, int year) {
        final String key = makeKey("motion", blockId, month, year);
        return monthlyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putBlockMotionEventCount(String blockId, int month, int year, MonthlyMotionDetectionCount monthlyMotionDetectionCount) {
        final String key = makeKey("motion", blockId, month, year);
        monthlyMotionOperations.opsForValue().set(key, monthlyMotionDetectionCount, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<YearlyMotionDetectionCount> getBlockMotionEventCount(String blockId, int year) {
        final String key = makeKey("motion", blockId, year);
        return yearlyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putBlockMotionEventCount(String blockId, int year, YearlyMotionDetectionCount yearlyMotionDetectionCount) {
        final String key = makeKey("motion", blockId, year);
        yearlyMotionOperations.opsForValue().set(key, yearlyMotionDetectionCount, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<DailyMotionDetectionCount> getFloorMotionEventCount(long floorId, int day, int month, int year) {
        final String key = makeKey("motion", floorId, day, month, year);
        return dailyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putFloorMotionEventCount(long floorId, int day, int month, int year, DailyMotionDetectionCount dailyMotionDetectionCount) {
        final String key = makeKey("motion", floorId, day, month, year);
        dailyMotionOperations.opsForValue().set(key, dailyMotionDetectionCount, KEY_EXPIRY_30_MINUTES).block();
    }

    @Override
    public Optional<MonthlyMotionDetectionCount> getFloorMotionEventCount(long floorId, int month, int year) {
        final String key = makeKey("motion", floorId, month, year);
        return monthlyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putFloorMotionEventCount(long floorId, int month, int year, MonthlyMotionDetectionCount monthlyMotionDetectionCount) {
        final String key = makeKey("motion", floorId, month, year);
        monthlyMotionOperations.opsForValue().set(key, monthlyMotionDetectionCount, KEY_EXPIRY_24_HOURS).block();
    }

    @Override
    public Optional<YearlyMotionDetectionCount> getFloorMotionEventCount(long floorId, int year) {
        final String key = makeKey("motion", floorId, year);
        return yearlyMotionOperations.opsForValue().get(key).blockOptional();
    }

    @Override
    public void putFloorMotionEventCount(long floorId, int year, YearlyMotionDetectionCount yearlyMotionDetectionCount) {
        final String key = makeKey("motion", floorId, year);
        yearlyMotionOperations.opsForValue().set(key, yearlyMotionDetectionCount, KEY_EXPIRY_24_HOURS).block();
    }

    private String makeKey(Object... parts) {
        return Arrays.stream(parts).collect(StringBuilder::new, (builder, e) -> builder.append(e), (b1, b2) -> {}).toString();
    }
}
