package com.aztech.light.analytic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsLightAnalyticServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmsLightAnalyticServiceApplication.class, args);
	}

}
