package com.aztech.light.analytic.service;

import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.model.DailyMotionDetectionCount;
import com.aztech.light.analytic.model.MonthlyMotionDetectionCount;
import com.aztech.light.analytic.model.YearlyMotionDetectionCount;

public interface CompositeLightAnalyticService {
    DailyEnergyConsumption getLightEnergyConsumption(String lightId, int day, int month, int year);
    MonthlyEnergyConsumption getLightEnergyConsumption(String lightId, int month, int year);
    YearlyEnergyConsumption getLightEnergyConsumption(String lightId, int year);

    DailyEnergyConsumption getFloorEnergyConsumption(String floorId, int day, int month, int year);
    MonthlyEnergyConsumption getFloorEnergyConsumption(String floorId, int month, int year);
    YearlyEnergyConsumption getFloorEnergyConsumption(String floorId, int year);

    DailyEnergyConsumption getBlockEnergyConsumption(String blockId, int day, int month, int year);
    MonthlyEnergyConsumption getBlockEnergyConsumption(String blockId, int month, int year);
    YearlyEnergyConsumption getBlockEnergyConsumption(String blockId, int year);

    DailyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int day, int month, int year);
    MonthlyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int month, int year);
    YearlyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int year);

    DailyMotionDetectionCount getBlockMotionEventCount(String blockId, int day, int month, int year);
    MonthlyMotionDetectionCount getBlockMotionEventCount(String blockId, int month, int year);
    YearlyMotionDetectionCount getBlockMotionEventCount(String blockId, int year);

    DailyMotionDetectionCount getFloorMotionEventCount(long floorId, String blockNO, int day, int month, int year);
    MonthlyMotionDetectionCount getFloorMotionEventCount(long floorId, String blockNO, int month, int year);
    YearlyMotionDetectionCount getFloorMotionEventCount(long floorId, String blockNO, int year);
}
