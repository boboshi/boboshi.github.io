package com.aztech.light.analytic.controller;

import com.aztech.light.analytic.dto.DailyEnergyConsumptionDto;
import com.aztech.light.analytic.dto.MonthlyEnergyConsumptionDto;
import com.aztech.light.analytic.dto.YearlyEnergyConsumptionDto;
import com.aztech.light.analytic.entity.mapper.DailyEnergyConsumptionMapper;
import com.aztech.light.analytic.entity.mapper.MonthlyEnergyConsumptionMapper;
import com.aztech.light.analytic.entity.mapper.YearlyEnergyConsumptionMapper;
import com.aztech.light.analytic.model.DailyMotionDetectionCount;
import com.aztech.light.analytic.model.MonthlyMotionDetectionCount;
import com.aztech.light.analytic.model.YearlyMotionDetectionCount;
import com.aztech.light.analytic.service.CompositeLightAnalyticService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/light-analytic")
public class LightAnalyticServiceController {
    private CompositeLightAnalyticService compositeLightAnalyticService;
    private DailyEnergyConsumptionMapper dailyEnergyConsumptionMapper;
    private MonthlyEnergyConsumptionMapper monthlyEnergyConsumptionMapper;
    private YearlyEnergyConsumptionMapper yearlyEnergyConsumptionMapper;

    public LightAnalyticServiceController(
            CompositeLightAnalyticService compositeLightAnalyticService,
            DailyEnergyConsumptionMapper dailyEnergyConsumptionMapper,
            MonthlyEnergyConsumptionMapper monthlyEnergyConsumptionMapper,
            YearlyEnergyConsumptionMapper yearlyEnergyConsumptionMapper) {
        this.compositeLightAnalyticService = compositeLightAnalyticService;
        this.dailyEnergyConsumptionMapper = dailyEnergyConsumptionMapper;
        this.monthlyEnergyConsumptionMapper = monthlyEnergyConsumptionMapper;
        this.yearlyEnergyConsumptionMapper = yearlyEnergyConsumptionMapper;
    }

    @GetMapping(path = "/energy/lightId/{lightId}/day/{day}/month/{month}/year/{year}")
    public DailyEnergyConsumptionDto getLightDailyEnergyConsumption(
            @PathVariable String lightId,
            @PathVariable int day,
            @PathVariable int month,
            @PathVariable int year) {
        return dailyEnergyConsumptionMapper.toDailyEnergyConsumptionDto(compositeLightAnalyticService.getLightEnergyConsumption(lightId, day, month, year));
    }

    @GetMapping(path = "/energy/lightId/{lightId}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public MonthlyEnergyConsumptionDto getLightMonthlyEnergyConsumption(
            @PathVariable String lightId,
            @PathVariable int month,
            @PathVariable int year) {
        return monthlyEnergyConsumptionMapper.toMonthlyEnergyConsumptionDto(compositeLightAnalyticService.getLightEnergyConsumption(lightId, month, year));
    }

    @GetMapping(path = "/energy/lightId/{lightId}/year/{year}", produces = "application/json")
    @ResponseBody
    public YearlyEnergyConsumptionDto getLightYearlyEnergyConsumption(
            @PathVariable String lightId,
            @PathVariable int year) {
        return yearlyEnergyConsumptionMapper.toYearlyEnergyConsumptionDto(compositeLightAnalyticService.getLightEnergyConsumption(lightId, year));
    }

    @GetMapping(path = "/energy/floorId/{floorId}/day/{day}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public DailyEnergyConsumptionDto getFloorDailyEnergyConsumption(
            @PathVariable String floorId,
            @PathVariable int day,
            @PathVariable int month,
            @PathVariable int year) {
        return dailyEnergyConsumptionMapper.toDailyEnergyConsumptionDto(compositeLightAnalyticService.getFloorEnergyConsumption(floorId, day, month, year));
    }

    @GetMapping(path = "/energy/floorId/{floorId}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public MonthlyEnergyConsumptionDto getFloorMonthlyEnergyConsumption(
            @PathVariable String floorId,
            @PathVariable int month,
            @PathVariable int year) {
        return monthlyEnergyConsumptionMapper.toMonthlyEnergyConsumptionDto(compositeLightAnalyticService.getFloorEnergyConsumption(floorId, month, year));
    }

    @GetMapping(path = "/energy/floorId/{floorId}/year/{year}", produces = "application/json")
    @ResponseBody
    public YearlyEnergyConsumptionDto getFloorYearlyEnergyConsumption(
            @PathVariable String floorId,
            @PathVariable int year) {
        return yearlyEnergyConsumptionMapper.toYearlyEnergyConsumptionDto(compositeLightAnalyticService.getFloorEnergyConsumption(floorId, year));
    }

    @GetMapping(path = "/energy/blockId/{blockId}/day/{day}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public DailyEnergyConsumptionDto getBlockDailyEnergyConsumption(
            @PathVariable String blockId,
            @PathVariable int day,
            @PathVariable int month,
            @PathVariable int year) {
        return dailyEnergyConsumptionMapper.toDailyEnergyConsumptionDto(compositeLightAnalyticService.getBlockEnergyConsumption(blockId, day, month, year));
    }

    @GetMapping(path = "/energy/blockId/{blockId}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public MonthlyEnergyConsumptionDto getBlockMonthlyEnergyConsumption(
            @PathVariable String blockId,
            @PathVariable int month,
            @PathVariable int year) {
        return monthlyEnergyConsumptionMapper.toMonthlyEnergyConsumptionDto(compositeLightAnalyticService.getBlockEnergyConsumption(blockId, month, year));
    }

    @GetMapping(path = "/energy/blockId/{blockId}/year/{year}", produces = "application/json")
    @ResponseBody
    public YearlyEnergyConsumptionDto getBlockYearlyEnergyConsumption(
            @PathVariable String blockId,
            @PathVariable int year) {
        return yearlyEnergyConsumptionMapper.toYearlyEnergyConsumptionDto(compositeLightAnalyticService.getBlockEnergyConsumption(blockId, year));
    }

    @GetMapping(path = "/motion/lightId/{lightId}/blockId/{blockId}/day/{day}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public DailyMotionDetectionCount getDailyMotionDetectionCount(
            @PathVariable String lightId,
            @PathVariable String blockId,
            @PathVariable int day,
            @PathVariable int month,
            @PathVariable int year) {
        return compositeLightAnalyticService.getLightMotionEventCount(lightId, blockId, day, month, year);
    }

    @GetMapping(path = "/motion/lightId/{lightId}/blockId/{blockId}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public MonthlyMotionDetectionCount getMonthlyMotionDetectionCount(
            @PathVariable String lightId,
            @PathVariable String blockId,
            @PathVariable int month,
            @PathVariable int year) {
        return compositeLightAnalyticService.getLightMotionEventCount(lightId, blockId, month, year);
    }

    @GetMapping(path = "/motion/lightId/{lightId}/blockId/{blockId}/year/{year}", produces = "application/json")
    @ResponseBody
    public YearlyMotionDetectionCount getYearlyMotionDetectionCount(
            @PathVariable String lightId,
            @PathVariable String blockId,
            @PathVariable int year) {
        return compositeLightAnalyticService.getLightMotionEventCount(lightId, blockId, year);
    }

    @GetMapping(path = "/motion/blockId/{blockId}/day/{day}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public DailyMotionDetectionCount getDailyBlockMotionDetectionCount(
            @PathVariable String blockId,
            @PathVariable int day,
            @PathVariable int month,
            @PathVariable int year) {
        return compositeLightAnalyticService.getBlockMotionEventCount(blockId, day, month, year);
    }

    @GetMapping(path = "/motion/blockId/{blockId}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public MonthlyMotionDetectionCount getMonthlyBlockMotionDetectionCount(
            @PathVariable String blockId,
            @PathVariable int month,
            @PathVariable int year) {
        return compositeLightAnalyticService.getBlockMotionEventCount(blockId, month, year);
    }

    @GetMapping(path = "/motion/blockId/{blockId}/year/{year}", produces = "application/json")
    @ResponseBody
    public YearlyMotionDetectionCount getYearlyBlockMotionDetectionCount(
            @PathVariable String blockId,
            @PathVariable int year) {
        return compositeLightAnalyticService.getBlockMotionEventCount(blockId, year);
    }

    @GetMapping(path = "/motion/floorId/{floorId}/blockNO/{blockNO}/day/{day}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public DailyMotionDetectionCount getDailyFloorMotionDetectionCount(
            @PathVariable long floorId,
            @PathVariable String blockNO,
            @PathVariable int day,
            @PathVariable int month,
            @PathVariable int year) {
        return compositeLightAnalyticService.getFloorMotionEventCount(floorId, blockNO, day, month, year);
    }

    @GetMapping(path = "/motion/floorId/{floorId}/blockNO/{blockNO}/month/{month}/year/{year}", produces = "application/json")
    @ResponseBody
    public MonthlyMotionDetectionCount getMonthlyFloorMotionDetectionCount(
            @PathVariable long floorId,
            @PathVariable String blockNO,
            @PathVariable int month,
            @PathVariable int year) {
        return compositeLightAnalyticService.getFloorMotionEventCount(floorId, blockNO, month, year);
    }

    @GetMapping(path = "/motion/floorId/{floorId}/blockNO/{blockNO}/year/{year}", produces = "application/json")
    @ResponseBody
    public YearlyMotionDetectionCount getYearlyFloorMotionDetectionCount(
            @PathVariable long floorId,
            @PathVariable String blockNO,
            @PathVariable int year) {
        return compositeLightAnalyticService.getFloorMotionEventCount(floorId, blockNO, year);
    }

}
