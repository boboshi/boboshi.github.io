package com.aztech.light.analytic.service.impl;

import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.entity.MotionDetectionEvent;
import com.aztech.light.analytic.entity.SmartLight;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.exception.EnergyConsumptionNotFoundException;
import com.aztech.light.analytic.exception.MotionEventCountNotFoundException;
import com.aztech.light.analytic.model.DailyMotionDetectionCount;
import com.aztech.light.analytic.model.LightScopeCategory;
import com.aztech.light.analytic.model.MonthlyMotionDetectionCount;
import com.aztech.light.analytic.model.YearlyMotionDetectionCount;
import com.aztech.light.analytic.repository.DailyEnergyConsumptionRepository;
import com.aztech.light.analytic.repository.MonthlyEnergyConsumptionRepository;
import com.aztech.light.analytic.repository.MotionDetectionEventRepository;
import com.aztech.light.analytic.repository.YearlyEnergyConsumptionRepository;
import com.aztech.light.analytic.service.LightAnalyticService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;

import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

@Service
public class LightAnalyticServiceImpl implements LightAnalyticService {
    final Logger log = LoggerFactory.getLogger(LightAnalyticServiceImpl.class);

    private DailyEnergyConsumptionRepository dailyEnergyConsumptionRepository;
    private MonthlyEnergyConsumptionRepository monthlyEnergyConsumptionRepository;
    private YearlyEnergyConsumptionRepository yearlyEnergyConsumptionRepository;
    private MotionDetectionEventRepository motionDetectionEventRepository;

    public LightAnalyticServiceImpl(
            DailyEnergyConsumptionRepository dailyEnergyConsumptionRepository,
            MonthlyEnergyConsumptionRepository monthlyEnergyConsumptionRepository,
            YearlyEnergyConsumptionRepository yearlyEnergyConsumptionRepository,
            MotionDetectionEventRepository motionDetectionEventRepository) {
        this.dailyEnergyConsumptionRepository = dailyEnergyConsumptionRepository;
        this.monthlyEnergyConsumptionRepository = monthlyEnergyConsumptionRepository;
        this.yearlyEnergyConsumptionRepository = yearlyEnergyConsumptionRepository;
        this.motionDetectionEventRepository = motionDetectionEventRepository;
    }

    @Override
    public MonthlyEnergyConsumption getLightEnergyConsumption(String lightId, int month, int year) {
        return monthlyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportMonthAndReportYear(LightScopeCategory.LIGHT, lightId, month, year)
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(lightId, month, year));
    }

    @Override
    public YearlyEnergyConsumption getLightEnergyConsumption(String lightId, int year) {
        return yearlyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportYear(LightScopeCategory.LIGHT, lightId, year)
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(lightId, year));
    }

    @Override
    public DailyEnergyConsumption getLightEnergyConsumption(String lightId, int day, int month, int year) {
        return dailyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportDate(LightScopeCategory.LIGHT, lightId, makeDate(day, month, year))
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(lightId, day, month, year));
    }

    @Override
    public DailyEnergyConsumption getFloorEnergyConsumption(String floorId, int day, int month, int year) {
        return dailyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportDate(LightScopeCategory.FLOOR, floorId, makeDate(day, month, year))
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(floorId, day, month, year));
    }

    @Override
    public MonthlyEnergyConsumption getFloorEnergyConsumption(String floorId, int month, int year) {
        return monthlyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportMonthAndReportYear(LightScopeCategory.FLOOR, floorId, month, year)
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(floorId, month, year));
    }

    @Override
    public YearlyEnergyConsumption getFloorEnergyConsumption(String floorId, int year) {
        return yearlyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportYear(LightScopeCategory.FLOOR, floorId, year)
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(floorId, year));
    }

    @Override
    public DailyEnergyConsumption getBlockEnergyConsumption(String blockId, int day, int month, int year) {
        return dailyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportDate(LightScopeCategory.BLOCK, blockId, makeDate(day, month, year))
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(blockId, day, month, year));
    }

    @Override
    public MonthlyEnergyConsumption getBlockEnergyConsumption(String blockId, int month, int year) {
        return monthlyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportMonthAndReportYear(LightScopeCategory.BLOCK, blockId, month, year)
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(blockId, month, year));
    }

    @Override
    public YearlyEnergyConsumption getBlockEnergyConsumption(String blockId, int year) {
        return yearlyEnergyConsumptionRepository
                .findByDataTypeAndDataIdAndReportYear(LightScopeCategory.BLOCK, blockId, year)
                .orElseThrow(() -> new EnergyConsumptionNotFoundException(blockId, year));
    }

    @Override
    public DailyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int day, int month, int year) {
        return queryDailyMotionDetectionCount(
                day, month, year,
                (startDateTime, endDateTime) -> motionDetectionEventRepository
                        .findByDetectedStatusGreaterThanEqualAndLightSNAndBlockNOAndReportDateTimeBetween(1, lightId, blockId, startDateTime, endDateTime));
    }

    @Override
    public MonthlyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int month, int year) {
        return queryMonthlyMotionDetectionCount(
                month, year,
                (startDateTime, endDateTime) ->
                        motionDetectionEventRepository
                                .findByDetectedStatusGreaterThanEqualAndLightSNAndBlockNOAndReportDateTimeBetween(1, lightId, blockId, startDateTime, endDateTime)
        );
    }

    @Override
    public YearlyMotionDetectionCount getLightMotionEventCount(String lightId, String blockId, int year) {
        return queryYearlyMotionDetectionCount(
                year,
                (startDateTime, endDateTime) -> motionDetectionEventRepository
                        .findByDetectedStatusGreaterThanEqualAndLightSNAndBlockNOAndReportDateTimeBetween(1, lightId, blockId, startDateTime, endDateTime));
    }

    @Override
    public DailyMotionDetectionCount getBlockMotionEventCount(String blockId, int day, int month, int year) {
        return queryDailyMotionDetectionCount(
                day, month, year,
                (startDateTime, endDateTime) -> motionDetectionEventRepository
                        .findByDetectedStatusGreaterThanEqualAndBlockNOAndReportDateTimeBetween(1, blockId, startDateTime, endDateTime));
    }

    @Override
    public MonthlyMotionDetectionCount getBlockMotionEventCount(String blockId, int month, int year) {
        return queryMonthlyMotionDetectionCount(
                month, year,
                (startDateTime, endDateTime) -> motionDetectionEventRepository.findByDetectedStatusGreaterThanEqualAndBlockNOAndReportDateTimeBetween(1, blockId, startDateTime, endDateTime)
        );
    }

    @Override
    public YearlyMotionDetectionCount getBlockMotionEventCount(String blockId, int year) {
        return queryYearlyMotionDetectionCount(
                year,
                (startDateTime, endDateTime) -> motionDetectionEventRepository
                        .findByDetectedStatusGreaterThanEqualAndBlockNOAndReportDateTimeBetween(1, blockId, startDateTime, endDateTime)
        );
    }

    @Override
    public DailyMotionDetectionCount getFloorMotionEventCount(List<SmartLight> smartLightList, String blockNO, int day, int month, int year) {
        return queryDailyMotionDetectionCount(
                day, month, year,
                (startDateTime, endDateTime) ->
                        motionDetectionEventRepository.findByLightSNInAndBlockNOAndReportDateTimeBetween(
                                smartLightList.stream().map(SmartLight::getLightSN).collect(toList()),
                                blockNO,
                                startDateTime,
                                endDateTime));
    }

    @Override
    public MonthlyMotionDetectionCount getFloorMotionEventCount(List<SmartLight> smartLightList, String blockNO, int month, int year) {
        return queryMonthlyMotionDetectionCount(
                month, year, (startDateTime, endDateTime) ->
                        motionDetectionEventRepository.findByLightSNInAndBlockNOAndReportDateTimeBetween(
                                smartLightList.stream().map(SmartLight::getLightSN).collect(toList()),
                                blockNO,
                                startDateTime,
                                endDateTime));
    }

    @Override
    public YearlyMotionDetectionCount getFloorMotionEventCount(List<SmartLight> smartLightList, String blockNO, int year) {
        return queryYearlyMotionDetectionCount(
                year, (startDateTime, endDateTime) ->
                        motionDetectionEventRepository.findByLightSNInAndBlockNOAndReportDateTimeBetween(
                                smartLightList.stream().map(SmartLight::getLightSN).collect(toList()),
                                blockNO,
                                startDateTime,
                                endDateTime));
    }

    private DailyMotionDetectionCount queryDailyMotionDetectionCount(
            int day, int month, int year,
            BiFunction<LocalDateTime, LocalDateTime, List<MotionDetectionEvent>> supplier) {

        LocalDateTime startDateTime = LocalDateTime.of(year, month, day, 0, 0, 0);
        LocalDateTime endDateTime = LocalDateTime.of(year, month, day, 23, 59, 59);

        final List<MotionDetectionEvent> events = supplier.apply(startDateTime, endDateTime);

        log.info("queryDailyMotionDetectionCount processes {} rows for {} and {} (daily)", events.size(), startDateTime, endDateTime);

        if (events.size() < 1) throw new MotionEventCountNotFoundException(day, month, year);

        final Map<String, Long> eventCountMap = events.stream()
                .map(this::toEventCountHourGroup)
                .collect(groupingBy(g -> g, counting()));

        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(eventCountMap, DailyMotionDetectionCount.class);
    }

    private MonthlyMotionDetectionCount queryMonthlyMotionDetectionCount(
            int month, int year,
            BiFunction<LocalDateTime, LocalDateTime, List<MotionDetectionEvent>> supplier) {

        LocalDateTime startDateTime = LocalDateTime.of(year, month, 1, 0, 0, 0);
        final int lastDayOfMonth = startDateTime.toLocalDate().getMonth().length(startDateTime.toLocalDate().isLeapYear());
        LocalDateTime endDateTime = LocalDateTime.of(year, month, lastDayOfMonth, 23, 59, 59);

        final List<MotionDetectionEvent> events = supplier.apply(startDateTime, endDateTime);

        log.info("queryMonthlyMotionDetectionCount processes {} rows for {} and {} (monthly)", events.size(), startDateTime, endDateTime);

        if (events.size() < 1) throw new MotionEventCountNotFoundException(month, year);

        final Map<String, Long> eventCountMap = events.stream()
                .map(this::toEventCountDateGroup)
                .collect(groupingBy(g -> g, counting()));

        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(eventCountMap, MonthlyMotionDetectionCount.class);
    }

    private YearlyMotionDetectionCount queryYearlyMotionDetectionCount(
            int year, BiFunction<LocalDateTime, LocalDateTime, List<MotionDetectionEvent>> supplier) {

        LocalDateTime startDateTime = LocalDateTime.of(year, 1, 1, 0, 0, 0);
        LocalDateTime endDateTime = LocalDateTime.of(year, 12, 31, 23, 59, 59);

        final List<MotionDetectionEvent> events = supplier.apply(startDateTime, endDateTime);

        log.info("queryYearlyMotionDetectionCount returns {} rows for {} and {} (yearly)", events.size(), startDateTime, endDateTime);

        if (events.size() < 1) throw new MotionEventCountNotFoundException(year);

        final Map<String, Long> eventCountMap = events.stream()
                .map(this::toEventCountMonthGroup)
                .collect(groupingBy(g -> g, counting()));

        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(eventCountMap, YearlyMotionDetectionCount.class);
    }

    private String toEventCountMonthGroup(MotionDetectionEvent event) {
        return String.format("monthPIRDetectNumber%d", event.getReportDateTime().getMonthValue());
    }

    private String toEventCountDateGroup(MotionDetectionEvent event) {
        return String.format("dayPIRDetectNumber%d", event.getReportDateTime().getDayOfMonth());
    }

    private String toEventCountHourGroup(MotionDetectionEvent event) {
        return String.format("hourPIRDetectNumber%d", event.getReportDateTime().getHour() + 1);
    }

    private LocalDate makeDate(int day, int month, int year) {
        return LocalDate.of(year, month, day);
    }
}
