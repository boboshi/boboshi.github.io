package com.aztech.light.analytic.entity.mapper;

import org.mapstruct.Mapper;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Mapper(componentModel = "spring")
public abstract class LocalDateMapper {
    public String toDateString(LocalDate localDate) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("YYYY-MM-dd");
        return localDate.format(dateTimeFormatter);
    }

    public LocalDate fromDateString(String dateString) {
        return LocalDate.parse(dateString);
    }
}
