package com.aztech.light.analytic.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "smartLight")
public class SmartLight {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "lightId")
    private Long id;

    @Column(name = "displayName")
    private String lightSN;

    private long floorId;
}
