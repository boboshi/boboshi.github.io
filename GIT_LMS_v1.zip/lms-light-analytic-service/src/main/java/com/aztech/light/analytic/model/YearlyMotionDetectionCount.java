package com.aztech.light.analytic.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(force = true)
public class YearlyMotionDetectionCount {
    private long monthPIRDetectNumber1;
    private long monthPIRDetectNumber2;
    private long monthPIRDetectNumber3;
    private long monthPIRDetectNumber4;
    private long monthPIRDetectNumber5;
    private long monthPIRDetectNumber6;
    private long monthPIRDetectNumber7;
    private long monthPIRDetectNumber8;
    private long monthPIRDetectNumber9;
    private long monthPIRDetectNumber10;
    private long monthPIRDetectNumber11;
    private long monthPIRDetectNumber12;
}
