package com.aztech.light.analytic.model;

import com.aztech.light.analytic.exception.LightScopeCategoryNotFoundException;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.stream.Stream;

@Converter(autoApply = true)
public class LightScopeCategoryConverter implements AttributeConverter<LightScopeCategory, Integer> {
    @Override
    public Integer convertToDatabaseColumn(LightScopeCategory lightScopeCategory) {
        return lightScopeCategory.getScopeValue();
    }

    @Override
    public LightScopeCategory convertToEntityAttribute(Integer scopeValue) {
        return Stream.of(LightScopeCategory.values())
                .filter(v -> v.getScopeValue() == scopeValue)
                .findFirst()
                .orElseThrow(() -> new LightScopeCategoryNotFoundException(scopeValue));
    }
}
