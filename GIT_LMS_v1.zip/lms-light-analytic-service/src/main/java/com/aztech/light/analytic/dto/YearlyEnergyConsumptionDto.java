package com.aztech.light.analytic.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class YearlyEnergyConsumptionDto {
    private int reportYear;
    private float monthEnergy1;
    private float monthEnergy2;
    private float monthEnergy3;
    private float monthEnergy4;
    private float monthEnergy5;
    private float monthEnergy6;
    private float monthEnergy7;
    private float monthEnergy8;
    private float monthEnergy9;
    private float monthEnergy10;
    private float monthEnergy11;
    private float monthEnergy12;
}
