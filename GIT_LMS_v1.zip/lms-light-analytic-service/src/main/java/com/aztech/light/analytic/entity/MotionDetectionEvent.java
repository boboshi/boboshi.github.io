package com.aztech.light.analytic.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@Entity
@Table(name = "motionDetect")
public class MotionDetectionEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long motionDetectId;
    private int detectedStatus;
    private LocalDateTime reportDateTime;
    private LocalDateTime serverDateTime;
    private String lightSN;
    private String blockNO;
}
