package com.aztech.light.analytic.service;

import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.entity.MotionDetectionEvent;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.exception.EnergyConsumptionNotFoundException;
import com.aztech.light.analytic.repository.DailyEnergyConsumptionRepository;
import com.aztech.light.analytic.repository.MonthlyEnergyConsumptionRepository;
import com.aztech.light.analytic.repository.MotionDetectionEventRepository;
import com.aztech.light.analytic.repository.YearlyEnergyConsumptionRepository;
import com.aztech.light.analytic.service.impl.LightAnalyticServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class LightAnalyticServiceTest {
    private DailyEnergyConsumptionRepository dailyEnergyConsumptionRepository = null;
    private MonthlyEnergyConsumptionRepository monthlyEnergyConsumptionRepository = null;
    private YearlyEnergyConsumptionRepository yearlyEnergyConsumptionRepository = null;
    private MotionDetectionEventRepository motionDetectionEventRepository = null;
    private LightAnalyticService service = null;

    @BeforeEach
    public void initializeService() {
        monthlyEnergyConsumptionRepository = mock(MonthlyEnergyConsumptionRepository.class);
        dailyEnergyConsumptionRepository = mock(DailyEnergyConsumptionRepository.class);
        yearlyEnergyConsumptionRepository = mock(YearlyEnergyConsumptionRepository.class);
        motionDetectionEventRepository = mock(MotionDetectionEventRepository.class);
        service = new LightAnalyticServiceImpl(
                dailyEnergyConsumptionRepository,
                monthlyEnergyConsumptionRepository,
                yearlyEnergyConsumptionRepository,
                motionDetectionEventRepository);
    }

    @Test
    public void testGetDailyLightEnergyConsumption() {
        when(dailyEnergyConsumptionRepository.findByDataTypeAndDataIdAndReportDate(any(), anyString(),any(LocalDate.class)))
                .thenReturn(Optional.of(new DailyEnergyConsumption()));

        assertDoesNotThrow(() -> service.getLightEnergyConsumption("1", 1, 12, 2020));
    }

    @Test
    public void testGetDailyLightEnergyConsumptionWithException() {
        when(dailyEnergyConsumptionRepository.findByDataTypeAndDataIdAndReportDate(any(), anyString(),any(LocalDate.class)))
                .thenReturn(Optional.empty());

        assertThrows(EnergyConsumptionNotFoundException.class, () -> service.getLightEnergyConsumption("1", 1, 12, 2020));
    }

    @Test
    public void testGetMonthlyLightEnergyConsumption() {
        when(monthlyEnergyConsumptionRepository.findByDataTypeAndDataIdAndReportMonthAndReportYear(any(), anyString(), anyInt(), anyInt()))
                .thenReturn(Optional.of(new MonthlyEnergyConsumption()));

        assertDoesNotThrow(() -> service.getLightEnergyConsumption("1",12,2020));
    }

    @Test
    public void testGetMonthlyLightEnergyConsumptionWithException() {
        when(monthlyEnergyConsumptionRepository.findByDataTypeAndDataIdAndReportMonthAndReportYear(any(), anyString(), anyInt(), anyInt()))
                .thenReturn(Optional.empty());

        assertThrows(EnergyConsumptionNotFoundException.class, () -> service.getLightEnergyConsumption("1",12,2020));
    }

    @Test
    public void testGetYearlyLightEnergyConsumption() {
        when(yearlyEnergyConsumptionRepository.findByDataTypeAndDataIdAndReportYear(any(), anyString(), anyInt()))
                .thenReturn(Optional.of(new YearlyEnergyConsumption()));

        assertDoesNotThrow(() -> service.getLightEnergyConsumption("1",2020));
    }

    @Test
    public void testGetYearlyLightEnergyConsumptionWithException() {
        when(yearlyEnergyConsumptionRepository.findByDataTypeAndDataIdAndReportYear(any(), anyString(), anyInt()))
                .thenReturn(Optional.empty());

        assertThrows(EnergyConsumptionNotFoundException.class, () -> service.getLightEnergyConsumption("1", 2020));
    }

}
