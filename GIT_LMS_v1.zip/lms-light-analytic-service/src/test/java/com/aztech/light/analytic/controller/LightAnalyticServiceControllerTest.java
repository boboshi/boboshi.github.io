package com.aztech.light.analytic.controller;

import com.aztech.light.analytic.controller.configuration.ControllerTestConfiguration;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.service.CompositeLightAnalyticService;
import com.aztech.light.analytic.utils.DataGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@WebMvcTest(LightAnalyticServiceController.class)
@Import(ControllerTestConfiguration.class)
public class LightAnalyticServiceControllerTest {
    @Autowired
    private MockMvc mvc;

    @MockBean
    private CompositeLightAnalyticService compositeLightAnalyticService;

    @Test
    public void testGetMonthlyEnergyConsumption() throws Exception {
        DataGenerator dataGenerator = new DataGenerator();
        List<MonthlyEnergyConsumption> mockedData = dataGenerator.getMonthlyData();
        when(compositeLightAnalyticService.getLightEnergyConsumption(anyString(), anyInt(), anyInt())).thenReturn(mockedData.get(0));

        mvc.perform(get("/api/light-analytic/energy/lightId/1/month/1/year/2018").accept("application/json"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
