package com.aztech.light.analytic.controller.configuration;

import com.aztech.light.analytic.entity.mapper.DailyEnergyConsumptionMapper;
import com.aztech.light.analytic.entity.mapper.DailyEnergyConsumptionMapperImpl;
import com.aztech.light.analytic.entity.mapper.LocalDateMapper;
import com.aztech.light.analytic.entity.mapper.LocalDateMapperImpl;
import com.aztech.light.analytic.entity.mapper.MonthlyEnergyConsumptionMapper;
import com.aztech.light.analytic.entity.mapper.MonthlyEnergyConsumptionMapperImpl;
import com.aztech.light.analytic.entity.mapper.YearlyEnergyConsumptionMapper;
import com.aztech.light.analytic.entity.mapper.YearlyEnergyConsumptionMapperImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ControllerTestConfiguration {
    @Bean
    public MonthlyEnergyConsumptionMapper monthlyEnergyConsumptionMapper() {
        return new MonthlyEnergyConsumptionMapperImpl();
    }

    @Bean
    public YearlyEnergyConsumptionMapper yearlyEnergyConsumptionMapper() {
        return new YearlyEnergyConsumptionMapperImpl();
    }

    @Bean
    public DailyEnergyConsumptionMapper dailyEnergyConsumptionMapper() {
        return new DailyEnergyConsumptionMapperImpl();
    }

    @Bean
    public LocalDateMapper localDateMapper() {
        return new LocalDateMapperImpl();
    }
}
