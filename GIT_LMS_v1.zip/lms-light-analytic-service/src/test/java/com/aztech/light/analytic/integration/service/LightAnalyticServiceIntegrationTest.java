package com.aztech.light.analytic.integration.service;

import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.repository.DailyEnergyConsumptionRepository;
import com.aztech.light.analytic.repository.MonthlyEnergyConsumptionRepository;
import com.aztech.light.analytic.repository.YearlyEnergyConsumptionRepository;
import com.aztech.light.analytic.service.LightAnalyticService;
import com.aztech.light.analytic.service.impl.LightAnalyticServiceImpl;
import com.aztech.light.analytic.utils.DataGenerator;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

//@DataJpaTest
public class LightAnalyticServiceIntegrationTest {
    @Autowired
    private TestEntityManager testEntityManager;

    @Autowired
    private DailyEnergyConsumptionRepository dailyEnergyConsumptionRepository;

    @Autowired
    private MonthlyEnergyConsumptionRepository monthlyEnergyConsumptionRepository;

    @Autowired
    private YearlyEnergyConsumptionRepository yearlyEnergyConsumptionRepository;


    @Test
    @Disabled
    public void testGetMonthlyEnergyConsumption() {
//        DataGenerator dataGenerator = new DataGenerator();
//        List<MonthlyEnergyConsumption> mockedData = dataGenerator.getMonthlyData();
//        mockedData.iterator().forEachRemaining(d -> testEntityManager.persist(d));
//        LightAnalyticService service = new LightAnalyticServiceImpl(
//                dailyEnergyConsumptionRepository,
//                monthlyEnergyConsumptionRepository,
//                yearlyEnergyConsumptionRepository);
//
//        final MonthlyEnergyConsumption monthlyEnergyConsumptions =
//                service.getLightEnergyConsumption(
//                        mockedData.get(0).getDataId(),
//                        mockedData.get(0).getReportMonth(),
//                        mockedData.get(0).getReportYear());
//
//        assertEquals(mockedData.get(0).getDataId(), monthlyEnergyConsumptions.getDataId());
//        assertEquals(mockedData.get(0).getReportMonth(), monthlyEnergyConsumptions.getReportMonth());
//        assertEquals(mockedData.get(0).getReportYear(), monthlyEnergyConsumptions.getReportYear());
    }
}
