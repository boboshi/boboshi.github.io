package com.aztech.light.analytic.utils;

import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.model.LightScopeCategory;

import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.toList;

public class DataGenerator {
    public List<MonthlyEnergyConsumption> getMonthlyData() {
        Random generator = new Random(1);
        return IntStream.rangeClosed(1, 3)
                .mapToObj(i -> makeMonthlyEnergyConsumption(i, generator))
                .collect(toList());
    }

    private MonthlyEnergyConsumption makeMonthlyEnergyConsumption(int index, Random generator) {
        MonthlyEnergyConsumption data = new MonthlyEnergyConsumption();
        data.setDayEnergy1(generator.nextDouble());
        data.setDayEnergy2(generator.nextDouble());
        data.setDayEnergy3(generator.nextDouble());
        data.setDayEnergy4(generator.nextDouble());
        data.setDayEnergy5(generator.nextDouble());
        data.setDayEnergy6(generator.nextDouble());
        data.setDayEnergy7(generator.nextDouble());
        data.setDayEnergy8(generator.nextDouble());
        data.setDayEnergy9(generator.nextDouble());
        data.setDayEnergy10(generator.nextDouble());
        data.setDayEnergy11(generator.nextDouble());
        data.setDayEnergy12(generator.nextDouble());
        data.setDayEnergy13(generator.nextDouble());
        data.setDayEnergy14(generator.nextDouble());
        data.setDayEnergy15(generator.nextDouble());
        data.setDayEnergy16(generator.nextDouble());
        data.setDayEnergy17(generator.nextDouble());
        data.setDayEnergy18(generator.nextDouble());
        data.setDayEnergy19(generator.nextDouble());
        data.setDayEnergy20(generator.nextDouble());
        data.setDayEnergy21(generator.nextDouble());
        data.setDayEnergy22(generator.nextDouble());
        data.setDayEnergy23(generator.nextDouble());
        data.setDayEnergy24(generator.nextDouble());
        data.setDayEnergy25(generator.nextDouble());
        data.setDayEnergy26(generator.nextDouble());
        data.setDayEnergy27(generator.nextDouble());
        data.setDayEnergy28(generator.nextDouble());
        data.setDayEnergy29(generator.nextDouble());
        data.setDayEnergy30(generator.nextDouble());
        data.setDayEnergy31(generator.nextDouble());
        data.setDataId(String.valueOf(index));
        data.setDataType(LightScopeCategory.LIGHT);
        data.setReportMonth(index);
        data.setReportYear(2018 + index);
        return data;
    }
}
