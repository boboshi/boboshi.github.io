package com.aztech.light.analytic.service;

import com.aztech.light.analytic.entity.DailyEnergyConsumption;
import com.aztech.light.analytic.entity.MonthlyEnergyConsumption;
import com.aztech.light.analytic.entity.YearlyEnergyConsumption;
import com.aztech.light.analytic.service.impl.CompositeLightAnalyticServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;


public class CompositeLightAnalyticServiceTest {
    LightAnalyticCacheService lightAnalyticCacheService = null;
    LightAnalyticService lightAnalyticService = null;
    SmartLightService smartLightService = null;
    CompositeLightAnalyticService service = null;

    @BeforeEach
    public void initializeService() {
        lightAnalyticCacheService = mock(LightAnalyticCacheService.class);
        lightAnalyticService = mock(LightAnalyticService.class);
        smartLightService = mock(SmartLightService.class);
        service = new CompositeLightAnalyticServiceImpl(lightAnalyticCacheService, lightAnalyticService, smartLightService);
    }

    @Test
    public void testGetLightEnergyConsumptionWithEmptyCacheForDaily() {
        when(lightAnalyticCacheService.getLightEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getLightEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt())).thenReturn(new DailyEnergyConsumption());
        service.getLightEnergyConsumption("1",1,12, 2020);
        verify(lightAnalyticService, times(1)).getLightEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putLightEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt(), any(DailyEnergyConsumption.class));
    }

    @Test
    public void testGetLightEnergyConsumptionWithNonEmptyCacheForDaily() {
        when(lightAnalyticCacheService.getLightEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt()))
                .thenReturn(Optional.of(new DailyEnergyConsumption()));
        service.getLightEnergyConsumption("1",1,12,2020);
        verifyNoInteractions(lightAnalyticService);
    }

    @Test
    public void testGetLightEnergyConsumptionWithEmptyCacheForMonthly() {
        when(lightAnalyticCacheService.getLightEnergyConsumption(anyString(), anyInt(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getLightEnergyConsumption(anyString(), anyInt(), anyInt())).thenReturn(new MonthlyEnergyConsumption());
        service.getLightEnergyConsumption("1",12, 2020);
        verify(lightAnalyticService, times(1)).getLightEnergyConsumption(anyString(), anyInt(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putLightEnergyConsumption(anyString(), anyInt(), anyInt(), any(MonthlyEnergyConsumption.class));
    }

    @Test
    public void testGetLightEnergyConsumptionWithNonEmptyCacheForMonthly() {
        when(lightAnalyticCacheService.getLightEnergyConsumption(anyString(), anyInt(), anyInt()))
                .thenReturn(Optional.of(new MonthlyEnergyConsumption()));
        service.getLightEnergyConsumption("1",12,2020);
        verifyNoInteractions(lightAnalyticService);
    }

    @Test
    public void testGetLightEnergyConsumptionWithEmptyCacheForYearly() {
        when(lightAnalyticCacheService.getLightEnergyConsumption(anyString(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getLightEnergyConsumption(anyString(), anyInt())).thenReturn(new YearlyEnergyConsumption());
        service.getLightEnergyConsumption("1", 2020);
        verify(lightAnalyticService, times(1)).getLightEnergyConsumption(anyString(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putLightEnergyConsumption(anyString(), anyInt(), any(YearlyEnergyConsumption.class));
    }

    @Test
    public void testGetLightEnergyConsumptionWithNonEmptyCacheForYearly() {
        when(lightAnalyticCacheService.getLightEnergyConsumption(anyString(), anyInt()))
                .thenReturn(Optional.of(new YearlyEnergyConsumption()));
        service.getLightEnergyConsumption("1", 2020);
        verifyNoInteractions(lightAnalyticService);
    }

    @Test
    public void testGetFloorEnergyConsumptionWithEmptyCacheForDaily() {
        when(lightAnalyticCacheService.getFloorEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getFloorEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt())).thenReturn(new DailyEnergyConsumption());
        service.getFloorEnergyConsumption("1",1,12, 2020);
        verify(lightAnalyticService, times(1)).getFloorEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putFloorEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt(), any(DailyEnergyConsumption.class));
    }

    @Test
    public void testGetFloorEnergyConsumptionWithNonEmptyCacheForDaily() {
        when(lightAnalyticCacheService.getFloorEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt()))
                .thenReturn(Optional.of(new DailyEnergyConsumption()));
        service.getFloorEnergyConsumption("1",1,12, 2020);
        verifyNoInteractions(lightAnalyticService);
    }

    @Test
    public void testGetFloorEnergyConsumptionWithEmptyCacheForMonthly() {
        when(lightAnalyticCacheService.getFloorEnergyConsumption(anyString(), anyInt(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getFloorEnergyConsumption(anyString(), anyInt(), anyInt())).thenReturn(new MonthlyEnergyConsumption());
        service.getFloorEnergyConsumption("1",12, 2020);
        verify(lightAnalyticService, times(1)).getFloorEnergyConsumption(anyString(), anyInt(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putFloorEnergyConsumption(anyString(), anyInt(), anyInt(), any(MonthlyEnergyConsumption.class));
    }

    @Test
    public void testGetFloorEnergyConsumptionWithNonEmptyCacheForMonthly() {
        when(lightAnalyticCacheService.getFloorEnergyConsumption(anyString(), anyInt(), anyInt()))
                .thenReturn(Optional.of(new MonthlyEnergyConsumption()));
        service.getFloorEnergyConsumption("1",12, 2020);
        verifyNoInteractions(lightAnalyticService);
    }

    @Test
    public void testGetFloorEnergyConsumptionWithEmptyCacheForYearly() {
        when(lightAnalyticCacheService.getFloorEnergyConsumption(anyString(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getFloorEnergyConsumption(anyString(), anyInt())).thenReturn(new YearlyEnergyConsumption());
        service.getFloorEnergyConsumption("1", 2020);
        verify(lightAnalyticService, times(1)).getFloorEnergyConsumption(anyString(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putFloorEnergyConsumption(anyString(), anyInt(), any(YearlyEnergyConsumption.class));
    }

    @Test
    public void testGetFloorEnergyConsumptionWithNonEmptyCacheForYearly() {
        when(lightAnalyticCacheService.getFloorEnergyConsumption(anyString(), anyInt()))
                .thenReturn(Optional.of(new YearlyEnergyConsumption()));
        service.getFloorEnergyConsumption("1", 2020);
        verifyNoInteractions(lightAnalyticService);
    }

    @Test
    public void testGetBlockEnergyConsumptionWithEmptyCacheForDaily() {
        when(lightAnalyticCacheService.getBlockEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getBlockEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt())).thenReturn(new DailyEnergyConsumption());
        service.getBlockEnergyConsumption("1",1,12,2020);
        verify(lightAnalyticService, times(1)).getBlockEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putBlockEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt(), any(DailyEnergyConsumption.class));
    }

    @Test
    public void testGetBlockEnergyConsumptionWithNonEmptyCacheForDaily() {
        when(lightAnalyticCacheService.getBlockEnergyConsumption(anyString(), anyInt(), anyInt(), anyInt()))
                .thenReturn(Optional.of(new DailyEnergyConsumption()));
        service.getBlockEnergyConsumption("1",1,12,2020);
        verifyNoInteractions(lightAnalyticService);
    }

    @Test
    public void testGetBlockEnergyConsumptionWithEmptyCacheForMonthly() {
        when(lightAnalyticCacheService.getBlockEnergyConsumption(anyString(), anyInt(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getBlockEnergyConsumption(anyString(), anyInt(), anyInt())).thenReturn(new MonthlyEnergyConsumption());
        service.getBlockEnergyConsumption("1",12,2020);
        verify(lightAnalyticService, times(1)).getBlockEnergyConsumption(anyString(), anyInt(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putBlockEnergyConsumption(anyString(), anyInt(), anyInt(), any(MonthlyEnergyConsumption.class));
    }

    @Test
    public void testGetBlockEnergyConsumptionWithNonEmptyCacheForMonthly() {
        when(lightAnalyticCacheService.getBlockEnergyConsumption(anyString(), anyInt(), anyInt()))
                .thenReturn(Optional.of(new MonthlyEnergyConsumption()));
        service.getBlockEnergyConsumption("1",12,2020);
        verifyNoInteractions(lightAnalyticService);
    }

    @Test
    public void testGetBlockEnergyConsumptionWithEmptyCacheForYearly() {
        when(lightAnalyticCacheService.getBlockEnergyConsumption(anyString(), anyInt())).thenReturn(Optional.empty());
        when(lightAnalyticService.getBlockEnergyConsumption(anyString(), anyInt())).thenReturn(new YearlyEnergyConsumption());
        service.getBlockEnergyConsumption("1", 2020);
        verify(lightAnalyticService, times(1)).getBlockEnergyConsumption(anyString(), anyInt());
        verify(lightAnalyticCacheService, times(1))
                .putBlockEnergyConsumption(anyString(), anyInt(), any(YearlyEnergyConsumption.class));
    }

    @Test
    public void testGetBlockEnergyConsumptionWithNonEmptyCacheForYearly() {
        when(lightAnalyticCacheService.getBlockEnergyConsumption(anyString(), anyInt()))
                .thenReturn(Optional.of(new YearlyEnergyConsumption()));
        service.getBlockEnergyConsumption("1", 2020);
        verifyNoInteractions(lightAnalyticService);
    }

}
