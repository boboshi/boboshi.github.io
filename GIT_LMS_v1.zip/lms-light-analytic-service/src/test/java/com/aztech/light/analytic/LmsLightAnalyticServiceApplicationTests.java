package com.aztech.light.analytic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class LmsLightAnalyticServiceApplicationTests {

//	@Test
	void contextLoads() {
	}

}
