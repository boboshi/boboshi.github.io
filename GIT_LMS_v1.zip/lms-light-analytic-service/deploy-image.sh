#!/usr/bin/env sh

docker image build --build-arg APP_BIN=lms-light-analytic-service-1.0.0.jar --build-arg SERVER_PORT=8081 --tag lms-light-analytic-service:latest .
docker image tag lms-light-analytic-service:latest aztechsg/lms-light-analytic-service:latest
docker image push aztechsg/lms-light-analytic-service:latest