#!/usr/bin/env sh

docker container run --rm --name maven-build --volume $HOME/.m2:/root/.m2 --volume $(pwd):/app --workdir /app --cpus 2 maven:3.6.3-jdk-8 mvn clean package
