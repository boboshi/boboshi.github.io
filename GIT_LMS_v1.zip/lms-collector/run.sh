#!/usr/bin/env bash

MODULE_NAME=lms-collector
EXECUTABLE_JAR=target/${MODULE_NAME}-0.0.1-SNAPSHOT.jar

if [[ ! -d ./app ]]; then
	mkdir app
fi

./mvnw clean; ./mvnw package; cp ${EXECUTABLE_JAR} app/
docker container rm -f ${MODULE_NAME}
docker container run --name ${MODULE_NAME} --network lms-net -t -p 8080:8080 -v /mnt/c/Users/Derrick.Teh/Projects/${MODULE_NAME}/app:/app ${MODULE_NAME}
