package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.FaultEntity;
import com.aztech.lmscollector.model.ClearFaultEvent;
import com.aztech.lmscollector.model.ClearFaultParameter;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class ClearFaultEventMapperTest {
    @Test
    public void testClearFaultEventToFaultEntity() {
        ClearFaultEvent event = new ClearFaultEvent();
        ClearFaultParameter parameter = new ClearFaultParameter();
        parameter.setReferenceEventId("EV-820421-1.1.73-20200901");
        event.setEventId("EV-820421-1.1.11-20200901");
        event.setParameter(parameter);

        ClearFaultEventMapper mapper = new ClearFaultEventMapperImpl();
        final FaultEntity entity = mapper.toFaultEntity(event);

        assertThat(entity.getEventId(), equalTo("EV-820421-1.1.73-20200901"));
        assertThat(entity.getFaultCleared(), equalTo("EV-820421-1.1.11-20200901"));
    }
}
