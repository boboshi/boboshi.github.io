package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.FaultEntity;
import com.aztech.lmscollector.model.FaultEvent;
import com.aztech.lmscollector.model.FaultParameter;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import java.time.Instant;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class FaultEventMapperTest {
    @Test
    public void testFaultEventToFaultEntity() {
        FaultEvent event = new FaultEvent();
        FaultParameter parameter = new FaultParameter();
        java.util.Date now = java.util.Date.from(Instant.now());
        java.sql.Date sqlNow = new java.sql.Date(now.getTime());
        parameter.setSeverity(1);
        parameter.setTripGeneralAlarm("Yup");
        parameter.setReportedDate(now);
        event.setEventId("1");
        event.setEventType("fault");
        event.setLightId("1.1.1");
        event.setBlockNumber("888111");
        event.setParameter(parameter);
        event.setDescription("Light 1.1.73 Current Error");
        event.setFaultCode("AZ-LS-FC-0003");

        FaultEventMapper mapper = new FaultEventMapperImpl();
        final FaultEntity entity = mapper.toFaultEntity(event);

        assertThat(entity.getBlockNO(), equalTo("888111"));
        assertThat(entity.getLightSN(), equalTo("1.1.1"));
        assertThat(entity.getEventId(), equalTo("1"));
        assertThat(entity.getEventType(), equalTo("fault"));
        assertThat(entity.getSeverity(), equalTo(1));
        assertThat(entity.getTripGeneralAlarm(), equalTo("Yup"));
        assertThat(entity.getDescription(), equalTo("Light 1.1.73 Current Error"));
        assertThat(entity.getFaultCode(), equalTo("AZ-LS-FC-0003"));
        assertThat(entity.getFaultCleared(), equalTo("0"));
        assertThat(entity.getReportDateTime(), equalTo(sqlNow));
    }
}
