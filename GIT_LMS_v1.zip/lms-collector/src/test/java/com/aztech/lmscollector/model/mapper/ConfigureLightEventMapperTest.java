package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.SmartLightEntity;
import com.aztech.lmscollector.model.ConfigureLightEvent;
import com.aztech.lmscollector.model.ConfigureLightParameter;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class ConfigureLightEventMapperTest {
    @Test
    public void testConfigureLightEventToSmartLightEntity() {
        ConfigureLightEvent event = new ConfigureLightEvent();
        ConfigureLightParameter parameter = new ConfigureLightParameter();
        parameter.setCommandType("Set_Ack");
        parameter.setMotionSensing("Yes");
        parameter.setMotionLevel(1);
        parameter.setMotionSensitivity(1);
        parameter.setBrightnessLevel(1);
        parameter.setBrightnessGroup("007");
        parameter.setLightIntensity(1);
        parameter.setDimLevel(1);
        parameter.setPhotoSensorGroup("003");
        parameter.setClockSync("Yes");
        parameter.setHoldTime(1);
        parameter.setScheduling("Yes");
        event.setBlockNumber("888111");
        event.setLightId("1.1.1");
        event.setParameter(parameter);

        ConfigureLightEventMapper mapper = new ConfigureLightEventMapperImpl();
        SmartLightEntity entity = mapper.toSmartLightEntity(event);

        assertThat(entity.getMotionSensing(), equalTo("Yes"));
        assertThat(entity.getMotionLevel(), equalTo(10));
        assertThat(entity.getMotionSensitivity(), equalTo(1));
        assertThat(entity.getBrightLevel(), equalTo(10));
        assertThat(entity.getBrightGroup(), equalTo("007"));
        assertThat(entity.getLightIntensity(), equalTo(1));
        assertThat(entity.getDimLevel(), equalTo(1));
        assertThat(entity.getPhotosensorGroup(), equalTo("003"));
        assertThat(entity.getClockSync(), equalTo("Yes"));
        assertThat(entity.getHoldTime(), equalTo(1));
        assertThat(entity.getScheduling(), equalTo("Yes"));
        assertThat(entity.getBlockNO(), equalTo("888111"));
        assertThat(entity.getLightSN(), equalTo("1.1.1"));

    }
}
