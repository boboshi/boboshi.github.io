package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.MotionDetectionEntity;
import com.aztech.lmscollector.entity.PhotoSensorEntity;
import com.aztech.lmscollector.model.MotionDetectionEvent;
import com.aztech.lmscollector.model.MotionDetectionParameter;
import com.aztech.lmscollector.model.PhotoSensorEvent;
import com.aztech.lmscollector.model.PhotoSensorParameter;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import java.time.Instant;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class PhotoSensorEventMapperTest {
    @Test
    public void testPhotoSensorEventToPhotoSensorEntity() {
        PhotoSensorEvent event = new PhotoSensorEvent();
        PhotoSensorParameter parameter = new PhotoSensorParameter();
        java.util.Date now = java.util.Date.from(Instant.now());
        java.sql.Date sqlNow = new java.sql.Date(now.getTime());
        parameter.setPhotoSensorLevel(1);
        parameter.setReportedDate(now);
        event.setLightId("1.1.1");
        event.setBlockNumber("888111");
        event.setParameter(parameter);

        PhotoSensorEventMapper mapper = new PhotoSensorEventMapperImpl();
        final PhotoSensorEntity entity = mapper.toPhotoSensorEntity(event);

        assertThat(entity.getBlockNO(), equalTo("888111"));
        assertThat(entity.getLightSN(), equalTo("1.1.1"));
        assertThat(entity.getPhotosensorLevel(), equalTo(1));
        assertThat(entity.getReportDateTime(), equalTo(sqlNow));

    }
}
