package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.SmartLightEntity;
import com.aztech.lmscollector.model.FirmwareEvent;
import com.aztech.lmscollector.model.FirmwareParameter;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class FirmwareEventMapperTest {

    @Test
    public void testFirmwareEventToSmartLightEntity() {
        FirmwareEvent event = new FirmwareEvent();
        FirmwareParameter parameter = new FirmwareParameter();
        parameter.setFirmwareVersion("2.2.2");
        event.setLightId("1.1.1");
        event.setBlockNumber("888111");
        event.setParameter(parameter);

        FirmwareEventMapper mapper = new FirmwareEventMapperImpl();
        final SmartLightEntity entity = mapper.toSmartLightEntity(event);

        assertThat(entity.getBlockNO(), equalTo("888111"));
        assertThat(entity.getLightSN(), equalTo("1.1.1"));
        assertThat(entity.getFirmware(), equalTo("2.2.2"));
    }
}
