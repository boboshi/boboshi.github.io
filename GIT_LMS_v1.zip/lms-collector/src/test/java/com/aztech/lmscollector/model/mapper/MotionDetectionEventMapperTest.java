package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.MotionDetectionEntity;
import com.aztech.lmscollector.model.MotionDetectionEvent;
import com.aztech.lmscollector.model.MotionDetectionParameter;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import java.time.Instant;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class MotionDetectionEventMapperTest {
    @Test
    public void testMotionDetectionEventToMotionDetectionEntity() {
        MotionDetectionEvent event = new MotionDetectionEvent();
        MotionDetectionParameter parameter = new MotionDetectionParameter();
        java.util.Date now = java.util.Date.from(Instant.now());
        java.sql.Date sqlNow = new java.sql.Date(now.getTime());
        parameter.setDetectedStatus(1);
        parameter.setReportedDate(now);
        event.setLightId("1.1.1");
        event.setBlockNumber("888111");
        event.setParameter(parameter);

        MotionDetectionEventMapper mapper = new MotionDetectionEventMapperImpl();
        MotionDetectionEntity entity = mapper.toMotionDetectionEntity(event);

        assertThat(entity.getBlockNO(), equalTo("888111"));
        assertThat(entity.getLightSN(), equalTo("1.1.1"));
        assertThat(entity.getDetectedStatus(), equalTo(1));
        assertThat(entity.getReportDateTime(), equalTo(sqlNow));

    }
}
