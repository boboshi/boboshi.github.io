package com.aztech.lmscollector.service;

import com.aztech.lmscollector.model.ClearFaultEvent;
import com.aztech.lmscollector.model.ConfigureLightEvent;
import com.aztech.lmscollector.model.ConfigurePhotoSensorEvent;
import com.aztech.lmscollector.model.CurrentLevelEvent;
import com.aztech.lmscollector.model.EventMessage;
import com.aztech.lmscollector.model.FaultEvent;
import com.aztech.lmscollector.model.FirmwareEvent;
import com.aztech.lmscollector.model.GatewayIPAddressUpdateEvent;
import com.aztech.lmscollector.model.MotionDetectionEvent;
import com.aztech.lmscollector.model.PhotoSensorEvent;
import com.aztech.lmscollector.model.mapper.ClearFaultEventMapper;
import com.aztech.lmscollector.model.mapper.ConfigureLightEventMapper;
import com.aztech.lmscollector.model.mapper.ConfigurePhotoSensorEventMapper;
import com.aztech.lmscollector.model.mapper.CurrentLevelEventMapper;
import com.aztech.lmscollector.model.mapper.DeviceEventMapper;
import com.aztech.lmscollector.model.mapper.FaultEventMapper;
import com.aztech.lmscollector.model.mapper.FirmwareEventMapper;
import com.aztech.lmscollector.model.mapper.GatewayIPAddressUpdateEventMapper;
import com.aztech.lmscollector.model.mapper.MotionDetectionEventMapper;
import com.aztech.lmscollector.model.mapper.PhotoSensorEventMapper;
import com.aztech.lmscollector.mqtt.IOExecutorService;
import com.aztech.lmscollector.repository.BlockRepository;
import com.aztech.lmscollector.repository.CurrentLevelRepository;
import com.aztech.lmscollector.repository.EventRepository;
import com.aztech.lmscollector.repository.FaultReportRepository;
import com.aztech.lmscollector.repository.MotionDetectionRepository;
import com.aztech.lmscollector.repository.PhotoSensorRepository;
import com.aztech.lmscollector.repository.SmartLightRepository;
import com.aztech.lmscollector.repository.UserAccountDetailRepository;
import io.micrometer.prometheus.PrometheusConfig;
import io.micrometer.prometheus.PrometheusMeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@RunWith(JUnitPlatform.class)
public class EventServiceTest {
    private EventService service = null;
    private MotionDetectionEventMapper motionDetectionEventMapper = null;
    private CurrentLevelEventMapper currentLevelEventMapper = null;
    private PhotoSensorEventMapper photoSensorEventMapper = null;
    private FirmwareEventMapper firmwareEventMapper = null;
    private FaultEventMapper faultEventMapper = null;
    private GatewayIPAddressUpdateEventMapper gatewayIPAddressUpdateEventMapper = null;
    private ConfigureLightEventMapper configureLightEventMapper = null;
    private ConfigurePhotoSensorEventMapper configurePhotoSensorEventMapper = null;
    private DeviceEventMapper deviceEventMapper = null;
    private ClearFaultEventMapper clearFaultEventMapper = null;
    private EventRepository eventRepository = null;
    private IOExecutorService ioExecutorService = null;
    private MotionDetectionRepository motionDetectionRepository = null;
    private CurrentLevelRepository currentLevelRepository = null;
    private PhotoSensorRepository photoSensorRepository = null;
    private SmartLightRepository smartLightRepository = null;
    private FaultReportRepository faultReportRepository = null;
    private UserAccountDetailRepository userAccountDetailRepository = null;
    private BlockRepository blockRepository = null;

    @BeforeEach
    public void setup() {
        motionDetectionEventMapper = mock(MotionDetectionEventMapper.class);
        currentLevelEventMapper = mock(CurrentLevelEventMapper.class);
        photoSensorEventMapper = mock(PhotoSensorEventMapper.class);
        firmwareEventMapper = mock(FirmwareEventMapper.class);
        faultEventMapper = mock(FaultEventMapper.class);
        gatewayIPAddressUpdateEventMapper = mock(GatewayIPAddressUpdateEventMapper.class);
        configureLightEventMapper = mock(ConfigureLightEventMapper.class);
        configurePhotoSensorEventMapper = mock(ConfigurePhotoSensorEventMapper.class);
        deviceEventMapper = mock(DeviceEventMapper.class);
        clearFaultEventMapper = mock(ClearFaultEventMapper.class);
        eventRepository = mock(EventRepository.class);
        ioExecutorService = mock(IOExecutorService.class);
        when(ioExecutorService.getExecutorService()).thenReturn(Executors.newSingleThreadExecutor());
        motionDetectionRepository = mock(MotionDetectionRepository.class);
        currentLevelRepository = mock(CurrentLevelRepository.class);
        photoSensorRepository = mock(PhotoSensorRepository.class);
        smartLightRepository = mock(SmartLightRepository.class);
        faultReportRepository = mock(FaultReportRepository.class);
        userAccountDetailRepository = mock(UserAccountDetailRepository.class);
        blockRepository = mock(BlockRepository.class);
        service = new EventService(
                motionDetectionEventMapper,
                currentLevelEventMapper,
                photoSensorEventMapper,
                firmwareEventMapper,
                faultEventMapper,
                gatewayIPAddressUpdateEventMapper,
                configureLightEventMapper,
                configurePhotoSensorEventMapper,
                deviceEventMapper,
                clearFaultEventMapper,
                eventRepository,
                ioExecutorService,
                motionDetectionRepository,
                currentLevelRepository,
                photoSensorRepository,
                smartLightRepository,
                faultReportRepository,
                userAccountDetailRepository,
                blockRepository, new PrometheusMeterRegistry(PrometheusConfig.DEFAULT));
    }

    private List<EventMessage> generateMotionDetectionEventMessage() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/motion#reading\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"MotionDetection\":3},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generateCurrentLevelEventMessage() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/lightLevel#reading\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"LightLevel\":35},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generatePhotoSensorEventMessage() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/photosensor#reading\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"PhotosensorLux\":360},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generateFirmwareEventMessage() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/firmware-version#reading\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"FirmwareVersion\":\"1.2.25\"},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generateFaultEventMessage() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/light#fault\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"TripGeneralAlarm\":\"\",\"Severity\":1},\"UserId\":\"4\",\"Description\":\"Light 1.1.73 Current Error\",\"Faultcode\":\"AZ-LS-FC-0003\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generateGatewayIPAddressUpdateEvent() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/getIpAddress\",\"Parameters\":{\"IpAddress\":{\"lo\":\"127.0.0.1\",\"ppp0\":\"180.255.1.45\"}},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generateConfigureLightEvent() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",";
        eventJson += "\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/setLightingConfiguration\",";
        eventJson += "\"Parameters\":{\"CommandType\":\"Set_Ack\",\"MotionSensing\":\"Enable\",\"MotionSensitivity\":5,\"DimLevel\":10,\"MotionLevel\":5,";
        eventJson += "\"BrightLevel\":5,\"HoldTime\":20,\"LightIntensity\":5,\"ClockSync\":\"Enable\",\"Scheduling\":\"Enable\",\"PhotosensorGroup\":\"007\",\"BrightGroup\":\"003\"},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generatePhotoSensorEvent() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/setPhotoSensing\",\"Parameters\":{\"PhotoSensing\":\"Enable\",\"PhotoUpperThreshold\":160,\"PhotoLowerThreshold\":60},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generateClearFaultEvent() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/system#clear\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"RefEventId\":\"EV-820421-1.1.1-20200901\",\"RefEventType\":\"\"},\"UserId\":\"4\",\"Description\":\"Light 1.1.73 Current Error\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generateInvalidEventMessage() {
        String eventJson = "{\"SenderId\"\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/setPhotoSensing\",\"Parameters\":{\"PhotoSensing\":\"Enable\",\"PhotoUpperThreshold\":160,\"PhotoLowerThreshold\":60},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    private List<EventMessage> generateUnknownEventMessage() {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/dontknow\",\"Parameters\":{\"PhotoSensing\":\"Enable\",\"PhotoUpperThreshold\":160,\"PhotoLowerThreshold\":60},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);
        return Arrays.asList(eventMessage);
    }

    @Test
    public void testProcessMotionDetectionEvent() {
        List<EventMessage> eventMessages = generateMotionDetectionEventMessage();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(motionDetectionEventMapper, times(1)).toMotionDetectionEntity(any(MotionDetectionEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testProcessCurrentLevelEvent() {
        List<EventMessage> eventMessages = generateCurrentLevelEventMessage();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(currentLevelEventMapper, times(1)).toCurrentLevelEntity(any(CurrentLevelEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testProcessPhotoSensorEvent() throws InterruptedException {
        List<EventMessage> eventMessages = generatePhotoSensorEventMessage();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(photoSensorEventMapper, times(1)).toPhotoSensorEntity(any(PhotoSensorEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testProcessFirmwareEvent() {
        List<EventMessage> eventMessages = generateFirmwareEventMessage();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(firmwareEventMapper, times(1)).toSmartLightEntity(any(FirmwareEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testProcessFaultEvent() {
        List<EventMessage> eventMessages = generateFaultEventMessage();

        service.processEvents(eventMessages);

        verify(faultEventMapper, times(1)).toFaultEntity(any(FaultEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testProcessGatewayIPAddressUpdateEvent() {
        List<EventMessage> eventMessages = generateGatewayIPAddressUpdateEvent();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(gatewayIPAddressUpdateEventMapper, times(1)).toBlockEntity(any(GatewayIPAddressUpdateEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testProcessConfigureLightEvent() {
        List<EventMessage> eventMessages = generateConfigureLightEvent();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(configureLightEventMapper, times(1)).toSmartLightEntity(any(ConfigureLightEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testProcessConfigurePhotoSensorEvent() {
        List<EventMessage> eventMessages = generatePhotoSensorEvent();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(configurePhotoSensorEventMapper, times(1)).toSmartLightEntity(any(ConfigurePhotoSensorEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testProcessClearFaultEvent() {
        List<EventMessage> eventMessages = generateClearFaultEvent();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(clearFaultEventMapper, times(1)).toFaultEntity(any(ClearFaultEvent.class));
        verify(deviceEventMapper, times(1)).toEventEntity(any());
        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
    }

    @Test
    public void testInvalidEventMessage() {
        List<EventMessage> eventMessages = generateInvalidEventMessage();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(deviceEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }

    @Test
    public void testUnknownEventMessage() {
        List<EventMessage> eventMessages = generateUnknownEventMessage();

        service.processEvents(eventMessages);

        service.parametersObservable.ignoreElements().blockingAwait();

        verify(eventRepository, times(1)).save(anyList());
        verifyNoInteractions(motionDetectionEventMapper);
        verifyNoInteractions(configurePhotoSensorEventMapper);
        verifyNoInteractions(deviceEventMapper);
        verifyNoInteractions(currentLevelEventMapper);
        verifyNoInteractions(photoSensorEventMapper);
        verifyNoInteractions(firmwareEventMapper);
        verifyNoInteractions(faultEventMapper);
        verifyNoInteractions(gatewayIPAddressUpdateEventMapper);
        verifyNoInteractions(configureLightEventMapper);
        verifyNoInteractions(clearFaultEventMapper);
    }
}
