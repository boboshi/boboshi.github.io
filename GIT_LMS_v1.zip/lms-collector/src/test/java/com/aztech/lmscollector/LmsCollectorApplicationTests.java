package com.aztech.lmscollector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsCollectorApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
