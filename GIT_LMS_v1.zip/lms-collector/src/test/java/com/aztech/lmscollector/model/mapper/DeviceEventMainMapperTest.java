package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.model.DeviceEvent;
import com.aztech.lmscollector.model.EventMessage;
import com.aztech.lmscollector.service.exception.NoSuchEventTypeException;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

@RunWith(JUnitPlatform.class)
public class DeviceEventMainMapperTest {

    @Test
    public void testEventMessageToMotionDetectionEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/motion#reading\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"MotionDetection\":3},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToCurrentLevelEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/lightLevel#reading\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"LightLevel\":35},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToPhotoSensorEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/photosensor#reading\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"PhotosensorLux\":360},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToFaultEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/light#fault\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"TripGeneralAlarm\":\"\",\"Severity\":1},\"UserId\":\"4\",\"Description\":\"Light 1.1.73 Current Error\",\"Faultcode\":\"AZ-LS-FC-0003\"}";
        EventMessage eventMessage = new EventMessage("Fault", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToFirmwareEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/firmware-version#reading\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"FirmwareVersion\":\"1.2.25\"},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Reading", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToGatewayIPAddressUpdateEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/getIpAddress\",\"Parameters\":{\"IpAddress\":{\"lo\":\"127.0.0.1\",\"ppp0\":\"180.255.1.45\"}},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Response", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToConfigureLightEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",";
        eventJson += "\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/setLightingConfiguration\",";
        eventJson += "\"Parameters\":{\"CommandType\":\"Set_Ack\",\"MotionSensing\":\"Enable\",\"MotionSensitivity\":5,\"DimLevel\":10,\"MotionLevel\":5,";
        eventJson += "\"BrightLevel\":5,\"HoldTime\":20,\"LightIntensity\":5,\"ClockSync\":\"Enable\",\"Scheduling\":\"Enable\",\"PhotosensorGroup\":\"007\",\"BrightGroup\":\"003\"},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Response", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToConfigurePhotoSensorEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/setPhotoSensing\",\"Parameters\":{\"PhotoSensing\":\"Enable\",\"PhotoUpperThreshold\":160,\"PhotoLowerThreshold\":60},\"UserId\":\"4\"}";
        EventMessage eventMessage = new EventMessage("Response", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToClearFaultEvent() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/system#clear\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"RefEventId\":\"EV-820421-1.1.1-20200901\",\"RefEventType\":\"\"},\"UserId\":\"4\",\"Description\":\"Light 1.1.73 Current Error\"}";
        EventMessage eventMessage = new EventMessage("Fault", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }

    @Test
    public void testEventMessageToFaultEventWithTrailingComman() throws JsonProcessingException, NoSuchEventTypeException {
        String eventJson = "{\"SenderId\":\"LightingSystem-AZTECH-820421-GATEWAY\",\"SensorID\":\"LightingSystem-AZTECH-820421-1.1.1\",\"lightSN\":\"\",\"blockNO\":\"\",\"EventId\":\"EV-820421-1.1.1-20200901\",\"EventType\":\"LightingSystem/light#fault\",\"Parameters\":{\"Time\":\"2020-09-02 00:00:00\",\"TripGeneralAlarm\":\"\",\"Severity\":1,},\"UserId\":\"4\",\"Description\":\"Light 1.1.73 Current Error\",\"Faultcode\":\"AZ-LS-FC-0003\",}";
        EventMessage eventMessage = new EventMessage("Fault", eventJson);

        DeviceEvent event = DeviceEventMainMapper.fromEventMessage(eventMessage);
        System.out.println(event);

        assertThat(event, notNullValue());
    }
}
