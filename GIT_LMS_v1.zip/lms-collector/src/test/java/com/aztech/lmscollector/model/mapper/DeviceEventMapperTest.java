package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.EventEntity;
import com.aztech.lmscollector.model.DeviceEvent;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class DeviceEventMapperTest {
    @Test
    public void testDeviceEventToEventEntity() {
        DeviceEvent event = new DeviceEvent();
        event.setEventId("1");
        event.setEventType("type");
        event.setSensorId("LightingSystem-AZTECH-820421-1.1.1");
        event.setSenderId("sender");
        event.setUserId(4);
        event.setParameterString("{}");

        DeviceEventMapper mapper = new DeviceEventMapperImpl();
        final EventEntity entity = mapper.toEventEntity(event);

        assertThat(entity.getBlockNO(), equalTo("820421"));
        assertThat(entity.getLightSN(), equalTo("1.1.1"));
        assertThat(entity.getEventId(), equalTo("1"));
        assertThat(entity.getEventType(), equalTo("type"));
        assertThat(entity.getSensorId(), equalTo("LightingSystem-AZTECH-820421-1.1.1"));
        assertThat(entity.getSenderId(), equalTo("sender"));
        assertThat(entity.getUserId(), equalTo(4));
        assertThat(entity.getParameters(), equalTo("{}"));
    }
}
