package com.aztech.lmscollector.entity;

import io.reactivex.rxjava3.core.Observable;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class MotioinDetectionEntityTest {
    @Test
    public void testEqualMotionDetectionEntity() {
        Date now = Date.from(Instant.now());

        MotionDetectionEntity left = new MotionDetectionEntity();
        left.setBlockNO("888111");
        left.setLightSN("1.1.1");
        left.setDetectedStatus(4);
        left.setReportDateTime(now);

        MotionDetectionEntity right = new MotionDetectionEntity();
        right.setBlockNO("888111");
        right.setLightSN("1.1.1");
        right.setDetectedStatus(4);
        right.setReportDateTime(now);

        assertThat(left, equalTo(right));
    }

    @Test
    public void testDistinctMotionDetectionEntity() {
        Date now = Date.from(Instant.now());

        MotionDetectionEntity left = new MotionDetectionEntity();
        left.setBlockNO("888111");
        left.setLightSN("1.1.1");
        left.setDetectedStatus(4);
        left.setReportDateTime(now);

        MotionDetectionEntity right = new MotionDetectionEntity();
        right.setBlockNO("888111");
        right.setLightSN("1.1.1");
        right.setDetectedStatus(4);
        right.setReportDateTime(now);

        List<MotionDetectionEntity> entities = Stream.of(left, right).distinct().collect(Collectors.toList());

        assertThat(entities.size(), equalTo(1));
    }

    @Test
    public void testRxDistinctMotionDetectionEntity() {
        Date now = Date.from(Instant.now());

        MotionDetectionEntity left = new MotionDetectionEntity();
        left.setBlockNO("888111");
        left.setLightSN("1.1.1");
        left.setDetectedStatus(4);
        left.setReportDateTime(now);

        MotionDetectionEntity right = new MotionDetectionEntity();
        right.setBlockNO("888111");
        right.setLightSN("1.1.1");
        right.setDetectedStatus(4);
        right.setReportDateTime(now);

        List<MotionDetectionEntity> entities = Observable.fromStream(Stream.of(left, right))
                .distinct(entity -> entity.hashCode())
                .toList()
                .blockingGet();

        assertThat(entities.size(), equalTo(1));
    }
}
