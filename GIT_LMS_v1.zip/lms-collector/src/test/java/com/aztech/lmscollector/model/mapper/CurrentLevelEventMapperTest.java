package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.CurrentLevelEntity;
import com.aztech.lmscollector.model.CurrentLevelEvent;
import com.aztech.lmscollector.model.CurrentLevelParameter;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import java.time.Instant;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class CurrentLevelEventMapperTest {
    @Test
    public void testCurrentLevelEventToCurrentLevelEntity() {
        CurrentLevelEvent event = new CurrentLevelEvent();
        CurrentLevelParameter parameter = new CurrentLevelParameter();
        java.util.Date now = java.util.Date.from(Instant.now());
        java.sql.Date sqlNow = new java.sql.Date(now.getTime());
        parameter.setCurrentLevel(1);
        parameter.setReportedDate(now);
        event.setLightId("1.1.1");
        event.setBlockNumber("888111");
        event.setParameter(parameter);

        CurrentLevelEventMapper mapper = new CurrentLevelEventMapperImpl();
        CurrentLevelEntity entity = mapper.toCurrentLevelEntity(event);

        assertThat(entity.getBlockNO(), equalTo("888111"));
        assertThat(entity.getLightSN(), equalTo("1.1.1"));
        assertThat(entity.getCurrentLevel(), equalTo(1));
        assertThat(entity.getReportDateTime(), equalTo(sqlNow));
    }
}
