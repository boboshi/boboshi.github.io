package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.SmartLightEntity;
import com.aztech.lmscollector.model.ConfigurePhotoSensorEvent;
import com.aztech.lmscollector.model.ConfigurePhotoSensorParameter;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@RunWith(JUnitPlatform.class)
public class ConfigurePhotoSensorEventMapperTest {
    @Test
    public void testPhotoSensorEventToSmartLightEntity() {
        ConfigurePhotoSensorEvent event = new ConfigurePhotoSensorEvent();
        ConfigurePhotoSensorParameter parameter = new ConfigurePhotoSensorParameter();
        parameter.setCommandType("Set_Ack");
        parameter.setPhotoSensing("Yes");
        parameter.setPhotoSensorLowerThreshold(1);
        parameter.setPhotoSensorUpperThreshold(2);
        event.setBlockNumber("888111");
        event.setLightId("1.1.1");
        event.setParameter(parameter);

        ConfigurePhotoSensorEventMapper mapper = new ConfigurePhotoSensorEventMapperImpl();
        final SmartLightEntity entity = mapper.toSmartLightEntity(event);

        assertThat(entity.getPhotoSensing(), equalTo("Yes"));
        assertThat(entity.getPhotoLowerThreshold(), equalTo(1));
        assertThat(entity.getPhotoUpperThreshold(), equalTo(2));
    }
}
