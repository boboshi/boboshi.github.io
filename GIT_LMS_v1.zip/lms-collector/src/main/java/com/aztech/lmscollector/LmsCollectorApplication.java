package com.aztech.lmscollector;

import com.aztech.lmscollector.configuration.EventMessageProcessingConfiguration;
import com.aztech.lmscollector.mqtt.EventMessageExecutorService;
import com.aztech.lmscollector.mqtt.IOExecutorService;
import com.aztech.lmscollector.mqtt.ReactiveMqttAsyncClient;
import com.aztech.lmscollector.mqtt.SmartCollectorMqttConfiguration;
import com.aztech.lmscollector.service.EventService;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import io.reactivex.rxjava3.schedulers.Schedulers;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriBuilderFactory;

import javax.net.ssl.SSLSocketFactory;
import javax.sql.DataSource;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.TimeUnit;

@SpringBootApplication
@EnableJdbcRepositories
public class LmsCollectorApplication {
	
	private static final Logger logger = LoggerFactory.getLogger(LmsCollectorApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(LmsCollectorApplication.class, args);
	}

	@Bean
	public DataSource dataSource(Environment environment) {
		HikariConfig hikariConfig = new HikariConfig();
		hikariConfig.setJdbcUrl(prepareJdbcUri(environment));
		hikariConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
		//TODO: TESTING ONLY
//		hikariConfig.setUsername("spsclient");
//		hikariConfig.setPassword("sN@6MS");
 		hikariConfig.setUsername(loadUsername());
		hikariConfig.setPassword(loadPassword());
		hikariConfig.setMaximumPoolSize(10);
		return new HikariDataSource(hikariConfig);
	}

	private String prepareJdbcUri(Environment environment) {
		String dbHost = environment.getProperty("DB_HOST", "localhost");
		String dbPort = environment.getProperty("DB_PORT", "3306");

		UriBuilderFactory builderFactory = new DefaultUriBuilderFactory();
		return new StringBuilder()
				.append("jdbc:")
				.append(builderFactory.builder()
						.scheme("mysql")
						.host(dbHost)
						.port(dbPort)
						.path("spsdb_sg")
						.queryParam("useSSL", false)
						.queryParam("serverTimezone", "Asia/Singapore")
						.queryParam("useLegacyDatetimeCode", false)
						.build().toString()).toString();
	}

	private String loadUsername() {
		return loadSecret("mysql_username");
	}

	private String loadPassword() {
		return loadSecret("mysql_password");
	}

	private String loadSecret(String name) {
		String secret = "";
		String secretPath = String.format("/run/secrets/%s", name);
		File secretFile = new File(secretPath);

		if (secretFile.exists()) {
			try (FileReader fileReader = new FileReader(secretFile)) {
				try (BufferedReader reader = new BufferedReader(fileReader)) {
					secret = reader.readLine();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return secret;
	}

	@Bean
	@ConfigurationProperties(prefix="app.mqtt.connection.options")
	public SmartCollectorMqttConfiguration smartCollectorMqttConfiguration(Environment environment) {
		//TODO: TESTING ONLY
		String brokerUrl = environment.getRequiredProperty("MQTT_BROKER_URI");
//		String brokerUrl = "ssl://sls.aztech.com:8883";
		SmartCollectorMqttConfiguration smartCollectorMqttConfiguration = new SmartCollectorMqttConfiguration();
		smartCollectorMqttConfiguration.setBrokerUrl(brokerUrl);
		return smartCollectorMqttConfiguration;
	}

	@Bean
	@ConfigurationProperties(prefix = "app.event.processing")
	public EventMessageProcessingConfiguration eventMessageProcessingConfiguration() {
		return new EventMessageProcessingConfiguration();
	}

	@Bean
	public NamedParameterJdbcTemplate namedParameterJdbcTemplate(DataSource dataSource) {
		return new NamedParameterJdbcTemplate(dataSource);
	}


	@Bean
	public MqttConnectOptions mqttConnectOptions(SmartCollectorMqttConfiguration configuration) {
		MqttConnectOptions options = new MqttConnectOptions();
		options.setCleanSession(configuration.getCleanSession());
		options.setConnectionTimeout(configuration.getConnectionTimeout());
		options.setKeepAliveInterval(configuration.getConnectionTimeout());
		options.setAutomaticReconnect(configuration.getAutomaticReconnect());
		options.setUserName(configuration.getUserNamePrefix() + new Date().getTime());
		if (configuration.getBrokerUrl().toLowerCase().startsWith("ssl")) {
			options.setSocketFactory(SSLSocketFactory.getDefault());
		}
		logger.info(options.toString());
		return options;
	}

	@Bean
	public ReactiveMqttAsyncClient reactiveMqttAsyncClient(
			SmartCollectorMqttConfiguration configuration,
			MqttConnectOptions mqttConnectOptions) throws MqttException {

		ReactiveMqttAsyncClient client = ReactiveMqttAsyncClient.create(
				configuration,
				mqttConnectOptions);

		return client;
	}

	@Bean
	public EventMessageExecutorService eventMessageExecutorService() {
		return EventMessageExecutorService.create(10);
	}

	@Bean
	public IOExecutorService ioExecutorService(@Value("${app.db.datasource.maxPoolSize}") int poolSize) {
		return IOExecutorService.create(poolSize);
	}

	@Bean
	public CommandLineRunner commandLineRunner(
			EventService eventService,
			ReactiveMqttAsyncClient reactiveMqttAsyncClient,
			EventMessageExecutorService eventMessageExecutorService,
			EventMessageProcessingConfiguration eventMessageProcessingConfiguration) {

		return (args) -> {

			final int batchProcessingCount = eventMessageProcessingConfiguration.getBatchProcessingCount();
			final int batchThresholdInMillis = eventMessageProcessingConfiguration.getBatchThresholdInMillis();

			reactiveMqttAsyncClient
					.getEventMessageObservable()
					.buffer(batchThresholdInMillis, TimeUnit.MILLISECONDS, batchProcessingCount)
					.filter(eventMessages -> !eventMessages.isEmpty())
					.observeOn(Schedulers.from(eventMessageExecutorService.getExecutorService()))
                    .doOnEach(n -> logger.trace(String.format("processing %d items", n.getValue().size())))
					.subscribe(eventMessages -> {
						eventService.processEvents(eventMessages);
					});
		};
	}
}
