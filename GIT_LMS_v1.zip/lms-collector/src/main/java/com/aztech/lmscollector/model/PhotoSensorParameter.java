package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.Date;

public class PhotoSensorParameter {
    private int photoSensorLevel;
    private Date reportedDate;

    public PhotoSensorParameter() {
        this.photoSensorLevel = 1;
        this.reportedDate = Date.from(Instant.now());
    }

    @JsonProperty("PhotosensorLux")
    public int getPhotoSensorLevel() {
        return photoSensorLevel;
    }

    public void setPhotoSensorLevel(int photoSensorLevel) {
        this.photoSensorLevel = photoSensorLevel;
    }

    @JsonProperty("Time")
    public Date getReportedDate() {
        return reportedDate;
    }

    public void setReportedDate(Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    @Override
    public String toString() {
        return "PhotoSensorParameter{" +
                "photoSensorLevel=" + photoSensorLevel +
                ", reportedDate=" + reportedDate +
                '}';
    }
}
