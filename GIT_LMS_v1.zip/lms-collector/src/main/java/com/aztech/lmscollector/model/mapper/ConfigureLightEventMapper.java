package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.SmartLightEntity;
import com.aztech.lmscollector.model.ConfigureLightEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ConfigureLightEventMapper {
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    @Mapping(source = "event.parameter.motionSensing", target = "motionSensing")
    @Mapping(source = "event.parameter.motionSensitivity", target = "motionSensitivity")
    @Mapping(source = "event.parameter.dimLevel", target = "dimLevel")
    @Mapping(source = "event.parameter.motionLevel", target = "motionLevel")
    @Mapping(source = "event.parameter.brightnessLevel", target = "brightLevel")
    @Mapping(source = "event.parameter.holdTime", target = "holdTime")
    @Mapping(source = "event.parameter.lightIntensity", target = "lightIntensity")
    @Mapping(source = "event.parameter.clockSync", target = "clockSync")
    @Mapping(source = "event.parameter.scheduling", target = "scheduling")
    @Mapping(source = "event.parameter.photoSensorGroup", target = "photosensorGroup")
    @Mapping(source = "event.parameter.brightnessGroup", target = "brightGroup")
    SmartLightEntity toSmartLightEntity(ConfigureLightEvent event);
}
