package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.Date;

public class MotionDetectionParameter {
    private int detectedStatus;
    private Date reportedDate;

    public MotionDetectionParameter() {
        this.detectedStatus = 0;
        this.reportedDate = Date.from(Instant.now());
    }

    @JsonProperty("MotionDetection")
    public int getDetectedStatus() {
        return detectedStatus;
    }

    public void setDetectedStatus(int detectedStatus) {
        this.detectedStatus = detectedStatus;
    }

    @JsonProperty("Time")
    public Date getReportedDate() {
        return reportedDate;
    }

    public void setReportedDate(Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    @Override
    public String toString() {
        return "MotionDetectionParameter{" +
                "detectedStatus=" + detectedStatus +
                ", reportedDate=" + reportedDate +
                '}';
    }
}
