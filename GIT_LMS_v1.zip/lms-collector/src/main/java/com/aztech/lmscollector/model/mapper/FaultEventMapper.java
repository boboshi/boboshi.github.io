package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.FaultEntity;
import com.aztech.lmscollector.model.FaultEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface FaultEventMapper {
    @Mapping(source = "event.parameter.severity", target = "severity")
    @Mapping(source = "event.parameter.tripGeneralAlarm", target = "tripGeneralAlarm")
    @Mapping(source = "event.parameter.reportedDate", target = "reportDateTime")
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    @Mapping(source = "eventId", target = "eventId")
    @Mapping(source = "eventType", target = "eventType")
    @Mapping(source = "description", target = "description")
    @Mapping(source = "faultCode", target = "faultCode")
    FaultEntity toFaultEntity(FaultEvent event);
}
