package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ControlLightEvent extends DeviceEvent {
    private ControlLightParameter parameter;

    public ControlLightEvent() {
        this.parameter = new ControlLightParameter();
    }

    @JsonProperty("Parameters")
    public ControlLightParameter getParameter() {
        return parameter;
    }

    public void setParameter(ControlLightParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "ControlLightEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameter=" + parameter +
                '}';
    }
}
