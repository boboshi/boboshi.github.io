package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FaultEvent extends DeviceEvent {
    private FaultParameter parameter;

    public FaultEvent() {
        this.parameter = new FaultParameter();
    }

    @JsonProperty("Parameters")
    public FaultParameter getParameter() {
        return parameter;
    }

    public void setParameter(FaultParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "FaultEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameter=" + parameter +
                '}';
    }
}
