package com.aztech.lmscollector.configuration;

public class EventMessageProcessingConfiguration {
    private int batchProcessingCount;
    private int batchThresholdInMillis;

    public EventMessageProcessingConfiguration() {
    }

    public int getBatchProcessingCount() {
        return batchProcessingCount;
    }

    public void setBatchProcessingCount(int batchProcessingCount) {
        this.batchProcessingCount = batchProcessingCount;
    }

    public int getBatchThresholdInMillis() {
        return batchThresholdInMillis;
    }

    public void setBatchThresholdInMillis(int batchThresholdInMillis) {
        this.batchThresholdInMillis = batchThresholdInMillis;
    }
}
