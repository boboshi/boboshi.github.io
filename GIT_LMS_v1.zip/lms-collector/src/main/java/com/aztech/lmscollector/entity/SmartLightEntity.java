package com.aztech.lmscollector.entity;

public class SmartLightEntity {
    private String firmware;
    private String lightSN;
    private String blockNO;
    private String motionSensing;
    private int motionSensitivity;
    private int motionLevel;
    private int dimLevel;
    private int brightLevel;
    private int holdTime;
    private int lightIntensity;
    private String clockSync;
    private String scheduling;
    private String photosensorGroup;
    private String brightGroup;
    private String photoSensing;
    private int photoUpperThreshold;
    private int photoLowerThreshold;

    public SmartLightEntity() {
        this.firmware = "1.0.00";
        this.lightSN = "";
        this.blockNO = "";
        this.motionSensing = "Enable";
        this.motionSensitivity = 2;
        this.dimLevel = 20;
        this.motionLevel = 10;
        this.brightLevel = 10;
        this.holdTime = 15;
        this.lightIntensity = 3;
        this.clockSync = "Enable";
        this.scheduling = "Enable";
        this.photosensorGroup = "07001859";
        this.brightGroup = "19002359";
        this.photoSensing = "Enable";
        this.photoUpperThreshold = 150;
        this.photoLowerThreshold = 50;
    }

    public String getFirmware() {
        return firmware;
    }

    public void setFirmware(String firmware) {
        this.firmware = firmware;
    }

    public String getLightSN() {
        return lightSN;
    }

    public void setLightSN(String lightSN) {
        this.lightSN = lightSN;
    }

    public String getBlockNO() {
        return blockNO;
    }

    public void setBlockNO(String blockNO) {
        this.blockNO = blockNO;
    }

    public String getMotionSensing() {
        return motionSensing;
    }

    public void setMotionSensing(String motionSensing) {
        this.motionSensing = motionSensing;
    }

    public int getMotionSensitivity() {
        return motionSensitivity;
    }

    public void setMotionSensitivity(int motionSensitivity) {
        this.motionSensitivity = motionSensitivity;
    }

    public int getMotionLevel() {
        return motionLevel;
    }

    public void setMotionLevel(int motionLevel) {
        this.motionLevel = motionLevel;
    }

    public int getDimLevel() {
        return dimLevel;
    }

    public void setDimLevel(int dimLevel) {
        this.dimLevel = dimLevel;
    }

    public int getBrightLevel() {
        return brightLevel;
    }

    public void setBrightLevel(int brightLevel) {
        this.brightLevel = brightLevel;
    }

    public int getHoldTime() {
        return holdTime;
    }

    public void setHoldTime(int holdTime) {
        this.holdTime = holdTime;
    }

    public int getLightIntensity() {
        return lightIntensity;
    }

    public void setLightIntensity(int lightIntensity) {
        this.lightIntensity = lightIntensity;
    }

    public String getClockSync() {
        return clockSync;
    }

    public void setClockSync(String clockSync) {
        this.clockSync = clockSync;
    }

    public String getScheduling() {
        return scheduling;
    }

    public void setScheduling(String scheduling) {
        this.scheduling = scheduling;
    }

    public String getPhotosensorGroup() {
        return photosensorGroup;
    }

    public void setPhotosensorGroup(String photosensorGroup) {
        this.photosensorGroup = photosensorGroup;
    }

    public String getBrightGroup() {
        return brightGroup;
    }

    public void setBrightGroup(String brightGroup) {
        this.brightGroup = brightGroup;
    }

    public String getPhotoSensing() {
        return photoSensing;
    }

    public void setPhotoSensing(String photoSensing) {
        this.photoSensing = photoSensing;
    }

    public int getPhotoUpperThreshold() {
        return photoUpperThreshold;
    }

    public void setPhotoUpperThreshold(int photoUpperThreshold) {
        this.photoUpperThreshold = photoUpperThreshold;
    }

    public int getPhotoLowerThreshold() {
        return photoLowerThreshold;
    }

    public void setPhotoLowerThreshold(int photoLowerThreshold) {
        this.photoLowerThreshold = photoLowerThreshold;
    }

    @Override
    public String toString() {
        return "SmartLightEntity{" +
                "firmware='" + firmware + '\'' +
                ", lightSN='" + lightSN + '\'' +
                ", blockNO='" + blockNO + '\'' +
                ", motionSensing='" + motionSensing + '\'' +
                ", motionSensitivity=" + motionSensitivity +
                ", motionLevel=" + motionLevel +
                ", dimLevel=" + dimLevel +
                ", brightLevel=" + brightLevel +
                ", holdTime=" + holdTime +
                ", lightIntensity=" + lightIntensity +
                ", clockSync='" + clockSync + '\'' +
                ", scheduling='" + scheduling + '\'' +
                ", photosensorGroup='" + photosensorGroup + '\'' +
                ", brightGroup='" + brightGroup + '\'' +
                ", photoSensing='" + photoSensing + '\'' +
                ", photoUpperThreshold=" + photoUpperThreshold +
                ", photoLowerThreshold=" + photoLowerThreshold +
                '}';
    }
}
