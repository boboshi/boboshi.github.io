package com.aztech.lmscollector.model;


import com.fasterxml.jackson.annotation.JsonProperty;

public class MotionDetectionEvent extends DeviceEvent {

    private MotionDetectionParameter parameter;

    public MotionDetectionEvent() {
        parameter = new MotionDetectionParameter();
    }

    @JsonProperty("Parameters")
    public MotionDetectionParameter getParameter() {
        return parameter;
    }

    public void setParameter(MotionDetectionParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "MotionDetectionEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameter=" + getParameter().toString() +
                '}';
    }
}
