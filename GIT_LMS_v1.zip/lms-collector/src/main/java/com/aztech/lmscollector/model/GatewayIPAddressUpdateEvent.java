package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GatewayIPAddressUpdateEvent extends DeviceEvent {
    private String parameter;

    public GatewayIPAddressUpdateEvent() {
        this.parameter = "";
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "GatewayIPAddressUpdateEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameters='" + parameter + '\'' +
                '}';
    }
}
