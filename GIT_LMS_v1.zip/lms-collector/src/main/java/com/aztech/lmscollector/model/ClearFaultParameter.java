package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.Date;

public class ClearFaultParameter {
    private Date reportedDate;
    private String referenceEventId;
    private String referenceEventType;

    public ClearFaultParameter() {
        this.reportedDate = Date.from(Instant.now());
        this.referenceEventId = "";
        this.referenceEventType = "";
    }

    @JsonProperty("Time")
    public Date getReportedDate() {
        return reportedDate;
    }

    public void setReportedDate(Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    @JsonProperty("RefEventId")
    public String getReferenceEventId() {
        return referenceEventId;
    }

    public void setReferenceEventId(String referenceEventId) {
        this.referenceEventId = referenceEventId;
    }

    @JsonProperty("RefEventType")
    public String getReferenceEventType() {
        return referenceEventType;
    }

    public void setReferenceEventType(String referenceEventType) {
        this.referenceEventType = referenceEventType;
    }

    @Override
    public String toString() {
        return "ClearFaultParameter{" +
                "reportedDate=" + reportedDate +
                ", referenceEventId='" + referenceEventId + '\'' +
                ", referenceEventType='" + referenceEventType + '\'' +
                '}';
    }
}
