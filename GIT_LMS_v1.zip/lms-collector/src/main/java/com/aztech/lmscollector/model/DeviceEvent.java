package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DeviceEvent {
    private String senderId;
    private String sensorId;
    private String lightId;
    private String blockNumber;
    private String eventId;
    private String eventType;
    private int userId;
    private String description;
    private String faultCode;
    private String parameterString;

    public DeviceEvent() {
        this.senderId = "";
        this.sensorId = "";
        this.lightId = "";
        this.blockNumber = "";
        this.eventId = "";
        this.eventType = "";
        this.userId = -1;
        this.description = "";
        this.faultCode = "";
        this.parameterString = "";
    }

    @JsonProperty("SenderId")
    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    @JsonProperty("SensorID")
    public String getSensorId() {
        return sensorId;
    }

    public void setSensorId(String sensorId) {
        this.sensorId = sensorId;
        int lastHyphenPos = sensorId.lastIndexOf("-");
        int nextLastHyphenPos = sensorId.lastIndexOf("-", lastHyphenPos - 1);
        this.lightId = sensorId.substring(lastHyphenPos + 1);
        this.blockNumber = sensorId.substring(nextLastHyphenPos + 1, lastHyphenPos);
    }

    @JsonProperty("lightSN")
    public String getLightId() {
        return lightId;
    }

    @JsonIgnore
    public void setLightId(String lightId) {
        this.lightId = lightId;
    }

    @JsonProperty("blockNO")
    public String getBlockNumber() {
        return blockNumber;
    }

    @JsonIgnore
    public void setBlockNumber(String blockNumber) {
        this.blockNumber = blockNumber;
    }

    @JsonProperty("EventId")
    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    @JsonProperty("EventType")
    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @JsonProperty("UserId")
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    @JsonProperty(value = "Description", required = false)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty(value = "Faultcode", required = false)
    public String getFaultCode() {
        return faultCode;
    }

    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }

    public String getParameterString() {
        return parameterString;
    }

    public void setParameterString(String parameter) {
        this.parameterString = parameter;
    }

    @Override
    public String toString() {
        return "DeviceEvent{" +
                "senderId='" + senderId + '\'' +
                ", sensorId='" + sensorId + '\'' +
                ", lightId='" + lightId + '\'' +
                ", blockNumber='" + blockNumber + '\'' +
                ", eventId='" + eventId + '\'' +
                ", eventType='" + eventType + '\'' +
                ", userId=" + userId +
                ", description='" + description + '\'' +
                ", faultCode='" + faultCode + '\'' +
                ", parameterString='" + parameterString + '\'' +
                '}';
    }
}
