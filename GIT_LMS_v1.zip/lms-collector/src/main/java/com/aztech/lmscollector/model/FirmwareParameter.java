package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.Date;

public class FirmwareParameter {
    private String firmwareVersion;
    private Date reportedDate;

    public FirmwareParameter() {
        this.firmwareVersion = "1.0.00";
        this.reportedDate = Date.from(Instant.now());
    }

    @JsonProperty("FirmwareVersion")
    public String getFirmwareVersion() {
        return firmwareVersion;
    }

    public void setFirmwareVersion(String firmwareVersion) {
        this.firmwareVersion = firmwareVersion;
    }

    @JsonProperty("Time")
    public Date getReportedDate() {
        return reportedDate;
    }

    public void setReportedDate(Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    @Override
    public String toString() {
        return "FirmwareParameter{" +
                "firmwareVersion='" + firmwareVersion + '\'' +
                ", reportedDate=" + reportedDate +
                '}';
    }
}
