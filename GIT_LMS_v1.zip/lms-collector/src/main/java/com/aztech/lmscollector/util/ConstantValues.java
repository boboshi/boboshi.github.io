package com.aztech.lmscollector.util;

public class ConstantValues {
    public class MotionSensitivityString {
        public static final String ONE = "High";
        public static final String TWO = "Medium-High";
        public static final String THREE = "Medium";
        public static final String FOUR = "Medium-Low";
        public static final String FIVE = "Low";
    }

    public class LightIntensityString {
        public static final String ONE = "Slow";
        public static final String TWO = "Medium";
        public static final String THREE = "Fast";
    }

    public class DataType {
        public static final int AREA = 1;
        public static final int BLOCK = 2;
        public static final int FLOOR = 3;
        public static final int LIGHT = 4;
    }

    public class EventType {
        //Alarm-related
        public static final String LIGHT_FAULT = "LightingSystem/light#fault";
        public static final String FAULT_CLEAR = "LightingSystem/system#clear";

        //Reading-related
        public static final String MOTION_READING = "LightingSystem/motion#reading";
        public static final String LIGHTLEVEL_READING = "LightingSystem/lightLevel#reading";
        public static final String PHOTOSENSOR_READING = "LightingSystem/photosensor#reading";
        public static final String FIRMWARE_READING = "LightingSystem/firmware-version#reading";

        //Light control/configure/response related
        public static final String CONTROL_LIGHT = "LightingSystem/setLightingOverride";
        public static final String CONFIGURE_LIGHT = "LightingSystem/setLightingConfiguration";
        public static final String CONFIGURE_PHOTOSENSOR = "LightingSystem/setPhotoSensing";
        public static final String GET_GATEWAY_IP = "LightingSystem/getIpAddress";
    }

    public class MqttPayloadKey {
        //Mandatory
        public static final String SENDER_ID = "SenderId";
        public static final String SENSOR_ID = "SensorID";
        public static final String EVENT_ID = "EventId";
        public static final String EVENT_TYPE = "EventType";
        public static final String PARAMETERS = "Parameters";

        //Control/Config
        public static final String COMMAND_TYPE = "CommandType";
        public static final String COMMAND_TYPE_SET_ACK = "Set_Ack";
        public static final String COMMAND_TYPE_SET_ERROR = "Set_Error";

        //Control
        public static final String LIGHTING_CONTROL = "LightingControl";

        //Config
        public static final String MOTION_SENSING = "MotionSensing";
        public static final String MOTION_SENSITIVITY = "MotionSensitivity";
        public static final String DIM_LEVEL = "DimLevel";
        public static final String MOTION_LEVEL = "MotionLevel";
        public static final String BRIGHT_LEVEL = "BrightLevel";
        public static final String HOLD_TIME = "HoldTime";
        public static final String LIGHT_INTENSITY = "LightIntensity";
        public static final String CLOCK_SYNC = "ClockSync";
        public static final String SCHEDULING = "Scheduling";
        public static final String PHOTOSENSOR_GROUP = "PhotosensorGroup";
        public static final String BRIGHT_GROUP = "BrightGroup";

        //Config photosensor
        public static final String PHOTOSENSING = "PhotoSensing";
        public static final String PHOTOSENSOR_UPPER_THRESHOLD = "PhotoUpperThreshold";
        public static final String PHOTOSENSOR_LOWER_THRESHOLD = "PhotoLowerThreshold";

        //Readings/Reporting
        public static final String TIME = "Time";

        //Readings
        public static final String MOTION_DETECTION = "MotionDetection";
        public static final String LIGHT_LEVEL = "LightLevel";
        public static final String PHOTOSENSOR_LUX = "PhotosensorLux";
        public static final String FIRMWARE_VERSION = "FirmwareVersion";

        //Reporting
        public static final String SEVERITY = "Severity";
        public static final String TRIP_GENERAL_ALARM = "TripGeneralAlarm";
        public static final String DESCRIPTION = "Description";
        public static final String FAULT_CODE = "Faultcode";
        public static final String REFERENCE_EVENT_ID = "RefEventId";
        public static final String REFERENCE_EVENT_TYPE = "RefEventType";
    }
}
