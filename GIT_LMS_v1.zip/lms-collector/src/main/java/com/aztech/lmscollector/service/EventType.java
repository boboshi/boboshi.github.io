package com.aztech.lmscollector.service;

public class EventType {
    //Alarm-related
    public static final String LIGHT_FAULT = "LightingSystem/light#fault";
    public static final String FAULT_CLEAR = "LightingSystem/system#clear";

    //Reading-related
    public static final String MOTION_READING = "LightingSystem/motion#reading";
    public static final String LIGHTLEVEL_READING = "LightingSystem/lightLevel#reading";
    public static final String PHOTOSENSOR_READING = "LightingSystem/photosensor#reading";
    public static final String FIRMWARE_READING = "LightingSystem/firmware-version#reading";

    //Light control/configure/response related
    public static final String CONTROL_LIGHT = "LightingSystem/setLightingOverride";
    public static final String CONFIGURE_LIGHT = "LightingSystem/setLightingConfiguration";
    public static final String CONFIGURE_PHOTOSENSOR = "LightingSystem/setPhotoSensing";
    public static final String GET_GATEWAY_IP = "LightingSystem/getIpAddress";
}
