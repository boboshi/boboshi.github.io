package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.SmartLightEntity;
import com.aztech.lmscollector.model.FirmwareEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface FirmwareEventMapper {
    @Mapping(source = "event.parameter.firmwareVersion", target = "firmware")
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    SmartLightEntity toSmartLightEntity(FirmwareEvent event);
}
