package com.aztech.lmscollector.service.exception;

public class NoSuchEventTypeException extends Exception {
    public NoSuchEventTypeException(String message) {
        super(message);
    }
}
