package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.EventEntity;
import com.aztech.lmscollector.model.DeviceEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface DeviceEventMapper {
    @Mapping(source = "senderId", target = "senderId")
    @Mapping(source = "sensorId", target = "sensorId")
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    @Mapping(source = "eventId", target = "eventId")
    @Mapping(source = "eventType", target = "eventType")
    @Mapping(source = "parameterString", target = "parameters")
    @Mapping(source = "userId", target = "userId")
    EventEntity toEventEntity(DeviceEvent event);
}
