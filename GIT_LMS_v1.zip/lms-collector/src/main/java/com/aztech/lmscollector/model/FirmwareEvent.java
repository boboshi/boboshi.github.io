package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FirmwareEvent extends DeviceEvent {
    private FirmwareParameter parameter;

    public FirmwareEvent() {
        this.parameter = new FirmwareParameter();
    }

    @JsonProperty("Parameters")
    public FirmwareParameter getParameter() {
        return parameter;
    }

    public void setParameter(FirmwareParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "FirmwareEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameter=" + parameter +
                '}';
    }
}
