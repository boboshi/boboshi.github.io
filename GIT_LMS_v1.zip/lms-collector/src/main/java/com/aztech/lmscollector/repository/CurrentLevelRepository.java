package com.aztech.lmscollector.repository;

import com.aztech.lmscollector.entity.CurrentLevelEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.IntStream;

@Repository
public class CurrentLevelRepository {
    private static Logger logger = LoggerFactory.getLogger(CurrentLevelRepository.class);
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public CurrentLevelRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public int[] save(List<CurrentLevelEntity> list) {
        // Insertion of current light level record triggers many errors due to duplication of entries. Error logging
        // is commented out until the to-do below resolve the duplicate entries.
        // TODO: query for existing records before insertion
        if (!list.isEmpty()) {
            StringBuilder sql = new StringBuilder();
            sql.append("INSERT IGNORE INTO currentLevel (currentLevel, reportDateTime, lightSN, blockNO) ");
            sql.append("VALUES (:currentLevel, :reportDateTime, :lightSN, :blockNO);");
            int[] done = namedParameterJdbcTemplate.batchUpdate(sql.toString(), SqlParameterSourceUtils.createBatch(list));

//            IntStream.range(0, done.length)
//                    .filter(i -> done[i] != 1)
//                    .forEach(i -> logger.error(String.format("Failed to insert %s", list.get(i))));

            return done;
        }
        return new int[0];
    }
}
