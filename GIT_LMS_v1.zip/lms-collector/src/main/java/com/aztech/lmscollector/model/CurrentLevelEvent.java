package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CurrentLevelEvent extends DeviceEvent {
    private CurrentLevelParameter parameter;

    public CurrentLevelEvent() {
        this.parameter = new CurrentLevelParameter();
    }

    @JsonProperty("Parameters")
    public CurrentLevelParameter getParameter() {
        return parameter;
    }

    public void setParameter(CurrentLevelParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "CurrentLevelEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameter=" + parameter +
                '}';
    }
}
