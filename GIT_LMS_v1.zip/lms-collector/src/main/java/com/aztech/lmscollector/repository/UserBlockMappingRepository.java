package com.aztech.lmscollector.repository;

import com.aztech.lmscollector.entity.UserBlockMapping;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserBlockMappingRepository extends CrudRepository<UserBlockMapping, Long> {
    List<UserBlockMapping> findByBlockId(Long blockId);
}
