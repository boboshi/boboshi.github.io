package com.aztech.lmscollector.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Set;

@Table("userBlock")
public class UserBlockMapping {
    @Id @Column("userBlockId") private Long userBlockId;
    @Column("blockId") private Long blockId;
    @MappedCollection(idColumn = "userId") Set<UserAccountDetail> userAccountDetails;

    public UserBlockMapping(Long blockId, Set<UserAccountDetail> userAccountDetails) {
        this.blockId = blockId;
        this.userAccountDetails = userAccountDetails;
    }

    public Long getUserBlockId() {
        return userBlockId;
    }

    public void setUserBlockId(Long userBlockId) {
        this.userBlockId = userBlockId;
    }

    public Long getBlockId() {
        return blockId;
    }

    public void setBlockId(Long blockId) {
        this.blockId = blockId;
    }

    public Set<UserAccountDetail> getUserAccountDetails() {
        return userAccountDetails;
    }

    public void setUserAccountDetails(Set<UserAccountDetail> userAccountDetails) {
        this.userAccountDetails = userAccountDetails;
    }

    @Override
    public String toString() {
        return "UserBlockMapping{" +
                "userBlockId=" + userBlockId +
                ", blockId=" + blockId +
                ", userAccountDetails=" + userAccountDetails +
                '}';
    }
}
