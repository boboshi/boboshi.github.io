package com.aztech.lmscollector.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("userAccount")
public class UserAccountDetail {
    @Id @Column("userId") private String userId;
    @Column("userMailAddress") private String userMailAddress;

    public UserAccountDetail(String userId, String userMailAddress) {
        this.userId = userId;
        this.userMailAddress = userMailAddress;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserMailAddress() {
        return userMailAddress;
    }

    public void setUserMailAddress(String userMailAddress) {
        this.userMailAddress = userMailAddress;
    }

    @Override
    public String toString() {
        return "UserAccountDetail{" +
                "userId='" + userId + '\'' +
                ", userMailAddress='" + userMailAddress + '\'' +
                '}';
    }
}
