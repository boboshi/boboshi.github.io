package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ClearFaultEvent extends DeviceEvent {
    private ClearFaultParameter parameter;

    public ClearFaultEvent() {
        this.parameter = new ClearFaultParameter();
    }

    @JsonProperty("Parameters")
    public ClearFaultParameter getParameter() {
        return parameter;
    }

    public void setParameter(ClearFaultParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "ClearFaultEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameter=" + parameter +
                '}';
    }
}
