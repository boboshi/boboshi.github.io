package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.BlockEntity;
import com.aztech.lmscollector.model.GatewayIPAddressUpdateEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface GatewayIPAddressUpdateEventMapper {
    @Mapping(source = "blockNumber", target = "blockNO")
    @Mapping(source = "parameter", target = "ipAddress")
    BlockEntity toBlockEntity(GatewayIPAddressUpdateEvent event);
}
