package com.aztech.lmscollector.repository;

import com.aztech.lmscollector.entity.MotionDetectionEntity;
import io.reactivex.rxjava3.core.Observable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;

@Repository
public class MotionDetectionRepository {
    private static Logger logger = LoggerFactory.getLogger(MotionDetectionRepository.class);
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public MotionDetectionRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public int[] save(List<MotionDetectionEntity> list) {
        // Insertion of motion detection record triggers many errors due to duplication of entries. Error logging
        // is commented out until the to-do below resolve the duplicate entries.
        // TODO: query for existing records before insertion
        if (!list.isEmpty()) {
            StringBuilder sql = new StringBuilder();
            sql.append("INSERT IGNORE INTO motionDetect (detectedStatus, reportDateTime, lightSN, blockNO) ");
            sql.append("VALUES (:detectedStatus, :reportDateTime, :lightSN, :blockNO);");
            int[] done = namedParameterJdbcTemplate.batchUpdate(sql.toString(), SqlParameterSourceUtils.createBatch(list));

//            IntStream.range(0, done.length)
//                    .filter(i -> done[i] != 1)
//                    .forEach(i -> logger.error(String.format("Failed to insert %s", list.get(i))));
            return done;
        }
        return new int[0];
    }
}
