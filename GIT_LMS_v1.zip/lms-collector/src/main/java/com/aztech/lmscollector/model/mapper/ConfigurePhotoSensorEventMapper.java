package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.SmartLightEntity;
import com.aztech.lmscollector.model.ConfigurePhotoSensorEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ConfigurePhotoSensorEventMapper {
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    @Mapping(source = "event.parameter.photoSensing", target = "photoSensing")
    @Mapping(source = "event.parameter.photoSensorUpperThreshold", target = "photoUpperThreshold")
    @Mapping(source = "event.parameter.photoSensorLowerThreshold", target = "photoLowerThreshold")
    SmartLightEntity toSmartLightEntity(ConfigurePhotoSensorEvent event);
}
