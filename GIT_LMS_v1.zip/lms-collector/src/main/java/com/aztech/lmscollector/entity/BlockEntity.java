package com.aztech.lmscollector.entity;

public class BlockEntity {
    private String blockNO;
    private String ipAddress;

    public BlockEntity() {
        this.blockNO = "";
        this.ipAddress = "";
    }

    public String getBlockNO() {
        return blockNO;
    }

    public void setBlockNO(String blockNO) {
        this.blockNO = blockNO;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    @Override
    public String toString() {
        return "BlockEntity{" +
                "blockNO='" + blockNO + '\'' +
                ", ipAddress='" + ipAddress + '\'' +
                '}';
    }
}
