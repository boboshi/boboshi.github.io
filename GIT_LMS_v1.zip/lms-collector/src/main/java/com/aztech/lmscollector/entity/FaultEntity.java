package com.aztech.lmscollector.entity;

import java.time.Instant;
import java.util.Date;

public class FaultEntity {
    private String eventId;
    private String eventType;
    private String lightSN;
    private String blockNO;
    private Date reportDateTime;
    private int severity;
    private String tripGeneralAlarm;
    private String description;
    private String faultCode;
    private String faultCleared;

    public FaultEntity() {
        this.eventId = "";
        this.eventType = "";
        this.lightSN = "";
        this.blockNO = "";
        this.reportDateTime = Date.from(Instant.now());
        this.severity = 1;
        this.tripGeneralAlarm = "Yes";
        this.description = "Light Fault";
        this.faultCode = "AZ-LS-FC";
        this.faultCleared = "0";
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getLightSN() {
        return lightSN;
    }

    public void setLightSN(String lightSN) {
        this.lightSN = lightSN;
    }

    public String getBlockNO() {
        return blockNO;
    }

    public void setBlockNO(String blockNO) {
        this.blockNO = blockNO;
    }

    public Date getReportDateTime() {
        return reportDateTime;
    }

    public void setReportDateTime(Date reportDateTime) {
        this.reportDateTime = reportDateTime;
    }

    public int getSeverity() {
        return severity;
    }

    public void setSeverity(int severity) {
        this.severity = severity;
    }

    public String getTripGeneralAlarm() {
        return tripGeneralAlarm;
    }

    public void setTripGeneralAlarm(String tripGeneralAlarm) {
        this.tripGeneralAlarm = tripGeneralAlarm;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFaultCode() {
        return faultCode;
    }

    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }

    public String getFaultCleared() {
        return faultCleared;
    }

    public void setFaultCleared(String faultCleared) {
        this.faultCleared = faultCleared;
    }

    @Override
    public String toString() {
        return "FaultEntity{" +
                "eventId='" + eventId + '\'' +
                ", eventType='" + eventType + '\'' +
                ", lightSN='" + lightSN + '\'' +
                ", blockNO='" + blockNO + '\'' +
                ", reportDateTime=" + reportDateTime +
                ", severity=" + severity +
                ", tripGeneralAlarm='" + tripGeneralAlarm + '\'' +
                ", description='" + description + '\'' +
                ", faultCode='" + faultCode + '\'' +
                ", faultCleared='" + faultCleared + '\'' +
                '}';
    }
}
