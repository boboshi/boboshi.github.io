package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConfigureLightParameter {
    private String commandType;
    private String motionSensing;
    private int motionSensitivity;
    private int dimLevel;
    private int motionLevel;
    private int brightnessLevel;
    private int holdTime;
    private int lightIntensity;
    private String clockSync;
    private String scheduling;
    private String photoSensorGroup;
    private String brightnessGroup;

    public ConfigureLightParameter() {
        this.commandType = "";
        this.motionSensing = "Enable";
        this.motionSensitivity = 2;
        this.dimLevel = 20;
        this.motionLevel = 10;
        this.brightnessLevel = 10;
        this.holdTime = 15;
        this.lightIntensity = 3;
        this.clockSync = "Enable";
        this.scheduling = "Enable";
        this.photoSensorGroup = "07001859";
        this.brightnessGroup = "19002359";
    }

    @JsonProperty("CommandType")
    public String getCommandType() {
        return commandType;
    }

    public void setCommandType(String commandType) {
        this.commandType = commandType;
    }

    @JsonProperty("MotionSensing")
    public String getMotionSensing() {
        return motionSensing;
    }

    public void setMotionSensing(String motionSensing) {
        this.motionSensing = motionSensing;
    }

    @JsonProperty("MotionSensitivity")
    public int getMotionSensitivity() {
        return motionSensitivity;
    }

    public void setMotionSensitivity(int motionSensitivity) {
        this.motionSensitivity = motionSensitivity;
    }

    @JsonProperty("DimLevel")
    public int getDimLevel() {
        return dimLevel;
    }

    public void setDimLevel(int dimLevel) {
        this.dimLevel = dimLevel;
    }

    @JsonProperty("MotionLevel")
    public int getMotionLevel() {
        return motionLevel;
    }

    public void setMotionLevel(int motionLevel) {
        if (motionLevel <= 10) {
            motionLevel *= 10;
        }
        if (motionLevel > 100) {
            motionLevel = 100;
        }
        this.motionLevel = motionLevel;
    }

    @JsonProperty("BrightLevel")
    public int getBrightnessLevel() {
        return brightnessLevel;
    }

    public void setBrightnessLevel(int brightnessLevel) {
        if (brightnessLevel <= 10) {
            brightnessLevel *= 10;
        }
        if (brightnessLevel > 100) {
            brightnessLevel = 100;
        }
        this.brightnessLevel = brightnessLevel;
    }

    @JsonProperty("HoldTime")
    public int getHoldTime() {
        return holdTime;
    }

    public void setHoldTime(int holdTime) {
        this.holdTime = holdTime;
    }

    @JsonProperty("LightIntensity")
    public int getLightIntensity() {
        return lightIntensity;
    }

    public void setLightIntensity(int lightIntensity) {
        this.lightIntensity = lightIntensity;
    }

    @JsonProperty("ClockSync")
    public String getClockSync() {
        return clockSync;
    }

    public void setClockSync(String clockSync) {
        this.clockSync = clockSync;
    }

    @JsonProperty("Scheduling")
    public String getScheduling() {
        return scheduling;
    }

    public void setScheduling(String scheduling) {
        this.scheduling = scheduling;
    }

    @JsonProperty("PhotosensorGroup")
    public String getPhotoSensorGroup() {
        return photoSensorGroup;
    }

    public void setPhotoSensorGroup(String photoSensorGroup) {
        this.photoSensorGroup = photoSensorGroup;
    }

    @JsonProperty("BrightGroup")
    public String getBrightnessGroup() {
        return brightnessGroup;
    }

    public void setBrightnessGroup(String brightnessGroup) {
        this.brightnessGroup = brightnessGroup;
    }

    @Override
    public String toString() {
        return "ConfigureLightParameter{" +
                "commandType='" + commandType + '\'' +
                ", motionSensing='" + motionSensing + '\'' +
                ", motionSensitivity=" + motionSensitivity +
                ", dimLevel=" + dimLevel +
                ", motionLevel=" + motionLevel +
                ", brightnessLevel=" + brightnessLevel +
                ", holdTime=" + holdTime +
                ", lightIntensity=" + lightIntensity +
                ", clockSync='" + clockSync + '\'' +
                ", scheduling='" + scheduling + '\'' +
                ", photoSensorGroup='" + photoSensorGroup + '\'' +
                ", brightnessGroup='" + brightnessGroup + '\'' +
                '}';
    }
}
