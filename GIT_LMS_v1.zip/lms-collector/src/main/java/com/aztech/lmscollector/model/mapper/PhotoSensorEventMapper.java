package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.PhotoSensorEntity;
import com.aztech.lmscollector.model.PhotoSensorEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PhotoSensorEventMapper {
    @Mapping(source = "event.parameter.photoSensorLevel", target = "photosensorLevel")
    @Mapping(source = "event.parameter.reportedDate", target = "reportDateTime")
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    PhotoSensorEntity toPhotoSensorEntity(PhotoSensorEvent event);
}
