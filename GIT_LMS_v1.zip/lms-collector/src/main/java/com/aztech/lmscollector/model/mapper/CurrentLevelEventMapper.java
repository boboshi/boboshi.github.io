package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.CurrentLevelEntity;
import com.aztech.lmscollector.model.CurrentLevelEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CurrentLevelEventMapper {
    @Mapping(source = "event.parameter.currentLevel", target = "currentLevel")
    @Mapping(source = "event.parameter.reportedDate", target = "reportDateTime")
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    CurrentLevelEntity toCurrentLevelEntity(CurrentLevelEvent event);
}
