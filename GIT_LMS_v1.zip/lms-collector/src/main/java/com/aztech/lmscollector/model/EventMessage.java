package com.aztech.lmscollector.model;

public class EventMessage {
    private String topic;
    private String message;

    public EventMessage(String topic, String message) {
        this.topic = topic;
        this.message = message;
    }

    public String getTopic() {
        return topic;
    }

    public String getMessage() {
        return message;
    }
}
