package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.Date;

public class CurrentLevelParameter {
    private int currentLevel;
    private Date reportedDate;

    public CurrentLevelParameter() {
        this.currentLevel = 100;
        this.reportedDate = Date.from(Instant.now());
    }

    @JsonProperty("LightLevel")
    public int getCurrentLevel() {
        return currentLevel;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    @JsonProperty("Time")
    public Date getReportedDate() {
        return reportedDate;
    }

    public void setReportedDate(Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    @Override
    public String toString() {
        return "CurrentLevelParameter{" +
                "currentLevel=" + currentLevel +
                ", reportedDate=" + reportedDate +
                '}';
    }
}
