package com.aztech.lmscollector.entity;

import java.time.Instant;
import java.util.Date;
import java.util.Objects;

public class PhotoSensorEntity {
    private int photosensorLevel;
    private Date reportDateTime;
    private String lightSN;
    private String blockNO;

    public PhotoSensorEntity() {
        this.photosensorLevel = 1;
        this.reportDateTime = Date.from(Instant.now());
        this.lightSN = "";
        this.blockNO = "";
    }

    public int getPhotosensorLevel() {
        return photosensorLevel;
    }

    public void setPhotosensorLevel(int photosensorLevel) {
        this.photosensorLevel = photosensorLevel;
    }

    public Date getReportDateTime() {
        return reportDateTime;
    }

    public void setReportDateTime(Date reportDateTime) {
        this.reportDateTime = reportDateTime;
    }

    public String getLightSN() {
        return lightSN;
    }

    public void setLightSN(String lightSN) {
        this.lightSN = lightSN;
    }

    public String getBlockNO() {
        return blockNO;
    }

    public void setBlockNO(String blockNO) {
        this.blockNO = blockNO;
    }

    @Override
    public String toString() {
        return "PhotoSensorEntity{" +
                "photosensorLevel=" + photosensorLevel +
                ", reportDateTime=" + reportDateTime +
                ", lightSN='" + lightSN + '\'' +
                ", blockNO='" + blockNO + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PhotoSensorEntity)) return false;
        PhotoSensorEntity that = (PhotoSensorEntity) o;
        return photosensorLevel == that.photosensorLevel &&
                Objects.equals(reportDateTime, that.reportDateTime) &&
                Objects.equals(lightSN, that.lightSN) &&
                Objects.equals(blockNO, that.blockNO);
    }

    @Override
    public int hashCode() {
        return Objects.hash(photosensorLevel, reportDateTime, lightSN, blockNO);
    }
}
