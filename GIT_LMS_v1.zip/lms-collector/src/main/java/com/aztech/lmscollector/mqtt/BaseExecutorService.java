package com.aztech.lmscollector.mqtt;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class BaseExecutorService {
    private static Logger logger = LoggerFactory.getLogger(BaseExecutorService.class);
    private final ExecutorService executorService;

    public BaseExecutorService(int poolSize) {
        executorService = Executors.newFixedThreadPool(poolSize);
    }

    public void close() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(10, TimeUnit.SECONDS)) {
                logger.info("Graceful termination of executor service is taking too long, shutdown immediately");
                executorService.shutdownNow();
            }
            logger.info("Terminated executor service");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public ExecutorService getExecutorService() {
        return executorService;
    }
}
