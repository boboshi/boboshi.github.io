package com.aztech.lmscollector.repository;

import com.aztech.lmscollector.entity.BlockEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.IntStream;

@Repository
public class BlockRepository {
    private static final Logger logger = LoggerFactory.getLogger(BlockRepository.class);
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public BlockRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public int[] save(List<BlockEntity> list) {
        if (!list.isEmpty()) {
            String sql = "UPDATE block SET ipAddress = :ipAddress WHERE blockNO = :blockNO;";
            int[] done = namedParameterJdbcTemplate.batchUpdate(sql, SqlParameterSourceUtils.createBatch(list));
            IntStream.of(done)
                    .filter(i -> i != 1)
                    .forEach(i -> logger.error(String.format("Failed to update %s", list.get(i))));
            return done;
        }
        return new int[0];
    }
}
