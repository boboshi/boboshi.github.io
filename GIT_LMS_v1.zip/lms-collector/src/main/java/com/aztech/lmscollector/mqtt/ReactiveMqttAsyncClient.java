package com.aztech.lmscollector.mqtt;

import com.aztech.lmscollector.model.EventMessage;
import io.reactivex.rxjava3.core.Observable;
import org.eclipse.paho.client.mqttv3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

public class ReactiveMqttAsyncClient {
    private static Logger logger = LoggerFactory.getLogger(ReactiveMqttAsyncClient.class);
    private MqttAsyncClient mqttAsyncClient;


    private Observable<EventMessage> eventMessageObservable;

    private ReactiveMqttAsyncClient(
            SmartCollectorMqttConfiguration configuration,
            MqttConnectOptions mqttConnectOptions) throws MqttException {

        mqttAsyncClient = new MqttAsyncClient(
                configuration.getBrokerUrl(),
                configuration.getClientIdPrefix() + new Date().getTime());

        IMqttToken connectionToken = mqttAsyncClient.connect(mqttConnectOptions);
        connectionToken.waitForCompletion();

        eventMessageObservable = Observable.create(emitter -> {
            logger.info(String.format("Subscribing to topic '%s' as '%s' at qos=%d",
                    configuration.getTopic(),
                    mqttAsyncClient.getClientId(),
                    configuration.getQos()));

            IMqttToken subToken = mqttAsyncClient.subscribe(configuration.getTopic(), configuration.getQos(), (topic, message) -> {
                if (!emitter.isDisposed()) {
                    emitter.onNext(new EventMessage(topic, new String(message.getPayload())));
                }
            });
            subToken.waitForCompletion();
            emitter.setCancellable(() -> mqttAsyncClient.unsubscribe(configuration.getTopic()));

        });

    }

    public void close() {
        if (mqttAsyncClient.isConnected()) {
            try {
                logger.info("Disconnecting from broker");
                mqttAsyncClient.disconnect(10000,null, new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken iMqttToken) {
                        logger.info("Successfully disconnected from broker");
                        try {
                            mqttAsyncClient.close();
                            logger.info("Resource is freed and client is closed");
                        } catch (MqttException e) {
                            throw new RuntimeException(e);
                        }
                    }

                    @Override
                    public void onFailure(IMqttToken iMqttToken, Throwable throwable) {
                        logger.info("Failed to disconnect from broker. Need to forcibly disconnect.");
                        logger.info(throwable.getMessage());
                        try {
                            mqttAsyncClient.disconnectForcibly();
                            logger.info("Client has been forcibly disconnected from broker");
                        } catch (MqttException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static ReactiveMqttAsyncClient create(
            SmartCollectorMqttConfiguration configuration,
            MqttConnectOptions mqttConnectOptions) throws MqttException {

        return new ReactiveMqttAsyncClient(configuration, mqttConnectOptions);
    }

    public Observable<EventMessage> getEventMessageObservable() {
        return eventMessageObservable;
    }
}
