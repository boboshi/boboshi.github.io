package com.aztech.lmscollector.entity;

import java.util.Objects;

public class EventEntity {
    private String senderId;
    private String sensorId;
    private String lightSN;
    private String blockNO;
    private String eventId;
    private String eventType;
    private String parameters;
    private int userId;

    public EventEntity() {
        this.senderId = "";
        this.sensorId = "";
        this.lightSN = "";
        this.blockNO = "";
        this.eventId = "";
        this.eventType = "";
        this.parameters = "";
        this.userId = -1;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSensorId() {
        return sensorId;
    }

    public void setSensorId(String sensorId) {
        this.sensorId = sensorId;
    }

    public String getLightSN() {
        return lightSN;
    }

    public void setLightSN(String lightSN) {
        this.lightSN = lightSN;
    }

    public String getBlockNO() {
        return blockNO;
    }

    public void setBlockNO(String blockNO) {
        this.blockNO = blockNO;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getParameters() {
        return parameters;
    }

    public void setParameters(String parameters) {
        this.parameters = parameters;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "EventEntity{" +
                "senderId='" + senderId + '\'' +
                ", sensorId='" + sensorId + '\'' +
                ", lightSN='" + lightSN + '\'' +
                ", blockNO='" + blockNO + '\'' +
                ", eventId='" + eventId + '\'' +
                ", eventType='" + eventType + '\'' +
                ", parameters='" + parameters + '\'' +
                ", userId=" + userId +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EventEntity)) return false;
        EventEntity that = (EventEntity) o;
        return userId == that.userId &&
                Objects.equals(senderId, that.senderId) &&
                Objects.equals(sensorId, that.sensorId) &&
                Objects.equals(lightSN, that.lightSN) &&
                Objects.equals(blockNO, that.blockNO) &&
                Objects.equals(eventId, that.eventId) &&
                Objects.equals(eventType, that.eventType) &&
                Objects.equals(parameters, that.parameters);
    }

    @Override
    public int hashCode() {
        return Objects.hash(senderId, sensorId, lightSN, blockNO, eventId, eventType, parameters, userId);
    }
}
