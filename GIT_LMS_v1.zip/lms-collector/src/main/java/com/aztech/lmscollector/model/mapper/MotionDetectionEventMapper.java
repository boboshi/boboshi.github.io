package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.MotionDetectionEntity;
import com.aztech.lmscollector.model.MotionDetectionEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface MotionDetectionEventMapper {
    @Mapping(source = "event.parameter.detectedStatus", target = "detectedStatus")
    @Mapping(source = "event.parameter.reportedDate", target = "reportDateTime")
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    MotionDetectionEntity toMotionDetectionEntity(MotionDetectionEvent event);
}
