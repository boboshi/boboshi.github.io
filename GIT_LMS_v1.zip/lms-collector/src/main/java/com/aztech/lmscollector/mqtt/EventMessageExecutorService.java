package com.aztech.lmscollector.mqtt;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EventMessageExecutorService extends BaseExecutorService {
    private static final Logger logger = LoggerFactory.getLogger(EventMessageExecutorService.class);
    public static EventMessageExecutorService instance = null;

    public EventMessageExecutorService(int poolSize) {
        super(poolSize);
        logger.info(String.format("Initialized thread pool with size of 10"));
    }

    public static EventMessageExecutorService create(int poolSize) {
        if (instance == null) {
            instance = new EventMessageExecutorService(poolSize);
        }
        return instance;
    }
}
