package com.aztech.lmscollector.repository;

import com.aztech.lmscollector.entity.FaultEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Repository
public class FaultReportRepository {
    private static Logger logger = LoggerFactory.getLogger(FaultReportRepository.class);
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public FaultReportRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public int[] save(List<FaultEntity> list) {
        if (!list.isEmpty()) {
            // The following columns are unique in the faultReport table and trigger DuplicateKeyException
            // if duplicated insertion is performed. In that case, just update the reportDateTime of that row.
            // Unique keys: lightSN,  blockId, severity, tripGeneralAlarm, description, faultCode, faultCleared

            StringBuilder testInsertSql = new StringBuilder();
            testInsertSql.append("INSERT INTO faultReport (eventId, eventType, lightSN, blockNO, reportDateTime, severity, tripGeneralAlarm, description, faultCode) ");
            testInsertSql.append("VALUES (:eventId, :eventType, :lightSN, :blockNO, :reportDateTime, :severity, :tripGeneralAlarm, :description, :faultCode);");

            StringBuffer updateInsertSql = new StringBuffer();
            updateInsertSql.append("INSERT IGNORE INTO faultReport (eventId, eventType, lightSN, blockNO, reportDateTime, severity, tripGeneralAlarm, description, faultCode) ");
            updateInsertSql.append("VALUES (:eventId, :eventType, :lightSN, :blockNO, :reportDateTime, :severity, :tripGeneralAlarm, :description, :faultCode) ");
            updateInsertSql.append("ON DUPLICATE KEY UPDATE reportDateTime = :reportDateTime;");

            int[] done = Stream.of(SqlParameterSourceUtils.createBatch(list)).mapToInt(params -> {
                try {
                    namedParameterJdbcTemplate.update(testInsertSql.toString(), params);
                    return 1;
                } catch (DuplicateKeyException duplicateKeyException) {
                    namedParameterJdbcTemplate.update(updateInsertSql.toString(), params);
                    return -1;
                } catch (Exception e) {
                    logger.error(String.format("Failed to insert %s", params.toString()));
                    return 0;
                }
            }).toArray();

            return done;
        }

        return new int[0];
    }

    public int[] update(List<FaultEntity> list) {
        if (!list.isEmpty()) {
            String sql = "UPDATE faultReport SET faultCleared=:faultCleared WHERE eventId=:eventId;";
            int[] done = namedParameterJdbcTemplate.batchUpdate(sql.toString(), SqlParameterSourceUtils.createBatch(list));
            IntStream.range(0, done.length)
                    .filter(i -> done[i] != 1)
                    .forEach(i -> logger.error(String.format("Failed to insert %s", list.get(i))));
            return done;
        }
        return new int[0];
    }
}
