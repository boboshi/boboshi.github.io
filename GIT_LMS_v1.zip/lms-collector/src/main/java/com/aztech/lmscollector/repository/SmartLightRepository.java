package com.aztech.lmscollector.repository;


import com.aztech.lmscollector.entity.SmartLightEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.IntStream;

@Repository
public class SmartLightRepository {
    private static Logger logger = LoggerFactory.getLogger(SmartLightRepository.class);
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public SmartLightRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public void update(List<SmartLightEntity> list) {
        if (!list.isEmpty()) {
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE smartLight SET firmware = :firmware ");
            sql.append("WHERE blockId = (SELECT blockId from block WHERE blockNO = :blockNO) AND displayName = :lightSN;");
            int[] done = namedParameterJdbcTemplate.batchUpdate(sql.toString(), SqlParameterSourceUtils.createBatch(list));

            IntStream.range(0, done.length)
                    .filter(i -> done[i] != 1)
                    .forEach(i -> logger.error(String.format("Failed to insert %s", list.get(i))));

        }
    }

    public void updateLightConfiguration(List<SmartLightEntity> list) {
        if (!list.isEmpty()) {
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE smartLight ");
            sql.append("SET motionSensing=:motionSensing,motionSensitivity=:motionSensitivity,dimLevel=:dimLevel,motionLevel=:motionLevel,brightLevel=:brightLevel,");
            sql.append("holdTime=:holdTime,clockSync=:clockSync,scheduling=:scheduling,photosensorGroup=:photosensorGroup,brightGroup=:brightGroup ");
            sql.append("WHERE blockId = (SELECT blockId from block WHERE blockNO=:blockNO) AND displayName=:lightSN;");

            int[] done = namedParameterJdbcTemplate.batchUpdate(sql.toString(), SqlParameterSourceUtils.createBatch(list));

            IntStream.range(0, done.length)
                    .filter(i -> done[i] != 1)
                    .forEach(i -> logger.error(String.format("Failed to insert %s", list.get(i))));
        }
    }

    public int[] updatePhotoSensorConfiguration(List<SmartLightEntity> list) {
        if (!list.isEmpty()) {
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE smartLight ");
            sql.append("SET photoSensing=:photoSensing,photoUpperThreshold=:photoUpperThreshold,photoLowerThreshold=:photoLowerThreshold ");
            sql.append("WHERE blockId = (SELECT blockId from block WHERE blockNO=:blockNO) AND displayName=:lightSN;");

            int[] done = namedParameterJdbcTemplate.batchUpdate(sql.toString(), SqlParameterSourceUtils.createBatch(list));

            IntStream.range(0, done.length)
                    .filter(i -> done[i] != 1)
                    .forEach(i -> logger.error(String.format("Failed to insert %s", list.get(i))));
            return done;
        }
        return new int[0];
    }
}
