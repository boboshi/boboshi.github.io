package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.entity.FaultEntity;
import com.aztech.lmscollector.model.ClearFaultEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ClearFaultEventMapper {
    @Mapping(source = "event.parameter.referenceEventId", target = "eventId")
    @Mapping(source = "eventId", target = "faultCleared")
    @Mapping(source = "lightId", target = "lightSN")
    @Mapping(source = "blockNumber", target = "blockNO")
    FaultEntity toFaultEntity(ClearFaultEvent event);
}
