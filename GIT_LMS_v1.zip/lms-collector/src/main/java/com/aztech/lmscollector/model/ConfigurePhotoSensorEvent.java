package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConfigurePhotoSensorEvent extends DeviceEvent {
    private ConfigurePhotoSensorParameter parameter;

    public ConfigurePhotoSensorEvent() {
        this.parameter = new ConfigurePhotoSensorParameter();
    }

    @JsonProperty("Parameters")
    public ConfigurePhotoSensorParameter getParameter() {
        return parameter;
    }

    public void setParameter(ConfigurePhotoSensorParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "ConfigurePhotoSensorEvent{" +
                "DeviceEvent=" + super.toString() +
                " ,parameter=" + parameter +
                '}';
    }
}
