package com.aztech.lmscollector.entity;

import java.time.Instant;
import java.util.Date;
import java.util.Objects;

public class MotionDetectionEntity {
    private int detectedStatus;
    private Date reportDateTime;
    private String lightSN;
    private String blockNO;

    public MotionDetectionEntity() {
        this.detectedStatus = 0;
        this.reportDateTime = Date.from(Instant.now());
        this.lightSN = "";
        this.blockNO = "";
    }

    public int getDetectedStatus() {
        return detectedStatus;
    }

    public void setDetectedStatus(int detectedStatus) {
        this.detectedStatus = detectedStatus;
    }

    public Date getReportDateTime() {
        return reportDateTime;
    }

    public void setReportDateTime(Date reportDateTime) {
        this.reportDateTime = reportDateTime;
    }

    public String getLightSN() {
        return lightSN;
    }

    public void setLightSN(String lightSN) {
        this.lightSN = lightSN;
    }

    public String getBlockNO() {
        return blockNO;
    }

    public void setBlockNO(String blockNO) {
        this.blockNO = blockNO;
    }

    @Override
    public String toString() {
        return "MotionDetectionEntity{" +
                "detectedStatus=" + detectedStatus +
                ", reportDateTime='" + reportDateTime + '\'' +
                ", lightSN='" + lightSN + '\'' +
                ", blockNO='" + blockNO + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MotionDetectionEntity)) return false;
        MotionDetectionEntity that = (MotionDetectionEntity) o;
        return detectedStatus == that.detectedStatus &&
                Objects.equals(reportDateTime, that.reportDateTime) &&
                Objects.equals(lightSN, that.lightSN) &&
                Objects.equals(blockNO, that.blockNO);
    }

    @Override
    public int hashCode() {
        return Objects.hash(detectedStatus, reportDateTime, lightSN, blockNO);
    }
}
