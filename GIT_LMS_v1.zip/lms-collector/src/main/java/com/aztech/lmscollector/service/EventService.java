package com.aztech.lmscollector.service;

import com.aztech.lmscollector.entity.EventEntity;
import com.aztech.lmscollector.entity.FaultEntity;
import com.aztech.lmscollector.entity.UserAccountDetail;
import com.aztech.lmscollector.model.*;
import com.aztech.lmscollector.model.mapper.ClearFaultEventMapper;
import com.aztech.lmscollector.model.mapper.ConfigureLightEventMapper;
import com.aztech.lmscollector.model.mapper.ConfigurePhotoSensorEventMapper;
import com.aztech.lmscollector.model.mapper.CurrentLevelEventMapper;
import com.aztech.lmscollector.model.mapper.DeviceEventMainMapper;
import com.aztech.lmscollector.model.mapper.DeviceEventMapper;
import com.aztech.lmscollector.model.mapper.FaultEventMapper;
import com.aztech.lmscollector.model.mapper.FirmwareEventMapper;
import com.aztech.lmscollector.model.mapper.GatewayIPAddressUpdateEventMapper;
import com.aztech.lmscollector.model.mapper.MotionDetectionEventMapper;
import com.aztech.lmscollector.model.mapper.PhotoSensorEventMapper;
import com.aztech.lmscollector.mqtt.IOExecutorService;
import com.aztech.lmscollector.repository.BlockRepository;
import com.aztech.lmscollector.repository.CurrentLevelRepository;
import com.aztech.lmscollector.repository.EventRepository;
import com.aztech.lmscollector.repository.FaultReportRepository;
import com.aztech.lmscollector.repository.MotionDetectionRepository;
import com.aztech.lmscollector.repository.PhotoSensorRepository;
import com.aztech.lmscollector.repository.SmartLightRepository;
import com.aztech.lmscollector.repository.UserAccountDetailRepository;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.observables.ConnectableObservable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.toList;

@Service
public class EventService {
    private static Logger logger = LoggerFactory.getLogger(EventService.class);

    private MotionDetectionEventMapper motionDetectionEventMapper;
    private CurrentLevelEventMapper currentLevelEventMapper;
    private PhotoSensorEventMapper photoSensorEventMapper;
    private FirmwareEventMapper firmwareEventMapper;
    private FaultEventMapper faultEventMapper;
    private GatewayIPAddressUpdateEventMapper gatewayIPAddressUpdateEventMapper;
    private ConfigureLightEventMapper configureLightEventMapper;
    private ConfigurePhotoSensorEventMapper configurePhotoSensorEventMapper;
    private DeviceEventMapper deviceEventMapper;
    private ClearFaultEventMapper clearFaultEventMapper;
    private EventRepository eventRepository;
    private IOExecutorService ioExecutorService;
    private MotionDetectionRepository motionDetectionRepository;
    private CurrentLevelRepository currentLevelRepository;
    private PhotoSensorRepository photoSensorRepository;
    private SmartLightRepository smartLightRepository;
    private FaultReportRepository faultReportRepository;
    private UserAccountDetailRepository userAccountDetailRepository;
    private BlockRepository blockRepository;

    public Observable<DeviceEvent> parametersObservable = null;

    private AtomicLong motionDetectionEventCounter = new AtomicLong(0);
    private AtomicLong currentLevelEventCounter = new AtomicLong(0);
    private AtomicLong photoSensorEventCounter = new AtomicLong(0);
    private AtomicLong firmwareEventCounter = new AtomicLong(0);
    private AtomicLong gatewayIPAddressUpdateEventCounter = new AtomicLong(0);
    private AtomicLong faultEventCounter = new AtomicLong(0);
    private AtomicLong clearFaultEventCounter = new AtomicLong(0);
    private AtomicLong configureLightEventCounter = new AtomicLong(0);
    private AtomicLong configurePhotoSensorEventCounter = new AtomicLong(0);

    public EventService(
            MotionDetectionEventMapper motionDetectionEventMapper,
            CurrentLevelEventMapper currentLevelEventMapper,
            PhotoSensorEventMapper photoSensorEventMapper,
            FirmwareEventMapper firmwareEventMapper,
            FaultEventMapper faultEventMapper,
            GatewayIPAddressUpdateEventMapper gatewayIPAddressUpdateEventMapper,
            ConfigureLightEventMapper configureLightEventMapper,
            ConfigurePhotoSensorEventMapper configurePhotoSensorEventMapper,
            DeviceEventMapper deviceEventMapper,
            ClearFaultEventMapper clearFaultEventMapper,
            EventRepository eventRepository,
            IOExecutorService ioExecutorService,
            MotionDetectionRepository motionDetectionRepository,
            CurrentLevelRepository currentLevelRepository,
            PhotoSensorRepository photoSensorRepository,
            SmartLightRepository smartLightRepository,
            FaultReportRepository faultReportRepository,
            UserAccountDetailRepository userAccountDetailRepository,
            BlockRepository blockRepository,
            MeterRegistry meterRegistry) {

        this.motionDetectionEventMapper = motionDetectionEventMapper;
        this.currentLevelEventMapper = currentLevelEventMapper;
        this.photoSensorEventMapper = photoSensorEventMapper;
        this.firmwareEventMapper = firmwareEventMapper;
        this.faultEventMapper = faultEventMapper;
        this.gatewayIPAddressUpdateEventMapper = gatewayIPAddressUpdateEventMapper;
        this.configureLightEventMapper = configureLightEventMapper;
        this.configurePhotoSensorEventMapper = configurePhotoSensorEventMapper;
        this.deviceEventMapper = deviceEventMapper;
        this.clearFaultEventMapper = clearFaultEventMapper;
        this.eventRepository = eventRepository;
        this.ioExecutorService = ioExecutorService;
        this.motionDetectionRepository = motionDetectionRepository;
        this.currentLevelRepository = currentLevelRepository;
        this.photoSensorRepository = photoSensorRepository;
        this.smartLightRepository = smartLightRepository;
        this.faultReportRepository = faultReportRepository;
        this.userAccountDetailRepository = userAccountDetailRepository;
        this.blockRepository = blockRepository;

        Map<String, AtomicLong> counters = new HashMap<>();
        counters.put(EventType.MOTION_READING, motionDetectionEventCounter);
        counters.put(EventType.LIGHTLEVEL_READING, currentLevelEventCounter);
        counters.put(EventType.PHOTOSENSOR_READING, photoSensorEventCounter);
        counters.put(EventType.FIRMWARE_READING, firmwareEventCounter);
        counters.put(EventType.GET_GATEWAY_IP, gatewayIPAddressUpdateEventCounter);
        counters.put(EventType.LIGHT_FAULT, faultEventCounter);
        counters.put(EventType.FAULT_CLEAR, clearFaultEventCounter);
        counters.put(EventType.CONFIGURE_LIGHT, configureLightEventCounter);
        counters.put(EventType.CONFIGURE_PHOTOSENSOR, configurePhotoSensorEventCounter);
        initializeEventCounters(meterRegistry, counters);
    }

    public void processEvents(List<EventMessage> eventMessages) {
        List<DeviceEvent> events = eventMessages.stream()
                .map(this::fromEventMessage)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(toList());

        processDeviceEvents(events);

//        List<EventEntity> eventWithSenderId = events.stream()
//                .filter(event -> !event.getSenderId().trim().isEmpty())
//                .map(event -> deviceEventMapper.toEventEntity(event))
//                .distinct()
//                .collect(toList());
//
//        eventRepository.save(eventWithSenderId);

        List<EventEntity> eventWithUserId = events.stream()
                .filter(event -> event.getUserId() != -1)
                .map(event -> deviceEventMapper.toEventEntity(event))
                .distinct()
                .collect(toList());

        eventRepository.save(eventWithUserId);
    }

    private Optional<DeviceEvent> fromEventMessage(EventMessage message) {
        try {
            return Optional.of(DeviceEventMainMapper.fromEventMessage(message));
        } catch (Exception e) {
            logger.error(String.format("Failed to process message '%s'.\nUnable to convert message to it's internal event representation due to:\n%s",
                    message.getMessage(),
                    e.getMessage()));
        }
        return Optional.empty();
    }

    private void processDeviceEvents(List<DeviceEvent> events) {
        ConnectableObservable<DeviceEvent> parametersObservable =
                Observable.fromStream(events.stream())
                        .subscribeOn(Schedulers.from(ioExecutorService.getExecutorService()))
                        .publish();

        this.parametersObservable = parametersObservable;

        parametersObservable
                .filter(parameters -> EventType.MOTION_READING.equals(parameters.getEventType()))
                .map(event -> motionDetectionEventMapper.toMotionDetectionEntity((MotionDetectionEvent) event))
                .distinct()
                .collect(toList())
                .subscribe(list -> {
//                    logger.info("MQTT EventType: MotionDetect");
                    motionDetectionEventCounter.getAndAdd(list.size());
                    motionDetectionRepository.save(list);
                }, error -> { logger.error(error.getMessage()); });

        parametersObservable
                .filter(parameters -> EventType.LIGHTLEVEL_READING.equals(parameters.getEventType()))
                .map(event -> currentLevelEventMapper.toCurrentLevelEntity((CurrentLevelEvent) event))
                .distinct()
                .collect(toList())
                .subscribe(list -> {
//                    logger.info("MQTT EventType: CurrentLevel");
                    currentLevelEventCounter.getAndAdd(list.size());
                    currentLevelRepository.save(list);
                }, error -> { logger.error(error.getMessage()); });

        parametersObservable
                .filter(parameters -> EventType.PHOTOSENSOR_READING.equals(parameters.getEventType()))
                .map(event -> photoSensorEventMapper.toPhotoSensorEntity((PhotoSensorEvent) event))
                .distinct()
                .collect(toList())
                .subscribe(list -> {
//                    logger.info("MQTT EventType: PhotosensorLux");
                    photoSensorEventCounter.getAndAdd(list.size());
                    photoSensorRepository.save(list);
                }, error -> { logger.error(error.getMessage()); });

        parametersObservable
                .filter(parameters -> EventType.FIRMWARE_READING.equals(parameters.getEventType()))
                .map(event -> firmwareEventMapper.toSmartLightEntity((FirmwareEvent) event))
                .collect(toList())
                .subscribe(list -> {
//                    logger.info("MQTT EventType: FirmwareVersion");
                    firmwareEventCounter.getAndAdd(list.size());
                    smartLightRepository.update(list);
                }, error -> { logger.error(error.getMessage()); });

        parametersObservable
                .filter(parameters -> EventType.LIGHT_FAULT.equals(parameters.getEventType()))
                .map(event -> faultEventMapper.toFaultEntity((FaultEvent) event))
                .collect(toList())
                .subscribe(list -> {
//                    list.stream().forEach(p -> logger.info(String.format("MQTT EventType: LightFault - %s", p)));
                    faultEventCounter.getAndAdd(list.size());
                    int[] done = faultReportRepository.save(list);
                    reportFault(list, done);

                }, error -> { logger.error(error.getMessage()); });

        parametersObservable
                .filter(parameters -> EventType.GET_GATEWAY_IP.equals(parameters.getEventType()))
                .map(event -> gatewayIPAddressUpdateEventMapper.toBlockEntity((GatewayIPAddressUpdateEvent) event))
                .collect(toList())
                .subscribe(list -> {
                    gatewayIPAddressUpdateEventCounter.getAndAdd(list.size());
                    blockRepository.save(list);
                }, error -> { logger.error(error.getMessage()); });

        parametersObservable
                .filter(parameters -> EventType.CONFIGURE_LIGHT.equals(parameters.getEventType()))
                .map(event -> configureLightEventMapper.toSmartLightEntity((ConfigureLightEvent) event))
                .collect(toList())
                .subscribe(list -> {
                    configureLightEventCounter.getAndAdd(list.size());
                    smartLightRepository.updateLightConfiguration(list);
                }, error -> { logger.error(error.getMessage()); });

        parametersObservable
                .filter(parameters -> EventType.CONFIGURE_PHOTOSENSOR.equals(parameters.getEventType()))
                .map(event -> configurePhotoSensorEventMapper.toSmartLightEntity((ConfigurePhotoSensorEvent) event))
                .collect(toList())
                .subscribe(list -> {
                    configurePhotoSensorEventCounter.getAndAdd(list.size());
                    smartLightRepository.updatePhotoSensorConfiguration(list);
                }, error -> { logger.error(error.getMessage()); });

        parametersObservable
                .filter(parameters -> EventType.FAULT_CLEAR.equals(parameters.getEventType()))
                .map(event -> clearFaultEventMapper.toFaultEntity((ClearFaultEvent) event))
                .collect(toList())
                .subscribe(list -> {
                    clearFaultEventCounter.getAndAdd(list.size());
                    faultReportRepository.update(list);
                }, error -> { logger.error(error.getMessage()); });

        parametersObservable.connect();
    }

    private void reportFault(List<FaultEntity> list, int[] done) {
        IntStream.range(0, list.size())
                .mapToObj(i -> done[i] == 1 ? Optional.of(list.get(i)) : Optional.empty())
                .filter(Optional::isPresent)
                .forEach(event -> {
                    Long blockNO = Long.parseLong(((FaultEntity)event.get()).getBlockNO());
                    List<String> emails = userAccountDetailRepository
                            .findByBlockNO(blockNO).stream()
                            .map(UserAccountDetail::getUserMailAddress)
                            .collect(toList());
                    // TODO: outsource email notification to "fault reporting service"
                    logger.info(String.format("Sending email for %s", event.get()));
                    logger.info(emails.toString());
                });
    }

    private void initializeEventCounters(MeterRegistry meterRegistry, Map<String, AtomicLong> counters) {
        counters.entrySet().stream()
                .forEach(entry -> {
                    meterRegistry.more().timer(
                            "mqtt_events",
                            Tags.of("eventType", entry.getKey()),
                            entry.getValue(),
                            counter -> counter.getAndSet(0),
                            counter -> 0.0,
                            TimeUnit.SECONDS);
                });
    }

}
