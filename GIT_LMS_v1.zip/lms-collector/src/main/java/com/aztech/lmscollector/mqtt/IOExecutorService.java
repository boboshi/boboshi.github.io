package com.aztech.lmscollector.mqtt;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IOExecutorService extends BaseExecutorService {
    private static final Logger logger = LoggerFactory.getLogger(IOExecutorService.class);
    public static IOExecutorService instance = null;

    private IOExecutorService(int poolSize) {
        super(poolSize);
        logger.info(String.format("Initialized thread pool with size of %d", poolSize));
    }

    public static IOExecutorService create(int poolSize) {
        if (instance == null) {
            instance = new IOExecutorService(poolSize);
        }
        return instance;
    }
}
