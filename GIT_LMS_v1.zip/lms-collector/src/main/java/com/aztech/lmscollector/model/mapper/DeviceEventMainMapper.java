package com.aztech.lmscollector.model.mapper;

import com.aztech.lmscollector.model.*;
import com.aztech.lmscollector.service.exception.NoSuchEventTypeException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.text.SimpleDateFormat;
import java.util.Map;

import static com.aztech.lmscollector.service.EventType.CONFIGURE_LIGHT;
import static com.aztech.lmscollector.service.EventType.CONFIGURE_PHOTOSENSOR;
import static com.aztech.lmscollector.service.EventType.FIRMWARE_READING;
import static com.aztech.lmscollector.service.EventType.GET_GATEWAY_IP;
import static com.aztech.lmscollector.service.EventType.LIGHTLEVEL_READING;
import static com.aztech.lmscollector.service.EventType.LIGHT_FAULT;
import static com.aztech.lmscollector.service.EventType.MOTION_READING;
import static com.aztech.lmscollector.service.EventType.PHOTOSENSOR_READING;
import static com.aztech.lmscollector.service.EventType.FAULT_CLEAR;
import static com.aztech.lmscollector.service.EventType.CONTROL_LIGHT;
import static com.aztech.lmscollector.util.ConstantValues.MqttPayloadKey.EVENT_TYPE;

public class DeviceEventMainMapper {
    public static DeviceEvent fromEventMessage(final EventMessage eventMessage) throws JsonProcessingException, NoSuchEventTypeException {
        final ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(JsonReadFeature.ALLOW_TRAILING_COMMA.mappedFeature());
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));

        final JsonNode root = objectMapper.readTree(eventMessage.getMessage());
        String eventType = root.get(EVENT_TYPE).asText("");

        if (MOTION_READING.equals(eventType)) {
            MotionDetectionEvent event = objectMapper.treeToValue(root, MotionDetectionEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (LIGHTLEVEL_READING.equals(eventType)) {
            CurrentLevelEvent event = objectMapper.treeToValue(root, CurrentLevelEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (PHOTOSENSOR_READING.equals(eventType)) {
            PhotoSensorEvent event = objectMapper.treeToValue(root, PhotoSensorEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (LIGHT_FAULT.equals(eventType)) {
            FaultEvent event = objectMapper.treeToValue(root, FaultEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (FIRMWARE_READING.equals(eventType)) {
            FirmwareEvent event = objectMapper.treeToValue(root, FirmwareEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (GET_GATEWAY_IP.equals(eventType)) {
            Map<String, Object> map = objectMapper.convertValue(root, Map.class);
            map.remove("Parameters");
            GatewayIPAddressUpdateEvent event = objectMapper.convertValue(map, GatewayIPAddressUpdateEvent.class);
            event.setParameter(root.get("Parameters").toString());
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (CONFIGURE_LIGHT.equals(eventType)) {
            ConfigureLightEvent event = objectMapper.treeToValue(root, ConfigureLightEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (CONFIGURE_PHOTOSENSOR.equals(eventType)) {
            ConfigurePhotoSensorEvent event = objectMapper.treeToValue(root, ConfigurePhotoSensorEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (FAULT_CLEAR.equals(eventType)) {
            ClearFaultEvent event = objectMapper.treeToValue(root, ClearFaultEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else if (CONTROL_LIGHT.equals(eventType)) {
            ControlLightEvent event = objectMapper.treeToValue(root, ControlLightEvent.class);
            // the objectMapper didn't set the blockNumber and lightId for some reason
            // therefore the setter is invoke explicitly to set both fields
            event.setSensorId(event.getSensorId());
            event.setParameterString(root.get("Parameters").toString());
            return event;
        } else {
            throw new NoSuchEventTypeException(String.format("Event type '%s' cannot be handled", eventType));
        }

    }
}
