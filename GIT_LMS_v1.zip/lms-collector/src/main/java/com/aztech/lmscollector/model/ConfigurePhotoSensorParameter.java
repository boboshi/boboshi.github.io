package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConfigurePhotoSensorParameter {
    private String commandType;
    private String photoSensing;
    private int photoSensorUpperThreshold;
    private int photoSensorLowerThreshold;

    public ConfigurePhotoSensorParameter() {
        this.commandType = "";
        this.photoSensing = "Enable";
        this.photoSensorUpperThreshold = 150;
        this.photoSensorLowerThreshold = 50;
    }

    @JsonProperty("CommandType")
    public String getCommandType() {
        return commandType;
    }

    public void setCommandType(String commandType) {
        this.commandType = commandType;
    }

    @JsonProperty("PhotoSensing")
    public String getPhotoSensing() {
        return photoSensing;
    }

    public void setPhotoSensing(String photoSensing) {
        this.photoSensing = photoSensing;
    }

    @JsonProperty("PhotoUpperThreshold")
    public int getPhotoSensorUpperThreshold() {
        return photoSensorUpperThreshold;
    }

    public void setPhotoSensorUpperThreshold(int photoSensorUpperThreshold) {
        this.photoSensorUpperThreshold = photoSensorUpperThreshold;
    }

    @JsonProperty("PhotoLowerThreshold")
    public int getPhotoSensorLowerThreshold() {
        return photoSensorLowerThreshold;
    }

    public void setPhotoSensorLowerThreshold(int photoSensorLowerThreshold) {
        this.photoSensorLowerThreshold = photoSensorLowerThreshold;
    }

    @Override
    public String toString() {
        return "ConfigurePhotoSensorParameter{" +
                "commandType='" + commandType + '\'' +
                ", photoSensing='" + photoSensing + '\'' +
                ", photoUpperThreshold=" + photoSensorUpperThreshold +
                ", photoLowerThreshold=" + photoSensorLowerThreshold +
                '}';
    }
}
