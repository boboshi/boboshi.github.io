package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.Date;

public class FaultParameter {
    private int severity;
    private String tripGeneralAlarm;
    private Date reportedDate;

    public FaultParameter() {
        this.severity = 1;
        this.tripGeneralAlarm = "Yes";
        this.reportedDate = Date.from(Instant.now());
    }

    @JsonProperty("Severity")
    public int getSeverity() {
        return severity;
    }

    public void setSeverity(int severity) {
        this.severity = severity;
    }

    @JsonProperty("TripGeneralAlarm")
    public String getTripGeneralAlarm() {
        return tripGeneralAlarm;
    }

    public void setTripGeneralAlarm(String tripGeneralAlarm) {
        this.tripGeneralAlarm = tripGeneralAlarm;
    }

    @JsonProperty("Time")
    public Date getReportedDate() {
        return reportedDate;
    }

    public void setReportedDate(Date reportedDate) {
        this.reportedDate = reportedDate;
    }

    @Override
    public String toString() {
        return "FaultParameter{" +
                "severity=" + severity +
                ", tripGeneralAlarm='" + tripGeneralAlarm + '\'' +
                ", reportedDate=" + reportedDate +
                '}';
    }
}
