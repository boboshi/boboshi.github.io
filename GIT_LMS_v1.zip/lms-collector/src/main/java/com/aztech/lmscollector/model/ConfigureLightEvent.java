package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConfigureLightEvent extends DeviceEvent {
    private ConfigureLightParameter parameter;

    public ConfigureLightEvent() {
        this.parameter = new ConfigureLightParameter();
    }

    @JsonProperty("Parameters")
    public ConfigureLightParameter getParameter() {
        return parameter;
    }

    public void setParameter(ConfigureLightParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "ConfigureLightEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameter=" + parameter +
                '}';
    }
}
