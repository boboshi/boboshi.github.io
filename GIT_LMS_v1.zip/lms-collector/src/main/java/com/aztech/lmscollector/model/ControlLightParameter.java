package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ControlLightParameter {
    private String commandType;
    private String lightingControl;

    public ControlLightParameter() {
        this.commandType = "";
        this.lightingControl = "";
    }

    @JsonProperty("CommandType")
    public String getCommandType() {
        return commandType;
    }

    public void setCommandType(String commandType) {
        this.commandType = commandType;
    }

    @JsonProperty("LightingControl")
    public String getLightingControl() {
        return lightingControl;
    }

    public void setLightingControl(String lightingControl) {
        this.lightingControl = lightingControl;
    }

    @Override
    public String toString() {
        return "ControlLightParameter{" +
                "commandType='" + commandType + '\'' +
                ", lightingControl='" + lightingControl + '\'' +
                '}';
    }
}
