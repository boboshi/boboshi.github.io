package com.aztech.lmscollector.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhotoSensorEvent extends DeviceEvent {
    private PhotoSensorParameter parameter;

    public PhotoSensorEvent() {
        this.parameter = new PhotoSensorParameter();
    }

    @JsonProperty("Parameters")
    public PhotoSensorParameter getParameter() {
        return parameter;
    }

    public void setParameter(PhotoSensorParameter parameter) {
        this.parameter = parameter;
    }

    @Override
    public String toString() {
        return "PhotoSensorEvent{" +
                "DeviceEvent=" + super.toString() +
                ", parameter=" + parameter +
                '}';
    }
}
