package com.aztech.lmscollector.entity;

import java.time.Instant;
import java.util.Date;
import java.util.Objects;

public class CurrentLevelEntity {
    private int currentLevel;
    private Date reportDateTime;
    private String lightSN;
    private String blockNO;

    public CurrentLevelEntity() {
        this.currentLevel = 100;
        this.reportDateTime = Date.from(Instant.now());
        this.lightSN = "";
        this.blockNO = "";
    }

    public int getCurrentLevel() {
        return currentLevel;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    public Date getReportDateTime() {
        return reportDateTime;
    }

    public void setReportDateTime(Date reportDateTime) {
        this.reportDateTime = reportDateTime;
    }

    public String getLightSN() {
        return lightSN;
    }

    public void setLightSN(String lightSN) {
        this.lightSN = lightSN;
    }

    public String getBlockNO() {
        return blockNO;
    }

    public void setBlockNO(String blockNO) {
        this.blockNO = blockNO;
    }

    @Override
    public String toString() {
        return "CurrentLevelEntity{" +
                "currentLevel=" + currentLevel +
                ", reportDateTime=" + reportDateTime +
                ", lightSN='" + lightSN + '\'' +
                ", blockNO='" + blockNO + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CurrentLevelEntity)) return false;
        CurrentLevelEntity that = (CurrentLevelEntity) o;
        return currentLevel == that.currentLevel &&
                Objects.equals(reportDateTime, that.reportDateTime) &&
                Objects.equals(lightSN, that.lightSN) &&
                Objects.equals(blockNO, that.blockNO);
    }

    @Override
    public int hashCode() {
        return Objects.hash(currentLevel, reportDateTime, lightSN, blockNO);
    }
}
