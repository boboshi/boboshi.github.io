package com.aztech.lmscollector.repository;

import com.aztech.lmscollector.entity.UserAccountDetail;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Set;

public interface UserAccountDetailRepository extends CrudRepository<UserAccountDetail, Long> {
    @Query("SELECT DISTINCT ua.userId, userMailAddress FROM userBlock ub INNER JOIN block b ON ub.blockId = b.blockId INNER JOIN userAccount ua ON ub.userId = ua.userId WHERE b.blockNO = :blockNO;")
    Set<UserAccountDetail> findByBlockNO(@Param("blockNO") Long blockNO);
}
