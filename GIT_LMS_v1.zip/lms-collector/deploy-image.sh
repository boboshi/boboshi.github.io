#!/usr/bin/env sh

docker image build --build-arg SERVER_PORT=9090 --build-arg APP_BIN=lms-collector-0.0.1-SNAPSHOT.jar --tag lms-collector:latest .
docker image tag lms-collector:latest aztechsg/lms-collector:latest
docker image push aztechsg/lms-collector:latest
