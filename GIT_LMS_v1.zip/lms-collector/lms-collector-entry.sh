#!/usr/bin/env sh

set -e
echo "Setting up lms-collector..."
./wait-for-it.sh $DB_SERVICE -s -t 120 -- java -jar lms-collector.jar